<?php
session_start();
require_once __DIR__ . '/../config.php';

$search = isset($_REQUEST['search']) ? sanitize($_REQUEST['search']) : '';

if (!empty($search)) {
    $_SESSION['empresa'] = $search;
    redirect("../reclame/index.php");
}

redirect("index.php?error=Por favor, informe o nome da empresa.");
?>