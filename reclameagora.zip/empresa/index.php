<?php
session_start();
require_once '../config.php';
?>
<html lang="pt-BR">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width">
  <meta name="next-head-count" content="2">
  <link id="ra-header-style" href="./assets/style.css" rel="stylesheet">
  <link id="ra-hero-styles" href="./assets/style(1).css" rel="stylesheet">
  <link id="premio-award-stamp-styles" href="./assets/style(2).css" rel="stylesheet">
  <link id="premio-award-voting-box-styles" href="./assets/style(3).css" rel="stylesheet">
  <link rel="stylesheet" href="./assets/design_system.css">
  <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
  <link rel="preload" href="./assets/b6394e2e171f558c.css" as="style">
  <link rel="stylesheet" href="./assets/b6394e2e171f558c.css" data-n-g="">
  <style data-styled="active" data-styled-version="5.3.11"></style>
  <style data-styled="active" data-styled-version="5.0.0"></style>
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-17024935081"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-17024935081');
</script>

  <style data-href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&amp;display=swap">
    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: normal;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memSYaGs126MiZpBA-UvWbX2vVnXBbObj2OVZyOOSr4dVJWUgsiH0C4k.woff) format('woff')
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: normal;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memSYaGs126MiZpBA-UvWbX2vVnXBbObj2OVZyOOSr4dVJWUgsjZ0C4k.woff) format('woff')
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: normal;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memSYaGs126MiZpBA-UvWbX2vVnXBbObj2OVZyOOSr4dVJWUgsgH1y4k.woff) format('woff')
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: normal;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memSYaGs126MiZpBA-UvWbX2vVnXBbObj2OVZyOOSr4dVJWUgsg-1y4k.woff) format('woff')
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSumu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSymu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS2mu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTVOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C, U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9, U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043, U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1, U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE, U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319, U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF, U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF, U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTUGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190, U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F, U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF, U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB, U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF, U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382, U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0, U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442, U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9, U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7, U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A, U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2, U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC, U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD, U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9, U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9, U+1FAF0-1FAF8, U+1FB00-1FBFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSCmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 300;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSumu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSymu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS2mu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTVOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C, U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9, U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043, U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1, U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE, U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319, U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF, U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF, U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTUGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190, U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F, U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF, U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB, U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF, U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382, U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0, U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442, U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9, U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7, U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A, U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2, U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC, U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD, U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9, U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9, U+1FAF0-1FAF8, U+1FB00-1FBFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSCmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 400;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSumu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSymu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS2mu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTVOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C, U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9, U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043, U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1, U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE, U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319, U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF, U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF, U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTUGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190, U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F, U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF, U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB, U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF, U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382, U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0, U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442, U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9, U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7, U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A, U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2, U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC, U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD, U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9, U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9, U+1FAF0-1FAF8, U+1FB00-1FBFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSCmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 600;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSumu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSymu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS2mu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0307-0308, U+0590-05FF, U+200C-2010, U+20AA, U+25CC, U+FB1D-FB4F
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTVOmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C, U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9, U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043, U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1, U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE, U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319, U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF, U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF, U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTUGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190, U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F, U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF, U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB, U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF, U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382, U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0, U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442, U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9, U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7, U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A, U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2, U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC, U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD, U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9, U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9, U+1FAF0-1FAF8, U+1FB00-1FBFF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSCmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSGmu0SC55K5gw.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Open Sans';
      font-style: normal;
      font-weight: 700;
      font-stretch: 100%;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/opensans/v40/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-mu0SC55I.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }
  </style>
  <style data-href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&amp;display=swap">
    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuOKfMZs.woff) format('woff')
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuLyfMZs.woff) format('woff')
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuGKYMZs.woff) format('woff')
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYMZs.woff) format('woff')
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2JL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa0ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa25L7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7W0Q5nw.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2JL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa0ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa25L7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7W0Q5nw.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2JL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa0ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa25L7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 600;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7W0Q5nw.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2JL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa0ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2ZL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+1F00-1FFF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa2pL7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa25L7W0Q5n-wU.woff2) format('woff2');
      unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF
    }

    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/inter/v18/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7W0Q5nw.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD
    }
  </style>
  <link rel="stylesheet" type="text/css" href="./assets/95f8be1f38fdb515.css">
  <style type="text/css">
    .__react_component_tooltip {
      border-radius: 3px;
      display: inline-block;
      font-size: 13px;
      left: -999em;
      opacity: 0;
      padding: 8px 21px;
      position: fixed;
      pointer-events: none;
      transition: opacity 0.3s ease-out;
      top: -999em;
      visibility: hidden;
      z-index: 999;
    }

    .__react_component_tooltip.allow_hover,
    .__react_component_tooltip.allow_click {
      pointer-events: auto;
    }

    .__react_component_tooltip:before,
    .__react_component_tooltip:after {
      content: "";
      width: 0;
      height: 0;
      position: absolute;
    }

    .__react_component_tooltip.show {
      opacity: 0.9;
      margin-top: 0px;
      margin-left: 0px;
      visibility: visible;
    }

    .__react_component_tooltip.type-dark {
      color: #fff;
      background-color: #222;
    }

    .__react_component_tooltip.type-dark.place-top:after {
      border-top-color: #222;
      border-top-style: solid;
      border-top-width: 6px;
    }

    .__react_component_tooltip.type-dark.place-bottom:after {
      border-bottom-color: #222;
      border-bottom-style: solid;
      border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-dark.place-left:after {
      border-left-color: #222;
      border-left-style: solid;
      border-left-width: 6px;
    }

    .__react_component_tooltip.type-dark.place-right:after {
      border-right-color: #222;
      border-right-style: solid;
      border-right-width: 6px;
    }

    .__react_component_tooltip.type-dark.border {
      border: 1px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-top:before {
      border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-bottom:before {
      border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-left:before {
      border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-dark.border.place-right:before {
      border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-success {
      color: #fff;
      background-color: #8DC572;
    }

    .__react_component_tooltip.type-success.place-top:after {
      border-top-color: #8DC572;
      border-top-style: solid;
      border-top-width: 6px;
    }

    .__react_component_tooltip.type-success.place-bottom:after {
      border-bottom-color: #8DC572;
      border-bottom-style: solid;
      border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-success.place-left:after {
      border-left-color: #8DC572;
      border-left-style: solid;
      border-left-width: 6px;
    }

    .__react_component_tooltip.type-success.place-right:after {
      border-right-color: #8DC572;
      border-right-style: solid;
      border-right-width: 6px;
    }

    .__react_component_tooltip.type-success.border {
      border: 1px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-top:before {
      border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-bottom:before {
      border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-left:before {
      border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-success.border.place-right:before {
      border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning {
      color: #fff;
      background-color: #F0AD4E;
    }

    .__react_component_tooltip.type-warning.place-top:after {
      border-top-color: #F0AD4E;
      border-top-style: solid;
      border-top-width: 6px;
    }

    .__react_component_tooltip.type-warning.place-bottom:after {
      border-bottom-color: #F0AD4E;
      border-bottom-style: solid;
      border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-warning.place-left:after {
      border-left-color: #F0AD4E;
      border-left-style: solid;
      border-left-width: 6px;
    }

    .__react_component_tooltip.type-warning.place-right:after {
      border-right-color: #F0AD4E;
      border-right-style: solid;
      border-right-width: 6px;
    }

    .__react_component_tooltip.type-warning.border {
      border: 1px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-top:before {
      border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-bottom:before {
      border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-left:before {
      border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-warning.border.place-right:before {
      border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-error {
      color: #fff;
      background-color: #BE6464;
    }

    .__react_component_tooltip.type-error.place-top:after {
      border-top-color: #BE6464;
      border-top-style: solid;
      border-top-width: 6px;
    }

    .__react_component_tooltip.type-error.place-bottom:after {
      border-bottom-color: #BE6464;
      border-bottom-style: solid;
      border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-error.place-left:after {
      border-left-color: #BE6464;
      border-left-style: solid;
      border-left-width: 6px;
    }

    .__react_component_tooltip.type-error.place-right:after {
      border-right-color: #BE6464;
      border-right-style: solid;
      border-right-width: 6px;
    }

    .__react_component_tooltip.type-error.border {
      border: 1px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-top:before {
      border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-bottom:before {
      border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-left:before {
      border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-error.border.place-right:before {
      border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-info {
      color: #fff;
      background-color: #337AB7;
    }

    .__react_component_tooltip.type-info.place-top:after {
      border-top-color: #337AB7;
      border-top-style: solid;
      border-top-width: 6px;
    }

    .__react_component_tooltip.type-info.place-bottom:after {
      border-bottom-color: #337AB7;
      border-bottom-style: solid;
      border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-info.place-left:after {
      border-left-color: #337AB7;
      border-left-style: solid;
      border-left-width: 6px;
    }

    .__react_component_tooltip.type-info.place-right:after {
      border-right-color: #337AB7;
      border-right-style: solid;
      border-right-width: 6px;
    }

    .__react_component_tooltip.type-info.border {
      border: 1px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-top:before {
      border-top: 8px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-bottom:before {
      border-bottom: 8px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-left:before {
      border-left: 8px solid #fff;
    }

    .__react_component_tooltip.type-info.border.place-right:before {
      border-right: 8px solid #fff;
    }

    .__react_component_tooltip.type-light {
      color: #222;
      background-color: #fff;
    }

    .__react_component_tooltip.type-light.place-top:after {
      border-top-color: #fff;
      border-top-style: solid;
      border-top-width: 6px;
    }

    .__react_component_tooltip.type-light.place-bottom:after {
      border-bottom-color: #fff;
      border-bottom-style: solid;
      border-bottom-width: 6px;
    }

    .__react_component_tooltip.type-light.place-left:after {
      border-left-color: #fff;
      border-left-style: solid;
      border-left-width: 6px;
    }

    .__react_component_tooltip.type-light.place-right:after {
      border-right-color: #fff;
      border-right-style: solid;
      border-right-width: 6px;
    }

    .__react_component_tooltip.type-light.border {
      border: 1px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-top:before {
      border-top: 8px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-bottom:before {
      border-bottom: 8px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-left:before {
      border-left: 8px solid #222;
    }

    .__react_component_tooltip.type-light.border.place-right:before {
      border-right: 8px solid #222;
    }

    .__react_component_tooltip.place-top {
      margin-top: -10px;
    }

    .__react_component_tooltip.place-top:before {
      border-left: 10px solid transparent;
      border-right: 10px solid transparent;
      bottom: -8px;
      left: 50%;
      margin-left: -10px;
    }

    .__react_component_tooltip.place-top:after {
      border-left: 8px solid transparent;
      border-right: 8px solid transparent;
      bottom: -6px;
      left: 50%;
      margin-left: -8px;
    }

    .__react_component_tooltip.place-bottom {
      margin-top: 10px;
    }

    .__react_component_tooltip.place-bottom:before {
      border-left: 10px solid transparent;
      border-right: 10px solid transparent;
      top: -8px;
      left: 50%;
      margin-left: -10px;
    }

    .__react_component_tooltip.place-bottom:after {
      border-left: 8px solid transparent;
      border-right: 8px solid transparent;
      top: -6px;
      left: 50%;
      margin-left: -8px;
    }

    .__react_component_tooltip.place-left {
      margin-left: -10px;
    }

    .__react_component_tooltip.place-left:before {
      border-top: 6px solid transparent;
      border-bottom: 6px solid transparent;
      right: -8px;
      top: 50%;
      margin-top: -5px;
    }

    .__react_component_tooltip.place-left:after {
      border-top: 5px solid transparent;
      border-bottom: 5px solid transparent;
      right: -6px;
      top: 50%;
      margin-top: -4px;
    }

    .__react_component_tooltip.place-right {
      margin-left: 10px;
    }

    .__react_component_tooltip.place-right:before {
      border-top: 6px solid transparent;
      border-bottom: 6px solid transparent;
      left: -8px;
      top: 50%;
      margin-top: -5px;
    }

    .__react_component_tooltip.place-right:after {
      border-top: 5px solid transparent;
      border-bottom: 5px solid transparent;
      left: -6px;
      top: 50%;
      margin-top: -4px;
    }

    .__react_component_tooltip .multi-line {
      display: block;
      padding: 2px 0px;
      text-align: center;
    }
  </style>
  <style data-jss="" data-meta="MuiSvgIcon">
    .MuiSvgIcon-root {
      fill: currentColor;
      width: 1em;
      height: 1em;
      display: inline-block;
      font-size: 1.5rem;
      transition: fill 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
      flex-shrink: 0;
      user-select: none;
    }

    .MuiSvgIcon-colorPrimary {
      color: #3f51b5;
    }

    .MuiSvgIcon-colorSecondary {
      color: #f50057;
    }

    .MuiSvgIcon-colorAction {
      color: rgba(0, 0, 0, 0.54);
    }

    .MuiSvgIcon-colorError {
      color: #f44336;
    }

    .MuiSvgIcon-colorDisabled {
      color: rgba(0, 0, 0, 0.26);
    }

    .MuiSvgIcon-fontSizeInherit {
      font-size: inherit;
    }

    .MuiSvgIcon-fontSizeSmall {
      font-size: 1.25rem;
    }

    .MuiSvgIcon-fontSizeLarge {
      font-size: 2.1875rem;
    }
  </style>
  <title>Reclame AQUI - Pesquise antes de comprar. Reclame. Resolva</title>
  <link id="footer-style" rel="stylesheet" href="./assets/style(4).css">
  <style>
    .imCMmm input {
      font-size: 16px;
      border-radius: 6px;
      border: 1px solid rgb(225, 227, 229);
      padding: 16px 24px;
      color: rgb(0, 0, 0);
      font-weight: 400;
      background-color: rgb(255, 255, 255);
      width: 100%;
      box-sizing: border-box;
    }

    @media (max-width: 768px) {
      .kMVjGD {
        display: none;
      }
    }

    .kMVjGD {
      position: absolute;
      right: 1.5%;
      top: 41%;
      height: 46px;
    }

    .czGLxd {
      position: relative;
      color: rgb(255, 255, 255);
      font-size: 14px;
      border-radius: 4px;
      border: 0px;
      height: 40px;
      padding: 10px 16px 11px;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      box-sizing: border-box;
      width: 100%;
      max-width: 129px;
      background: rgb(31, 105, 193);
      transition: background 0.2s;
    }

    .czGLxd svg {
      margin-right: 15px;
      font-size: 24px;
      fill: rgb(255, 255, 255);
      width: 24px;
      height: 24px;
    }

    .MuiSvgIcon-root {
      fill: currentColor;
      width: 1em;
      height: 1em;
      display: inline-block;
      font-size: 1.5rem;
      transition: fill 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
      flex-shrink: 0;
      user-select: none;
    }

    .czGLxd span {
      font-weight: 600;
      font-size: 14px;
    }

    .czGLxd .progress {
      position: absolute;
      width: 0%;
      background: black;
      opacity: 0;
      transition: 0.3s;
      inset: 0px;
      z-index: 5;
    }

    .hHFEFV {
      background: rgb(234, 237, 240);
      min-height: 100vh;
      display: flex;

      flex-direction: column;
    }

    @media (max-width: 768px) {
      .ovvef {
        padding: 30px 20px;
        margin: 20px 10px;
        width: calc(100% - 20px);
      }
    }

    .ovvef {
      max-width: 1000px;
      width: 95%;
      padding: 60px;
      background: rgb(255, 255, 255);
      border-radius: 12px;
      box-shadow: rgba(0, 0, 0, 0.08) 0px 4px 30px 0px;
      margin-top: 40px;
      margin-bottom: 40px;
      align-self: center;
    }

    html,
    body {
      margin: 0px;
      padding: 0px;
      font-family: "Open Sans", sans-serif;
    }

    body {
      overflow-x: hidden;
    }

    .hOBhIY {
      width: 100%;
      font-size: 14px;
      color: rgb(31, 105, 193);
      margin: 48px 0px 8px;
      text-decoration: none;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
    }

    .iunUub {
      position: fixed;
      left: 50%;
      bottom: 0px;
      transform: translate(-50%, 0px);
      overflow: hidden;
      display: flex;
      flex-direction: column;
      z-index: 1000;
    }

    .iunUub {
      position: fixed;
      left: 50%;
      bottom: 0px;
      transform: translate(-50%, 0px);
      overflow: hidden;
      display: flex;
      flex-direction: column;
      z-index: 1000;
    }

    @media (max-width: 768px) {
      .gsmcgD {
        font-size: 24px;
        margin-top: 42px;
        margin-bottom: 50px;
      }
    }

    h2 {
      font-size: 22px;
    }

    .dnrNPY {
      display: flex;
      -webkit-box-align: center;
      align-items: center;
    }

    @media (max-width: 768px) {
      .imCMmm input {
        font-size: 16px;
        padding: 16px;
      }
    }

    .dqbsRD {
      color: rgb(75, 89, 99);
      display: block;
      margin-bottom: 8px;
      font-size: 16px;
      font-weight: 600;
    }

    .dqbsRD span {
      font-weight: 400;
      color: rgb(75, 89, 99);
    }

    .dqbsRD {
      color: rgb(75, 89, 99);
      display: block;
      margin-bottom: 8px;
      font-size: 16px;
      font-weight: 600;
    }

    .imCMmm {
      position: relative;
      font-weight: 300;
    }

    .gsmcgD {
      color: rgb(75, 89, 99);
      font-size: 38px;
      text-align: center;
      font-weight: 700;
      margin-top: 40px;
      margin-bottom: 40px;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
      font-weight: 600;
      margin: 0px 0px 8px;
    }

    .btmUVm {
      position: relative;
    }

    .bbfAHr {
      margin-bottom: 0px;
      background-color: rgb(249, 249, 249);
    }

    .gwSFwe {
      background-color: rgb(250, 250, 250);
      min-height: 100vh;
    }

    .dRjSTx {
      z-index: 1;
    }

    header.svelte-6k84nk {
      background-color: #fff;
      border-bottom: 2px solid #e1e3e5;
      padding: 4px 0;
      width: 100%;
      z-index: 4;
    }

    .z-40 {
      z-index: 40;
    }

    .relative {
      position: relative;
    }

    .hAfkWS>* {
      box-sizing: border-box;
    }

    .px-4 {
      padding-left: 1rem;
      padding-right: 1rem;
    }

    .gap-x-8 {
      -moz-column-gap: 2rem;
      column-gap: 2rem;
    }

    .justify-start {
      justify-content: flex-start;
    }

    .items-center {
      align-items: center;
    }

    .max-w-full {
      max-width: 100%;
    }

    .w-screen {
      width: 100vw;
    }

    .h-\[55px\] {
      height: 55px;
    }

    .flex {
      display: flex;
    }

    .box-border {
      box-sizing: border-box;
    }

    .m-auto {
      margin: auto;
    }

    .left-0 {
      left: 0;
    }

    .logo-desktop.svelte-6k84nk {
      background-image: url(https://storage.googleapis.com/reclameaqui-assets/images/logo.svg);
      background-position-y: center;
      background-size: inherit;
      background-size: contain;
    }

    .ra-logo.svelte-6k84nk {
      background-position: 50%;
      background-repeat: no-repeat;
      cursor: pointer;
      height: 60px;
      width: 180px;
    }

    @media (max-width: 920px) {
      .hide-in-mobile {
        display: none;
      }
    }

    @media (max-width: 920px) {
      .hide-in-mobile {
        display: none;
      }
    }

    a {
      text-decoration: none;
    }

    @media (max-width: 920px) {
      .logo-mobile.svelte-6k84nk {
        height: 50px;
        width: 40px;
      }
    }

    .logo-mobile.svelte-6k84nk {
      background-image: url(https://storage.googleapis.com/reclameaqui-assets/libraries/header/images/logo-mobile.svg);
      height: 60px;
      width: 180px;
    }

    .ra-logo.svelte-6k84nk {
      background-position: 50%;
      background-repeat: no-repeat;
      cursor: pointer;
      height: 60px;
      width: 180px;
    }

    header.svelte-6k84nk {
      background-color: #fff;
      border-bottom: 2px solid #e1e3e5;
      padding: 4px 0;
      width: 100%;
      z-index: 4;
    }
  </style>
</head>

<body>
  <div id="__next" data-reactroot="">
    <div id="header" class="sc-12zshe7-0 hAfkWS">
      <div>
        <header class="lg:pb-[69px] relative z-40 svelte-6k84nk" data-testid="reduced-header">
          <div id="header-mobile-container" class="flex max-w-full lg:max-w-[1100px] m-auto px-4 items-center gap-x-8 justify-start box-border h-[55px] left-0 w-screen"><a href="../index.php" class="ra-logo logo-desktop hide-in-mobile svelte-6k84nk" title="Logotipo cabeçalho ReclameAQUI" data-testid="brand"></a> <a href="../index.php" class="ra-logo logo-mobile hide-in-desktop svelte-6k84nk" title="Logotipo cabeçalho ReclameAQUI modelo mobile" data-testid="brand"></a></div>
        </header>
      </div>
    </div>

    <div class="main-content-wrapper">
      <div class="search-hero">
        <div class="search-container-v2">
          <h1>Encontre a empresa para reclamar</h1>
          <p>Digite o nome da empresa e clique em buscar para iniciar sua reclamação.</p>
          
          <form action="./process.php" method="post" class="search-form-v2">
            <div class="input-group-v2">
              <svg class="search-icon-svg" viewBox="0 0 24 24">
                <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
              </svg>
              <input 
                id="search" 
                name="search" 
                type="text" 
                placeholder="Ex: Empresa de Energia, Banco, Loja..." 
                required
                value="<?php echo isset($_GET['search']) ? sanitize($_GET['search']) : ''; ?>"
              >
              <button type="submit">Buscar Empresa</button>
            </div>
          </form>

          <div class="popular-searches">
            <span>Empresas sugeridas:</span>
            <div class="company-chips">
              <a href="process.php?search=Enel" class="chip">Enel</a>
              <a href="process.php?search=Nubank" class="chip">Nubank</a>
              <a href="process.php?search=Mercado Livre" class="chip">Mercado Livre</a>
              <a href="process.php?search=Santander" class="chip">Santander</a>
              <a href="process.php?search=Vivo" class="chip">Vivo</a>
            </div>
          </div>
        </div>
      </div>

      <div class="info-section">
        <div class="info-card">
          <div class="info-icon">🔍</div>
          <h3>Pesquise</h3>
          <p>Veja a reputação da empresa antes de fazer negócio.</p>
        </div>
        <div class="info-card">
          <div class="info-icon">📝</div>
          <h3>Reclame</h3>
          <p>Conte seu problema e a empresa será notificada.</p>
        </div>
        <div class="info-card">
          <div class="info-icon">✅</div>
          <h3>Resolva</h3>
          <p>Acompanhe a resposta e finalize sua reclamação.</p>
        </div>
      </div>
    </div>

    <style>
      :root {
        --primary: #02793e;
        --secondary: #4A90E2;
        --text: #333;
        --bg: #f8f9fa;
      }
      body {
        margin: 0;
        font-family: 'Open Sans', sans-serif;
        background-color: var(--bg);
      }
      .main-content-wrapper {
        min-height: 80vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 60px 20px;
      }
      .search-hero {
        width: 100%;
        max-width: 1000px;
        background: white;
        padding: 60px;
        border-radius: 15px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.08);
        text-align: center;
      }
      .search-hero h1 {
        color: var(--primary);
        font-size: 2.2rem;
        margin-bottom: 10px;
      }
      .search-hero p {
        color: #666;
        margin-bottom: 30px;
      }
      .search-form-v2 {
        width: 100%;
      }
      .input-group-v2 {
        display: flex;
        position: relative;
        align-items: center;
        gap: 10px;
      }
      .search-icon-svg {
        position: absolute;
        left: 20px;
        width: 24px;
        height: 24px;
        fill: #999;
      }
      .input-group-v2 input {
        flex: 1;
        padding: 18px 20px 18px 55px;
        border: 2px solid #eee;
        border-radius: 50px;
        font-size: 1rem;
        transition: all 0.3s;
        outline: none;
      }
      .input-group-v2 input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 10px rgba(2, 121, 62, 0.1);
      }
      .input-group-v2 button {
        padding: 18px 30px;
        background: var(--primary);
        color: white;
        border: none;
        border-radius: 50px;
        font-weight: 600;
        cursor: pointer;
        transition: transform 0.2s, background 0.3s;
      }
      .input-group-v2 button:hover {
        background: #015c2f;
        transform: translateY(-2px);
      }
      .popular-searches {
        margin-top: 30px;
        text-align: left;
      }
      .popular-searches span {
        font-size: 0.9rem;
        color: #888;
        display: block;
        margin-bottom: 10px;
      }
      .company-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
      }
      .chip {
        padding: 8px 16px;
        background: #f0f0f0;
        border-radius: 20px;
        text-decoration: none;
        color: #555;
        font-size: 0.85rem;
        transition: all 0.2s;
      }
      .chip:hover {
        background: var(--primary);
        color: white;
      }
      .info-section {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 30px;
        margin-top: 50px;
        max-width: 1100px;
        width: 90%;
      }
      .info-card {
        background: white;
        padding: 30px;
        border-radius: 15px;
        text-align: center;
        box-shadow: 0 5px 15px rgba(0,0,0,0.02);
      }
      .info-icon {
        font-size: 30px;
        margin-bottom: 15px;
      }
      .info-card h3 {
        margin: 10px 0;
        color: var(--primary);
      }
      .info-card p {
        color: #777;
        font-size: 0.9rem;
      }
      @media (max-width: 768px) {
        .main-content-wrapper {
          padding: 20px 15px;
        }
        .search-hero {
          padding: 30px 20px;
          width: 100%;
        }
        .search-hero h1 {
          font-size: 1.8rem;
        }
        .input-group-v2 {
          flex-direction: column;
        }
        .input-group-v2 button {
          width: 100%;
        }
        .info-section {
          grid-template-columns: 1fr;
        }
      }
    </style>

    <div id="footer">
      <footer id="footer-ra" class="tw-footer svelte-1mz1hj3">
        <div class="reduced-footer svelte-1mz1hj3"><a target="_top" class="svelte-1mz1hj3">Nossos termos de uso</a> <a target="_top" class="svelte-1mz1hj3">Política de privacidade</a></div>
      </footer>
    </div>
    <div id="toast-container" data-testid="toast-container" class="sc-AykKH iunUub"></div>
    <div class="sc-jOnpCo iwHvJm">
      <div class="sc-kFWlue dyizjL">
        <div class="sc-bkEOxz gRIKPX"></div>
        <div tabindex="0" role="button" class="sc-dhFUGM fczIiz"><svg style="width:24px;height:24px" viewBox="0 0 24 24">
            <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"></path>
          </svg></div>
      </div>
    </div>
  </div>
  <next-route-announcer>
    <p aria-live="assertive" id="__next-route-announcer__" role="alert" style="border: 0px; clip: rect(0px, 0px, 0px, 0px); height: 1px; margin: -1px; overflow: hidden; padding: 0px; position: absolute; width: 1px; white-space: nowrap; overflow-wrap: normal;"></p>
  </next-route-announcer>
  <div style="display: none; visibility: hidden;">

  </div>
  <style>
    .dgdmyD svg {
      font-size: 90px !important;
    }
  </style>
  <div style="display: none; visibility: hidden;">
    <script>
      localStorage.getItem("cf-additionalInfo") === "undefined" && localStorage.removeItem("cf-additionalInfo");
    </script>
  </div>
  <div style="display: none; visibility: hidden;">

  </div>
  <meta name="adopt-website-id" content="09bf4d91-aab2-45ed-9cae-494acf39ec1d">
  <style>
    body>dl-template>div>div>div.dl-content>div.dl-footer.dl-footer-link {
      display: none !important;
    }

    @media (min-width: 768px) and (orientation: landscape) {
      .cc-window {
        left: 0 !important;
        right: 0 !important;
        margin: 0 auto !important;
        width: 55% !important;
        padding: 24px !important;
      }

      .cc-window.cc-floating.cc-type-opt-in {
        width: 55% !important;
        padding: 24px !important;
      }

      .cc-message-container {
        padding: 0px !important;

      }

      .cc-message {
        padding: 0px !important;
        padding-left: 0px !important;
        padding-right: 0px !important;
      }
    }

    @media only screen and (max-width: 800px) {
      .cc-type-opt-in {
        margin: 0px !important;
      }
    }
  </style>
  <style>
    .go1690009051 {
      color: #000;
    }

    .fuJtcf {
      background-color: white;
    }

    .iaWhiq img {
      background-color: white;
    }

    .iRgTQW img {
      background-color: white;
    }

    .jibPFy {
      gap: 1.5em;
    }



    @media only screen and (max-width: 800px) {
      #header-search-overlay-wrapper {
        top: 62px;
      }

      .cc-type-opt-in {
        margin: 0px 10px 85px 10px;
        padding: 0px 10px;
        border: 1px solid #cecece;
      }

      .cc-message {
        margin-bottom: 0px !Important;
      }

      #cookieconsent\:desc>p:nth-child(2) {
        margin-bottom: 5px !important;
      }
    }

    @media screen and (min-width: 768px) {
      #header-search-overlay-wrapper {
        top: 74px;
      }
    }

    html {
      overflow-x: hidden;
    }
  </style>

  <div style="display: none; visibility: hidden;">
    <style type="text/css">
      #header-mobile-container>div.bg-white.z-50.px-\[18px\].w-full {
        display: none;
      }

      #menu-bottom {
        display: none !important;
      }

      #btn-access-my-complaint {
        padding: 10px;
      }
    </style>
  </div>
  <div style="display: none; visibility: hidden;">
    <style type="text/css">
      div#page-header: {
        position: relative !important
      }

      header.beLWHS {
        position: relative !important
      }
    </style>
  </div>
  <div style="display: none; visibility: hidden;">




  </div>


</body>

</html>