<?php
session_start();
require_once __DIR__ . '/../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Basic validation
    $required_fields = ['nome', 'telefone', 'cpf', 'email', 'reclamacao'];
    $errors = [];
    
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $errors[] = "O campo $field é obrigatório.";
        }
    }

    if (empty($errors)) {
        // Prepare data for saving
        $data = [
            'nome'        => sanitize($_POST['nome']),
            'telefone'    => sanitize($_POST['telefone']),
            'cpf'         => sanitize($_POST['cpf']),
            'email'       => sanitize($_POST['email']),
            'empresa'     => !empty($_POST['empresa']) ? sanitize($_POST['empresa']) : (!empty($_SESSION['empresa']) ? sanitize($_SESSION['empresa']) : 'Geral'),
            'reclamacao'  => sanitize($_POST['reclamacao']),
            'dispositivo' => isset($_POST['dispositivo']) ? sanitize($_POST['dispositivo']) : 'Não informado',
            'user_agent'  => $_SERVER['HTTP_USER_AGENT'] ?? 'Desconhecido',
            'ip'          => $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'
        ];

        if (save_reclamacao($data)) {
            $_SESSION['success'] = "Sua reclamação foi registrada e será analisada em breve.";
            redirect("index.php");
        } else {
            $_SESSION['error'] = "Ocorreu um erro técnico ao processar sua solicitação.";
            redirect("index.php");
        }
    } else {
        $_SESSION['error'] = implode("<br>", $errors);
        redirect("index.php");
    }
}
redirect("index.php");
?>

