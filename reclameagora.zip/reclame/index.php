<?php
session_start();
require_once '../config.php';

$empresa = isset($_SESSION['empresa']) ? $_SESSION['empresa'] : '';
?>


<html lang="pt">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="generator" content="Hostinger Website Builder"><!--[-->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body.swal2-shown:not(.swal2-no-backdrop, .swal2-toast-shown) {
      overflow: hidden
    }

    body.swal2-height-auto {
      height: auto !important
    }

    body.swal2-no-backdrop .swal2-container {
      background-color: rgba(0, 0, 0, 0) !important;
      pointer-events: none
    }

    body.swal2-no-backdrop .swal2-container .swal2-popup {
      pointer-events: all
    }

    body.swal2-no-backdrop .swal2-container .swal2-modal {
      box-shadow: 0 0 10px rgba(0, 0, 0, .4)
    }

    body.swal2-toast-shown .swal2-container {
      box-sizing: border-box;
      width: 360px;
      max-width: 100%;
      background-color: rgba(0, 0, 0, 0);
      pointer-events: none
    }

    body.swal2-toast-shown .swal2-container.swal2-top {
      inset: 0 auto auto 50%;
      transform: translateX(-50%)
    }

    body.swal2-toast-shown .swal2-container.swal2-top-end,
    body.swal2-toast-shown .swal2-container.swal2-top-right {
      inset: 0 0 auto auto
    }

    body.swal2-toast-shown .swal2-container.swal2-top-start,
    body.swal2-toast-shown .swal2-container.swal2-top-left {
      inset: 0 auto auto 0
    }

    body.swal2-toast-shown .swal2-container.swal2-center-start,
    body.swal2-toast-shown .swal2-container.swal2-center-left {
      inset: 50% auto auto 0;
      transform: translateY(-50%)
    }

    body.swal2-toast-shown .swal2-container.swal2-center {
      inset: 50% auto auto 50%;
      transform: translate(-50%, -50%)
    }

    body.swal2-toast-shown .swal2-container.swal2-center-end,
    body.swal2-toast-shown .swal2-container.swal2-center-right {
      inset: 50% 0 auto auto;
      transform: translateY(-50%)
    }

    body.swal2-toast-shown .swal2-container.swal2-bottom-start,
    body.swal2-toast-shown .swal2-container.swal2-bottom-left {
      inset: auto auto 0 0
    }

    body.swal2-toast-shown .swal2-container.swal2-bottom {
      inset: auto auto 0 50%;
      transform: translateX(-50%)
    }

    body.swal2-toast-shown .swal2-container.swal2-bottom-end,
    body.swal2-toast-shown .swal2-container.swal2-bottom-right {
      inset: auto 0 0 auto
    }

    @media print {
      body.swal2-shown:not(.swal2-no-backdrop, .swal2-toast-shown) {
        overflow-y: scroll !important
      }

      body.swal2-shown:not(.swal2-no-backdrop, .swal2-toast-shown)>[aria-hidden=true] {
        display: none
      }

      body.swal2-shown:not(.swal2-no-backdrop, .swal2-toast-shown) .swal2-container {
        position: static !important
      }
    }

    div:where(.swal2-container) {
      display: grid;
      position: fixed;
      z-index: 1060;
      inset: 0;
      box-sizing: border-box;
      grid-template-areas: "top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";
      grid-template-rows: minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto);
      height: 100%;
      padding: .625em;
      overflow-x: hidden;
      transition: background-color .1s;
      -webkit-overflow-scrolling: touch
    }

    div:where(.swal2-container).swal2-backdrop-show,
    div:where(.swal2-container).swal2-noanimation {
      background: rgba(0, 0, 0, .4)
    }

    div:where(.swal2-container).swal2-backdrop-hide {
      background: rgba(0, 0, 0, 0) !important
    }

    div:where(.swal2-container).swal2-top-start,
    div:where(.swal2-container).swal2-center-start,
    div:where(.swal2-container).swal2-bottom-start {
      grid-template-columns: minmax(0, 1fr) auto auto
    }

    div:where(.swal2-container).swal2-top,
    div:where(.swal2-container).swal2-center,
    div:where(.swal2-container).swal2-bottom {
      grid-template-columns: auto minmax(0, 1fr) auto
    }

    div:where(.swal2-container).swal2-top-end,
    div:where(.swal2-container).swal2-center-end,
    div:where(.swal2-container).swal2-bottom-end {
      grid-template-columns: auto auto minmax(0, 1fr)
    }

    div:where(.swal2-container).swal2-top-start>.swal2-popup {
      align-self: start
    }

    div:where(.swal2-container).swal2-top>.swal2-popup {
      grid-column: 2;
      place-self: start center
    }

    div:where(.swal2-container).swal2-top-end>.swal2-popup,
    div:where(.swal2-container).swal2-top-right>.swal2-popup {
      grid-column: 3;
      place-self: start end
    }

    div:where(.swal2-container).swal2-center-start>.swal2-popup,
    div:where(.swal2-container).swal2-center-left>.swal2-popup {
      grid-row: 2;
      align-self: center
    }

    div:where(.swal2-container).swal2-center>.swal2-popup {
      grid-column: 2;
      grid-row: 2;
      place-self: center center
    }

    div:where(.swal2-container).swal2-center-end>.swal2-popup,
    div:where(.swal2-container).swal2-center-right>.swal2-popup {
      grid-column: 3;
      grid-row: 2;
      place-self: center end
    }

    div:where(.swal2-container).swal2-bottom-start>.swal2-popup,
    div:where(.swal2-container).swal2-bottom-left>.swal2-popup {
      grid-column: 1;
      grid-row: 3;
      align-self: end
    }

    div:where(.swal2-container).swal2-bottom>.swal2-popup {
      grid-column: 2;
      grid-row: 3;
      place-self: end center
    }

    div:where(.swal2-container).swal2-bottom-end>.swal2-popup,
    div:where(.swal2-container).swal2-bottom-right>.swal2-popup {
      grid-column: 3;
      grid-row: 3;
      place-self: end end
    }

    div:where(.swal2-container).swal2-grow-row>.swal2-popup,
    div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup {
      grid-column: 1/4;
      width: 100%
    }

    div:where(.swal2-container).swal2-grow-column>.swal2-popup,
    div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup {
      grid-row: 1/4;
      align-self: stretch
    }

    div:where(.swal2-container).swal2-no-transition {
      transition: none !important
    }

    div:where(.swal2-container) div:where(.swal2-popup) {
      display: none;
      position: relative;
      box-sizing: border-box;
      grid-template-columns: minmax(0, 100%);
      width: 32em;
      max-width: 100%;
      padding: 0 0 1.25em;
      border: none;
      border-radius: 5px;
      background: #fff;
      color: #545454;
      font-family: inherit;
      font-size: 1rem
    }

    div:where(.swal2-container) div:where(.swal2-popup):focus {
      outline: none
    }

    div:where(.swal2-container) div:where(.swal2-popup).swal2-loading {
      overflow-y: hidden
    }

    div:where(.swal2-container) div:where(.swal2-popup).swal2-draggable {
      cursor: grab
    }

    div:where(.swal2-container) div:where(.swal2-popup).swal2-draggable div:where(.swal2-icon) {
      cursor: grab
    }

    div:where(.swal2-container) div:where(.swal2-popup).swal2-dragging {
      cursor: grabbing
    }

    div:where(.swal2-container) div:where(.swal2-popup).swal2-dragging div:where(.swal2-icon) {
      cursor: grabbing
    }

    div:where(.swal2-container) h2:where(.swal2-title) {
      position: relative;
      max-width: 100%;
      margin: 0;
      padding: .8em 1em 0;
      color: inherit;
      font-size: 1.875em;
      font-weight: 600;
      text-align: center;
      text-transform: none;
      word-wrap: break-word;
      cursor: initial
    }

    div:where(.swal2-container) div:where(.swal2-actions) {
      display: flex;
      z-index: 1;
      box-sizing: border-box;
      flex-wrap: wrap;
      align-items: center;
      justify-content: center;
      width: auto;
      margin: 1.25em auto 0;
      padding: 0
    }

    div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled[disabled] {
      opacity: .4
    }

    div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:hover {
      background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1))
    }

    div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:active {
      background-image: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2))
    }

    div:where(.swal2-container) div:where(.swal2-loader) {
      display: none;
      align-items: center;
      justify-content: center;
      width: 2.2em;
      height: 2.2em;
      margin: 0 1.875em;
      animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
      border-width: .25em;
      border-style: solid;
      border-radius: 100%;
      border-color: #2778c4 rgba(0, 0, 0, 0) #2778c4 rgba(0, 0, 0, 0)
    }

    div:where(.swal2-container) button:where(.swal2-styled) {
      margin: .3125em;
      padding: .625em 1.1em;
      transition: box-shadow .1s;
      box-shadow: 0 0 0 3px rgba(0, 0, 0, 0);
      font-weight: 500
    }

    div:where(.swal2-container) button:where(.swal2-styled):not([disabled]) {
      cursor: pointer
    }

    div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm) {
      border: 0;
      border-radius: .25em;
      background: initial;
      background-color: #7066e0;
      color: #fff;
      font-size: 1em
    }

    div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm):focus-visible {
      box-shadow: 0 0 0 3px rgba(112, 102, 224, .5)
    }

    div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny) {
      border: 0;
      border-radius: .25em;
      background: initial;
      background-color: #dc3741;
      color: #fff;
      font-size: 1em
    }

    div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny):focus-visible {
      box-shadow: 0 0 0 3px rgba(220, 55, 65, .5)
    }

    div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel) {
      border: 0;
      border-radius: .25em;
      background: initial;
      background-color: #6e7881;
      color: #fff;
      font-size: 1em
    }

    div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel):focus-visible {
      box-shadow: 0 0 0 3px rgba(110, 120, 129, .5)
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-default-outline:focus-visible {
      box-shadow: 0 0 0 3px rgba(100, 150, 200, .5)
    }

    div:where(.swal2-container) button:where(.swal2-styled):focus-visible {
      outline: none
    }

    div:where(.swal2-container) button:where(.swal2-styled)::-moz-focus-inner {
      border: 0
    }

    div:where(.swal2-container) div:where(.swal2-footer) {
      margin: 1em 0 0;
      padding: 1em 1em 0;
      border-top: 1px solid #eee;
      color: inherit;
      font-size: 1em;
      text-align: center;
      cursor: initial
    }

    div:where(.swal2-container) .swal2-timer-progress-bar-container {
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      grid-column: auto !important;
      overflow: hidden;
      border-bottom-right-radius: 5px;
      border-bottom-left-radius: 5px
    }

    div:where(.swal2-container) div:where(.swal2-timer-progress-bar) {
      width: 100%;
      height: .25em;
      background: rgba(0, 0, 0, .2)
    }

    div:where(.swal2-container) img:where(.swal2-image) {
      max-width: 100%;
      margin: 2em auto 1em;
      cursor: initial
    }

    div:where(.swal2-container) button:where(.swal2-close) {
      z-index: 2;
      align-items: center;
      justify-content: center;
      width: 1.2em;
      height: 1.2em;
      margin-top: 0;
      margin-right: 0;
      margin-bottom: -1.2em;
      padding: 0;
      overflow: hidden;
      transition: color .1s, box-shadow .1s;
      border: none;
      border-radius: 5px;
      background: rgba(0, 0, 0, 0);
      color: #ccc;
      font-family: monospace;
      font-size: 2.5em;
      cursor: pointer;
      justify-self: end
    }

    div:where(.swal2-container) button:where(.swal2-close):hover {
      transform: none;
      background: rgba(0, 0, 0, 0);
      color: #f27474
    }

    div:where(.swal2-container) button:where(.swal2-close):focus-visible {
      outline: none;
      box-shadow: inset 0 0 0 3px rgba(100, 150, 200, .5)
    }

    div:where(.swal2-container) button:where(.swal2-close)::-moz-focus-inner {
      border: 0
    }

    div:where(.swal2-container) div:where(.swal2-html-container) {
      z-index: 1;
      justify-content: center;
      margin: 0;
      padding: 1em 1.6em .3em;
      overflow: auto;
      color: inherit;
      font-size: 1.125em;
      font-weight: normal;
      line-height: normal;
      text-align: center;
      word-wrap: break-word;
      word-break: break-word;
      cursor: initial
    }

    div:where(.swal2-container) input:where(.swal2-input),
    div:where(.swal2-container) input:where(.swal2-file),
    div:where(.swal2-container) textarea:where(.swal2-textarea),
    div:where(.swal2-container) select:where(.swal2-select),
    div:where(.swal2-container) div:where(.swal2-radio),
    div:where(.swal2-container) label:where(.swal2-checkbox) {
      margin: 1em 2em 3px
    }

    div:where(.swal2-container) input:where(.swal2-input),
    div:where(.swal2-container) input:where(.swal2-file),
    div:where(.swal2-container) textarea:where(.swal2-textarea) {
      box-sizing: border-box;
      width: auto;
      transition: border-color .1s, box-shadow .1s;
      border: 1px solid #d9d9d9;
      border-radius: .1875em;
      background: rgba(0, 0, 0, 0);
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, .06), 0 0 0 3px rgba(0, 0, 0, 0);
      color: inherit;
      font-size: 1.125em
    }

    div:where(.swal2-container) input:where(.swal2-input).swal2-inputerror,
    div:where(.swal2-container) input:where(.swal2-file).swal2-inputerror,
    div:where(.swal2-container) textarea:where(.swal2-textarea).swal2-inputerror {
      border-color: #f27474 !important;
      box-shadow: 0 0 2px #f27474 !important
    }

    div:where(.swal2-container) input:where(.swal2-input):focus,
    div:where(.swal2-container) input:where(.swal2-file):focus,
    div:where(.swal2-container) textarea:where(.swal2-textarea):focus {
      border: 1px solid #b4dbed;
      outline: none;
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, .06), 0 0 0 3px rgba(100, 150, 200, .5)
    }

    div:where(.swal2-container) input:where(.swal2-input)::placeholder,
    div:where(.swal2-container) input:where(.swal2-file)::placeholder,
    div:where(.swal2-container) textarea:where(.swal2-textarea)::placeholder {
      color: #ccc
    }

    div:where(.swal2-container) .swal2-range {
      margin: 1em 2em 3px;
      background: #fff
    }

    div:where(.swal2-container) .swal2-range input {
      width: 80%
    }

    div:where(.swal2-container) .swal2-range output {
      width: 20%;
      color: inherit;
      font-weight: 600;
      text-align: center
    }

    div:where(.swal2-container) .swal2-range input,
    div:where(.swal2-container) .swal2-range output {
      height: 2.625em;
      padding: 0;
      font-size: 1.125em;
      line-height: 2.625em
    }

    div:where(.swal2-container) .swal2-input {
      height: 2.625em;
      padding: 0 .75em
    }

    div:where(.swal2-container) .swal2-file {
      width: 75%;
      margin-right: auto;
      margin-left: auto;
      background: rgba(0, 0, 0, 0);
      font-size: 1.125em
    }

    div:where(.swal2-container) .swal2-textarea {
      height: 6.75em;
      padding: .75em
    }

    div:where(.swal2-container) .swal2-select {
      min-width: 50%;
      max-width: 100%;
      padding: .375em .625em;
      background: rgba(0, 0, 0, 0);
      color: inherit;
      font-size: 1.125em
    }

    div:where(.swal2-container) .swal2-radio,
    div:where(.swal2-container) .swal2-checkbox {
      align-items: center;
      justify-content: center;
      background: #fff;
      color: inherit
    }

    div:where(.swal2-container) .swal2-radio label,
    div:where(.swal2-container) .swal2-checkbox label {
      margin: 0 .6em;
      font-size: 1.125em
    }

    div:where(.swal2-container) .swal2-radio input,
    div:where(.swal2-container) .swal2-checkbox input {
      flex-shrink: 0;
      margin: 0 .4em
    }

    div:where(.swal2-container) label:where(.swal2-input-label) {
      display: flex;
      justify-content: center;
      margin: 1em auto 0
    }

    div:where(.swal2-container) div:where(.swal2-validation-message) {
      align-items: center;
      justify-content: center;
      margin: 1em 0 0;
      padding: .625em;
      overflow: hidden;
      background: #f0f0f0;
      color: #666;
      font-size: 1em;
      font-weight: 300
    }

    div:where(.swal2-container) div:where(.swal2-validation-message)::before {
      content: "!";
      display: inline-block;
      width: 1.5em;
      min-width: 1.5em;
      height: 1.5em;
      margin: 0 .625em;
      border-radius: 50%;
      background-color: #f27474;
      color: #fff;
      font-weight: 600;
      line-height: 1.5em;
      text-align: center
    }

    div:where(.swal2-container) .swal2-progress-steps {
      flex-wrap: wrap;
      align-items: center;
      max-width: 100%;
      margin: 1.25em auto;
      padding: 0;
      background: rgba(0, 0, 0, 0);
      font-weight: 600
    }

    div:where(.swal2-container) .swal2-progress-steps li {
      display: inline-block;
      position: relative
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step {
      z-index: 20;
      flex-shrink: 0;
      width: 2em;
      height: 2em;
      border-radius: 2em;
      background: #2778c4;
      color: #fff;
      line-height: 2em;
      text-align: center
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step {
      background: #2778c4
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step {
      background: #add8e6;
      color: #fff
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line {
      background: #add8e6
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step-line {
      z-index: 10;
      flex-shrink: 0;
      width: 2.5em;
      height: .4em;
      margin: 0 -1px;
      background: #2778c4
    }

    div:where(.swal2-icon) {
      position: relative;
      box-sizing: content-box;
      justify-content: center;
      width: 5em;
      height: 5em;
      margin: 2.5em auto .6em;
      border: .25em solid rgba(0, 0, 0, 0);
      border-radius: 50%;
      border-color: #000;
      font-family: inherit;
      line-height: 5em;
      cursor: default;
      user-select: none
    }

    div:where(.swal2-icon) .swal2-icon-content {
      display: flex;
      align-items: center;
      font-size: 3.75em
    }

    div:where(.swal2-icon).swal2-error {
      border-color: #f27474;
      color: #f27474
    }

    div:where(.swal2-icon).swal2-error .swal2-x-mark {
      position: relative;
      flex-grow: 1
    }

    div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line] {
      display: block;
      position: absolute;
      top: 2.3125em;
      width: 2.9375em;
      height: .3125em;
      border-radius: .125em;
      background-color: #f27474
    }

    div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=left] {
      left: 1.0625em;
      transform: rotate(45deg)
    }

    div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=right] {
      right: 1em;
      transform: rotate(-45deg)
    }

    div:where(.swal2-icon).swal2-error.swal2-icon-show {
      animation: swal2-animate-error-icon .5s
    }

    div:where(.swal2-icon).swal2-error.swal2-icon-show .swal2-x-mark {
      animation: swal2-animate-error-x-mark .5s
    }

    div:where(.swal2-icon).swal2-warning {
      border-color: #f8bb86;
      color: #f8bb86
    }

    div:where(.swal2-icon).swal2-warning.swal2-icon-show {
      animation: swal2-animate-error-icon .5s
    }

    div:where(.swal2-icon).swal2-warning.swal2-icon-show .swal2-icon-content {
      animation: swal2-animate-i-mark .5s
    }

    div:where(.swal2-icon).swal2-info {
      border-color: #3fc3ee;
      color: #3fc3ee
    }

    div:where(.swal2-icon).swal2-info.swal2-icon-show {
      animation: swal2-animate-error-icon .5s
    }

    div:where(.swal2-icon).swal2-info.swal2-icon-show .swal2-icon-content {
      animation: swal2-animate-i-mark .8s
    }

    div:where(.swal2-icon).swal2-question {
      border-color: #87adbd;
      color: #87adbd
    }

    div:where(.swal2-icon).swal2-question.swal2-icon-show {
      animation: swal2-animate-error-icon .5s
    }

    div:where(.swal2-icon).swal2-question.swal2-icon-show .swal2-icon-content {
      animation: swal2-animate-question-mark .8s
    }

    div:where(.swal2-icon).swal2-success {
      border-color: #a5dc86;
      color: #a5dc86
    }

    div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line] {
      position: absolute;
      width: 3.75em;
      height: 7.5em;
      border-radius: 50%
    }

    div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=left] {
      top: -0.4375em;
      left: -2.0635em;
      transform: rotate(-45deg);
      transform-origin: 3.75em 3.75em;
      border-radius: 7.5em 0 0 7.5em
    }

    div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=right] {
      top: -0.6875em;
      left: 1.875em;
      transform: rotate(-45deg);
      transform-origin: 0 3.75em;
      border-radius: 0 7.5em 7.5em 0
    }

    div:where(.swal2-icon).swal2-success .swal2-success-ring {
      position: absolute;
      z-index: 2;
      top: -0.25em;
      left: -0.25em;
      box-sizing: content-box;
      width: 100%;
      height: 100%;
      border: .25em solid rgba(165, 220, 134, .3);
      border-radius: 50%
    }

    div:where(.swal2-icon).swal2-success .swal2-success-fix {
      position: absolute;
      z-index: 1;
      top: .5em;
      left: 1.625em;
      width: .4375em;
      height: 5.625em;
      transform: rotate(-45deg)
    }

    div:where(.swal2-icon).swal2-success [class^=swal2-success-line] {
      display: block;
      position: absolute;
      z-index: 2;
      height: .3125em;
      border-radius: .125em;
      background-color: #a5dc86
    }

    div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=tip] {
      top: 2.875em;
      left: .8125em;
      width: 1.5625em;
      transform: rotate(45deg)
    }

    div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=long] {
      top: 2.375em;
      right: .5em;
      width: 2.9375em;
      transform: rotate(-45deg)
    }

    div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-tip {
      animation: swal2-animate-success-line-tip .75s
    }

    div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-long {
      animation: swal2-animate-success-line-long .75s
    }

    div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-circular-line-right {
      animation: swal2-rotate-success-circular-line 4.25s ease-in
    }

    [class^=swal2] {
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0)
    }

    .swal2-show {
      animation: swal2-show .3s
    }

    .swal2-hide {
      animation: swal2-hide .15s forwards
    }

    .swal2-noanimation {
      transition: none
    }

    .swal2-scrollbar-measure {
      position: absolute;
      top: -9999px;
      width: 50px;
      height: 50px;
      overflow: scroll
    }

    .swal2-rtl .swal2-close {
      margin-right: initial;
      margin-left: 0
    }

    .swal2-rtl .swal2-timer-progress-bar {
      right: 0;
      left: auto
    }

    .swal2-toast {
      box-sizing: border-box;
      grid-column: 1/4 !important;
      grid-row: 1/4 !important;
      grid-template-columns: min-content auto min-content;
      padding: 1em;
      overflow-y: hidden;
      background: #fff;
      box-shadow: 0 0 1px rgba(0, 0, 0, .075), 0 1px 2px rgba(0, 0, 0, .075), 1px 2px 4px rgba(0, 0, 0, .075), 1px 3px 8px rgba(0, 0, 0, .075), 2px 4px 16px rgba(0, 0, 0, .075);
      pointer-events: all
    }

    .swal2-toast>* {
      grid-column: 2
    }

    .swal2-toast h2:where(.swal2-title) {
      margin: .5em 1em;
      padding: 0;
      font-size: 1em;
      text-align: initial
    }

    .swal2-toast .swal2-loading {
      justify-content: center
    }

    .swal2-toast input:where(.swal2-input) {
      height: 2em;
      margin: .5em;
      font-size: 1em
    }

    .swal2-toast .swal2-validation-message {
      font-size: 1em
    }

    .swal2-toast div:where(.swal2-footer) {
      margin: .5em 0 0;
      padding: .5em 0 0;
      font-size: .8em
    }

    .swal2-toast button:where(.swal2-close) {
      grid-column: 3/3;
      grid-row: 1/99;
      align-self: center;
      width: .8em;
      height: .8em;
      margin: 0;
      font-size: 2em
    }

    .swal2-toast div:where(.swal2-html-container) {
      margin: .5em 1em;
      padding: 0;
      overflow: initial;
      font-size: 1em;
      text-align: initial
    }

    .swal2-toast div:where(.swal2-html-container):empty {
      padding: 0
    }

    .swal2-toast .swal2-loader {
      grid-column: 1;
      grid-row: 1/99;
      align-self: center;
      width: 2em;
      height: 2em;
      margin: .25em
    }

    .swal2-toast .swal2-icon {
      grid-column: 1;
      grid-row: 1/99;
      align-self: center;
      width: 2em;
      min-width: 2em;
      height: 2em;
      margin: 0 .5em 0 0
    }

    .swal2-toast .swal2-icon .swal2-icon-content {
      display: flex;
      align-items: center;
      font-size: 1.8em;
      font-weight: bold
    }

    .swal2-toast .swal2-icon.swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em
    }

    .swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line] {
      top: .875em;
      width: 1.375em
    }

    .swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left] {
      left: .3125em
    }

    .swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right] {
      right: .3125em
    }

    .swal2-toast div:where(.swal2-actions) {
      justify-content: flex-start;
      height: auto;
      margin: 0;
      margin-top: .5em;
      padding: 0 .5em
    }

    .swal2-toast button:where(.swal2-styled) {
      margin: .25em .5em;
      padding: .4em .6em;
      font-size: 1em
    }

    .swal2-toast .swal2-success {
      border-color: #a5dc86
    }

    .swal2-toast .swal2-success [class^=swal2-success-circular-line] {
      position: absolute;
      width: 1.6em;
      height: 3em;
      border-radius: 50%
    }

    .swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left] {
      top: -0.8em;
      left: -0.5em;
      transform: rotate(-45deg);
      transform-origin: 2em 2em;
      border-radius: 4em 0 0 4em
    }

    .swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right] {
      top: -0.25em;
      left: .9375em;
      transform-origin: 0 1.5em;
      border-radius: 0 4em 4em 0
    }

    .swal2-toast .swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em
    }

    .swal2-toast .swal2-success .swal2-success-fix {
      top: 0;
      left: .4375em;
      width: .4375em;
      height: 2.6875em
    }

    .swal2-toast .swal2-success [class^=swal2-success-line] {
      height: .3125em
    }

    .swal2-toast .swal2-success [class^=swal2-success-line][class$=tip] {
      top: 1.125em;
      left: .1875em;
      width: .75em
    }

    .swal2-toast .swal2-success [class^=swal2-success-line][class$=long] {
      top: .9375em;
      right: .1875em;
      width: 1.375em
    }

    .swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip {
      animation: swal2-toast-animate-success-line-tip .75s
    }

    .swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long {
      animation: swal2-toast-animate-success-line-long .75s
    }

    .swal2-toast.swal2-show {
      animation: swal2-toast-show .5s
    }

    .swal2-toast.swal2-hide {
      animation: swal2-toast-hide .1s forwards
    }

    @keyframes swal2-show {
      0% {
        transform: scale(0.7)
      }

      45% {
        transform: scale(1.05)
      }

      80% {
        transform: scale(0.95)
      }

      100% {
        transform: scale(1)
      }
    }

    @keyframes swal2-hide {
      0% {
        transform: scale(1);
        opacity: 1
      }

      100% {
        transform: scale(0.5);
        opacity: 0
      }
    }

    @keyframes swal2-animate-success-line-tip {
      0% {
        top: 1.1875em;
        left: .0625em;
        width: 0
      }

      54% {
        top: 1.0625em;
        left: .125em;
        width: 0
      }

      70% {
        top: 2.1875em;
        left: -0.375em;
        width: 3.125em
      }

      84% {
        top: 3em;
        left: 1.3125em;
        width: 1.0625em
      }

      100% {
        top: 2.8125em;
        left: .8125em;
        width: 1.5625em
      }
    }

    @keyframes swal2-animate-success-line-long {
      0% {
        top: 3.375em;
        right: 2.875em;
        width: 0
      }

      65% {
        top: 3.375em;
        right: 2.875em;
        width: 0
      }

      84% {
        top: 2.1875em;
        right: 0;
        width: 3.4375em
      }

      100% {
        top: 2.375em;
        right: .5em;
        width: 2.9375em
      }
    }

    @keyframes swal2-rotate-success-circular-line {
      0% {
        transform: rotate(-45deg)
      }

      5% {
        transform: rotate(-45deg)
      }

      12% {
        transform: rotate(-405deg)
      }

      100% {
        transform: rotate(-405deg)
      }
    }

    @keyframes swal2-animate-error-x-mark {
      0% {
        margin-top: 1.625em;
        transform: scale(0.4);
        opacity: 0
      }

      50% {
        margin-top: 1.625em;
        transform: scale(0.4);
        opacity: 0
      }

      80% {
        margin-top: -0.375em;
        transform: scale(1.15)
      }

      100% {
        margin-top: 0;
        transform: scale(1);
        opacity: 1
      }
    }

    @keyframes swal2-animate-error-icon {
      0% {
        transform: rotateX(100deg);
        opacity: 0
      }

      100% {
        transform: rotateX(0deg);
        opacity: 1
      }
    }

    @keyframes swal2-rotate-loading {
      0% {
        transform: rotate(0deg)
      }

      100% {
        transform: rotate(360deg)
      }
    }

    @keyframes swal2-animate-question-mark {
      0% {
        transform: rotateY(-360deg)
      }

      100% {
        transform: rotateY(0)
      }
    }

    @keyframes swal2-animate-i-mark {
      0% {
        transform: rotateZ(45deg);
        opacity: 0
      }

      25% {
        transform: rotateZ(-25deg);
        opacity: .4
      }

      50% {
        transform: rotateZ(15deg);
        opacity: .8
      }

      75% {
        transform: rotateZ(-5deg);
        opacity: 1
      }

      100% {
        transform: rotateX(0);
        opacity: 1
      }
    }

    @keyframes swal2-toast-show {
      0% {
        transform: translateY(-0.625em) rotateZ(2deg)
      }

      33% {
        transform: translateY(0) rotateZ(-2deg)
      }

      66% {
        transform: translateY(0.3125em) rotateZ(2deg)
      }

      100% {
        transform: translateY(0) rotateZ(0deg)
      }
    }

    @keyframes swal2-toast-hide {
      100% {
        transform: rotateZ(1deg);
        opacity: 0
      }
    }

    @keyframes swal2-toast-animate-success-line-tip {
      0% {
        top: .5625em;
        left: .0625em;
        width: 0
      }

      54% {
        top: .125em;
        left: .125em;
        width: 0
      }

      70% {
        top: .625em;
        left: -0.25em;
        width: 1.625em
      }

      84% {
        top: 1.0625em;
        left: .75em;
        width: .5em
      }

      100% {
        top: 1.125em;
        left: .1875em;
        width: .75em
      }
    }

    @keyframes swal2-toast-animate-success-line-long {
      0% {
        top: 1.625em;
        right: 1.375em;
        width: 0
      }

      65% {
        top: 1.25em;
        right: .9375em;
        width: 0
      }

      84% {
        top: .9375em;
        right: 0;
        width: 1.125em
      }

      100% {
        top: .9375em;
        right: .1875em;
        width: 1.375em
      }
    }

    /* Form Styles Enhanced */
    .form {
      display: flex;
      flex-direction: column;
      gap: 20px;
      padding: 40px;
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 15px 35px rgba(0,0,0,0.08);
      max-width: 600px;
      margin: 0 auto;
      border: 1px solid #e1e4e8;
    }

    .form__control {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .input {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .input__label {
      font-size: 14px;
      color: #1a1a1a;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .input__component {
      width: 100%;
      padding: 14px 18px;
      font-size: 16px;
      color: #333;
      background-color: #f9f9f9;
      border: 1px solid #ddd;
      border-radius: 8px;
      transition: all 0.2s ease;
      box-sizing: border-box;
    }

    .input__component:focus {
      outline: none;
      background-color: #fff;
      border-color: #02793e;
      box-shadow: 0 0 0 4px rgba(2, 121, 62, 0.1);
    }

    .input__component--textarea {
      min-height: 150px;
      line-height: 1.6;
    }

    .input__options {
      display: flex;
      gap: 20px;
      margin-top: 10px;
      background: #f0f4f8;
      padding: 10px 15px;
      border-radius: 6px;
    }

    .select-input {
      display: flex;
      align-items: center;
      gap: 10px;
      cursor: pointer;
      font-weight: 600;
      color: #4b5963;
    }

    .select-input__input {
      width: 20px;
      height: 20px;
      accent-color: #02793e;
    }

    .grid-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 16px 32px;
      font-size: 18px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 1px;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      border: none;
      border-radius: 50px;
      background: linear-gradient(135deg, #02793e 0%, #039e51 100%);
      color: #ffffff;
      box-shadow: 0 4px 15px rgba(2, 121, 62, 0.3);
      width: 100%;
      margin-top: 20px;
    }

    .grid-button:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 25px rgba(2, 121, 62, 0.4);
      filter: brightness(1.1);
    }

    .grid-button:active {
      transform: translateY(-1px);
    }

    .input__label--read-only {
      color: #666;
    }
  </style>
  <title>Reclame Aqui - Soluções para Reclamações de Consumidores | Reclame Sac</title>
  <meta name="description" content="Na Reclame Sac, recebemos e analisamos reclamações de consumidores. Nosso objetivo é resolver conflitos entre consumidores e empresas, garantindo que seus direitos sejam respeitados. Entre em contato e saiba como podemos ajudar na sua reclamação.">
  <link rel="icon" href="./assets/ra-favicon.bf3991c3-dOq8vrQ7R0TR76eR.png">
  <link rel="apple-touch-icon" href="./assets/ra-favicon.bf3991c3-dOq8vrQ7R0TR76eR.png">
  <meta content="Reclame Aqui - Soluções para Reclamações de Consumidores | Reclame Sac" property="og:title">
  <meta name="twitter:title" content="Reclame Aqui - Soluções para Reclamações de Consumidores | Reclame Sac">
  <meta content="website" property="og:type">
  <meta property="og:description" content="Na Reclame Sac, recebemos e analisamos reclamações de consumidores. Nosso objetivo é resolver conflitos entre consumidores e empresas, garantindo que seus direitos sejam respeitados. Entre em contato e saiba como podemos ajudar na sua reclamação.">
  <meta name="twitter:description" content="Na Reclame Sac, recebemos e analisamos reclamações de consumidores. Nosso objetivo é resolver conflitos entre consumidores e empresas, garantindo que seus direitos sejam respeitados. Entre em contato e saiba como podemos ajudar na sua reclamação.">
  <meta property="og:site_name" content="Reclame Sac">
  <meta name="keywords" content="reclamações, direitos do consumidor, solução de conflitos">
  <meta property="og:image">
  <meta name="twitter:image">
  <meta content="" property="og:image:alt">
  <meta content="" name="twitter:image:alt">
  <meta name="twitter:card" content="summary_large_image"><!---->
  <link rel="preconnect"><!----><!----><!----><!----><!--[-->
  <link href="./assets/font-faces" rel="preconnect" crossorigin="true">
  <link href="./assets/font-faces" rel="preload" as="style">
  <link href="./assets/font-faces" rel="stylesheet" referrerpolicy="no-referrer"><!--]-->
  <style></style>
  <script>
    (function() {
      const postDate = null;

      const currentDate = new Date().setHours(0, 0, 0, 0);
      const postPublishDate = new Date(postDate).setHours(0, 0, 0, 0);

      if (postPublishDate && currentDate < postPublishDate) {
        window.location.replace('/');
      }
    })();
  </script>
  <link rel="stylesheet" href="./_slug_.B_FmpUEB.css">
  <style>
    :root {
      --color-meteorite-dark: #2f1c6a;
      --color-meteorite-dark-2: #1F1346;
      --color-meteorite: #8c85ff;
      --color-meteorite-light: #d5dfff;
      --color-primary-dark: #5025d1;
      --color-primary: #673de6;
      --color-primary-light: #ebe4ff;
      --color-primary-charts: #B39EF3;
      --color-danger-dark: #d63163;
      --color-danger: #fc5185;
      --color-danger-light: #ffe8ef;
      --color-danger-charts: #FEA8C2;
      --color-warning-dark: #fea419;
      --color-warning-dark-2: #9F6000;
      --color-warning-charts: #FFD28C;
      --color-warning: #ffcd35;
      --color-warning-light: #fff8e2;
      --color-success-dark: #008361;
      --color-success: #00b090;
      --color-success-light: #def4f0;
      --color-dark: #1d1e20;
      --color-gray-dark: #36344d;
      --color-gray: #727586;
      --color-gray-border: #dadce0;
      --color-gray-light: #f2f3f6;
      --color-light: #fff;
      --color-azure: #357df9;
      --color-azure-light: #e3ebf9;
      --color-azure-dark: #265ab2;
      --color-indigo: #6366F1
    }

    .whats-app-bubble {
      position: fixed;
      right: 20px;
      bottom: 24px;
      z-index: 1000;
      display: flex;
      cursor: pointer;
      border-radius: 100px;
      box-shadow: #00000026 0 4px 12px
    }

    #wtpQualitySign_fixedCSS,
    #wtpQualitySign_popupCSS {
      bottom: 10px !important
    }

    #wtpQualitySign_fixedCSS {
      z-index: 17 !important
    }

    #wtpQualitySign_popupCSS {
      z-index: 18 !important
    }
  </style>
  <meta name="generator" content="Hostinger Website builder">
</head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-17024935081"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-17024935081');
</script>
<body>
  <div>
    <style>
      astro-island,
      astro-slot,
      astro-static-slot {
        display: contents
      }
    </style>
    <script>
      (() => {
        var e = async t => {
          await (await t())()
        };
        (self.Astro || (self.Astro = {})).only = e;
        window.dispatchEvent(new Event("astro:only"));
      })();;
      (() => {
        var A = Object.defineProperty;
        var g = (i, o, a) => o in i ? A(i, o, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: a
        }) : i[o] = a;
        var d = (i, o, a) => g(i, typeof o != "symbol" ? o + "" : o, a);
        {
          let i = {
              0: t => m(t),
              1: t => a(t),
              2: t => new RegExp(t),
              3: t => new Date(t),
              4: t => new Map(a(t)),
              5: t => new Set(a(t)),
              6: t => BigInt(t),
              7: t => new URL(t),
              8: t => new Uint8Array(t),
              9: t => new Uint16Array(t),
              10: t => new Uint32Array(t),
              11: t => 1 / 0 * t
            },
            o = t => {
              let [l, e] = t;
              return l in i ? i[l](e) : void 0
            },
            a = t => t.map(o),
            m = t => typeof t != "object" || t === null ? t : Object.fromEntries(Object.entries(t).map(([l, e]) => [l, o(e)]));
          class y extends HTMLElement {
            constructor() {
              super(...arguments);
              d(this, "Component");
              d(this, "hydrator");
              d(this, "hydrate", async () => {
                var b;
                if (!this.hydrator || !this.isConnected) return;
                let e = (b = this.parentElement) == null ? void 0 : b.closest("astro-island[ssr]");
                if (e) {
                  e.addEventListener("astro:hydrate", this.hydrate, {
                    once: !0
                  });
                  return
                }
                let c = this.querySelectorAll("astro-slot"),
                  n = {},
                  h = this.querySelectorAll("template[data-astro-template]");
                for (let r of h) {
                  let s = r.closest(this.tagName);
                  s != null && s.isSameNode(this) && (n[r.getAttribute("data-astro-template") || "default"] = r.innerHTML, r.remove())
                }
                for (let r of c) {
                  let s = r.closest(this.tagName);
                  s != null && s.isSameNode(this) && (n[r.getAttribute("name") || "default"] = r.innerHTML)
                }
                let p;
                try {
                  p = this.hasAttribute("props") ? m(JSON.parse(this.getAttribute("props"))) : {}
                } catch (r) {
                  let s = this.getAttribute("component-url") || "<unknown>",
                    v = this.getAttribute("component-export");
                  throw v && (s += ` (export ${v})`), console.error(`[hydrate] Error parsing props for component ${s}`, this.getAttribute("props"), r), r
                }
                let u;
                await this.hydrator(this)(this.Component, p, n, {
                  client: this.getAttribute("client")
                }), this.removeAttribute("ssr"), this.dispatchEvent(new CustomEvent("astro:hydrate"))
              });
              d(this, "unmount", () => {
                this.isConnected || this.dispatchEvent(new CustomEvent("astro:unmount"))
              })
            }
            disconnectedCallback() {
              document.removeEventListener("astro:after-swap", this.unmount), document.addEventListener("astro:after-swap", this.unmount, {
                once: !0
              })
            }
            connectedCallback() {
              if (!this.hasAttribute("await-children") || document.readyState === "interactive" || document.readyState === "complete") this.childrenConnectedCallback();
              else {
                let e = () => {
                    document.removeEventListener("DOMContentLoaded", e), c.disconnect(), this.childrenConnectedCallback()
                  },
                  c = new MutationObserver(() => {
                    var n;
                    ((n = this.lastChild) == null ? void 0 : n.nodeType) === Node.COMMENT_NODE && this.lastChild.nodeValue === "astro:end" && (this.lastChild.remove(), e())
                  });
                c.observe(this, {
                  childList: !0
                }), document.addEventListener("DOMContentLoaded", e)
              }
            }
            async childrenConnectedCallback() {
              let e = this.getAttribute("before-hydration-url");
              e && await import(e), this.start()
            }
            async start() {
              let e = JSON.parse(this.getAttribute("opts")),
                c = this.getAttribute("client");
              if (Astro[c] === void 0) {
                window.addEventListener(`astro:${c}`, () => this.start(), {
                  once: !0
                });
                return
              }
              try {
                await Astro[c](async () => {
                  let n = this.getAttribute("renderer-url"),
                    [h, {
                      default: p
                    }] = await Promise.all([import(this.getAttribute("component-url")), n ? import(n) : () => () => {}]),
                    u = this.getAttribute("component-export") || "default";
                  if (!u.includes(".")) this.Component = h[u];
                  else {
                    this.Component = h;
                    for (let f of u.split(".")) this.Component = this.Component[f]
                  }
                  return this.hydrator = p, this.hydrate
                }, e, this)
              } catch (n) {
                console.error(`[astro-island] Error hydrating ${this.getAttribute("component-url")}`, n)
              }
            }
            attributeChangedCallback() {
              this.hydrate()
            }
          }
          d(y, "observedAttributes", ["props"]), customElements.get("astro-island") || customElements.define("astro-island", y)
        }
      })();
    </script><astro-island uid="KaIeY" component-url="./assets/ClientHead.BBgjaIiW.js" component-export="default" renderer-url="./assets/client.BtZKng67.js" props="{'page-noindex':[0,false],'canonical-url':[0,'#'],'site-meta':[0,{'version':[0,180],'isLayout':[0,true],'template':[0,'aigenerated'],'metaTitle':[0,'Reclame Sac'],'faviconPath':[0,'ra-favicon.bf3991c3-dOq8vrQ7R0TR76eR.png'],'aiWebsiteType':[0,'Business'],'defaultLocale':[0,'system'],'faviconOrigin':[0,'assets'],'isPrivateModeActive':[0,false],'demoEcommerceStoreId':[0,'demo_01G0E9P2R0CFTNBWEEFCEV8EG5'],'shouldAddWWWPrefixToDomain':[0,false]}],'domain':[0,'reclameatendimento.com']}" client="only" opts="{'name':'ClientHead','value':'vue'}" data-v-app="">
      <div></div>
    </astro-island>
    <script>
      (() => {
        var e = async t => {
          await (await t())()
        };
        (self.Astro || (self.Astro = {})).load = e;
        window.dispatchEvent(new Event("astro:load"));
      })();
    </script>
    <astro-island uid="Z1RTOf3" component-url="./assets/Page.DcNVC96T.js" component-export="default" renderer-url="./assets/client.BtZKng67.js" props="{'pageData':[0,{'pages':[0,{'zKf4dd':[0,{'date':[0,'2024-05-08T07:01:25.381Z'],'meta':[0,{'title':[0,'Como o Reclame Aqui ajuda consumidores a resolver problemas com empresas'],'ogImageAlt':[0,''],'description':[0,'No Reclame Aqui, recebemos reclamações de consumidores insatisfeitos. Analisamos cada caso e buscamos soluções adequadas, garantindo que os direitos do consumidor sejam respeitados. Nossa missão é facilitar a comunicação entre consumidores e empresas, promovendo um ambiente de negócios mais justo e transparente.'],'ogImagePath':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.40_1ed04360-AVL18WlzZpfVK5LQ.jpg'],'ogImageOrigin':[0,'assets']}],'name':[0,'Como o Reclame Aqui ajuda consumidores a resolver problemas com empresas'],'slug':[0,'como-o-reclame-aqui-ajuda-consumidores-a-resolver-problemas-com-empresas'],'type':[0,'blog'],'blocks':[1,[[0,'ai-LV9IqL'],[0,'ai-TPXLoz']]],'isDraft':[0,false],'categories':[1,[]],'coverImageAlt':[0,''],'minutesToRead':[0,'1'],'coverImagePath':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.40_1ed04360-AVL18WlzZpfVK5LQ.jpg'],'coverImageOrigin':[0,'assets']}],'zytf-T':[0,{'date':[0,'2024-05-08T07:01:25.377Z'],'meta':[0,{'title':[0,'Resolva suas reclamações com a ajuda do Reclame Aqui.'],'ogImageAlt':[0,''],'description':[0,'No Reclame Aqui, atendemos às reclamações dos consumidores insatisfeitos com empresas. Analisamos os casos e ajudamos a encontrar soluções justas, respeitando o direito do consumidor. Entre em contato através do nosso formulário e faça valer seus direitos com a nossa assistência especializada.'],'ogImagePath':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.31_904c8b87-YyvZxEwPOyuRnNOk.jpg'],'ogImageOrigin':[0,'assets']}],'name':[0,'Resolva suas reclamações com a ajuda do Reclame Aqui.'],'slug':[0,'resolva-suas-reclamaes-com-a-ajuda-do-reclame-aqui'],'type':[0,'blog'],'blocks':[1,[[0,'ai-1KZ4bg'],[0,'ai-98OeaA']]],'isDraft':[0,false],'categories':[1,[]],'coverImageAlt':[0,''],'minutesToRead':[0,'1'],'coverImagePath':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.31_904c8b87-YyvZxEwPOyuRnNOk.jpg'],'coverImageOrigin':[0,'assets']}],'ai-UdQm6':[0,{'meta':[0,{'title':[0,'Reclamações - Resolva seus problemas com empresas'],'noindex':[0,false],'keywords':[1,[[0,'reclamações'],[0,'direitos do consumidor'],[0,'solução de conflitos']]],'password':[0,''],'ogImageAlt':[0,''],'description':[0,'No Reclame Aqui, recebemos e analisamos reclamações de consumidores. Nosso objetivo é resolver conflitos entre consumidores e empresas, garantindo que seus direitos sejam respeitados. Entre em contato e saiba como podemos ajudar a solucionar sua reclamação de forma eficaz.'],'focusKeyword':[0,'reclamações'],'passwordDesign':[0,'default'],'passwordBackText':[0,'Voltar a'],'passwordButtonText':[0,'Introduza'],'passwordHeadingText':[0,'Área de convidado'],'passwordSubheadingText':[0,'Por favor, introduza a palavra-passe para aceder à página'],'passwordPlaceholderText':[0,'Introduza a palavra-passe']}],'name':[0,'Reclamações'],'slug':[0,'reclamacoes'],'type':[0,'default'],'blocks':[1,[[0,'zfOe95'],[0,'ai-LsIg8G'],[0,'ai-ugOYag']]]}],'ai-pQJlU':[0,{'meta':[0,{'title':[0,'Reclame Aqui - Soluções para Reclamações de Consumidores'],'noindex':[0,false],'keywords':[1,[[0,'reclamações'],[0,'direitos do consumidor'],[0,'solução de conflitos']]],'password':[0,''],'ogImageAlt':[0,''],'description':[0,'Na Reclame Sac, recebemos e analisamos reclamações de consumidores. Nosso objetivo é resolver conflitos entre consumidores e empresas, garantindo que seus direitos sejam respeitados. Entre em contato e saiba como podemos ajudar na sua reclamação.'],'focusKeyword':[0,'reclamações'],'passwordDesign':[0,'default'],'passwordBackText':[0,'Voltar'],'passwordButtonText':[0,'Acessar'],'passwordHeadingText':[0,'Área de visitantes'],'passwordSubheadingText':[0,'Digite a senha para acessar a página'],'passwordPlaceholderText':[0,'Digite a senha']}],'name':[0,'Inicio'],'slug':[0,'home'],'type':[0,'default'],'blocks':[1,[[0,'ai-NtVeA8'],[0,'ai-CDWkaW'],[0,'ai-obBnub'],[0,'ai-Crojhm'],[0,'ai-9_dLhw']]]}],'ai-pbfny':[0,{'meta':[0,{'title':[0,'Contato - Reclame Aqui para Resolver Suas Reclamações'],'keywords':[1,[[0,'reclamações'],[0,'consumidor'],[0,'resolução de conflitos']]],'description':[0,'Entre em contato conosco para registrar sua reclamação. Estamos aqui para ajudar a resolver conflitos entre consumidores e empresas, garantindo seus direitos. Preencha nosso formulário e nossa equipe analisará sua solicitação com atenção e agilidade.'],'focusKeyword':[0,'reclamações']}],'name':[0,'Contato'],'slug':[0,'contato'],'type':[0,'default'],'blocks':[1,[[0,'zpkGeg'],[0,'ai-axtKDF']]]}]}],'blocks':[0,{'header':[0,{'type':[0,'BlockNavigation'],'mobile':[0,{'height':[0,72],'logoHeight':[0,24]}],'desktop':[0,{'height':[0,84],'logoHeight':[0,24]}],'settings':[0,{'styles':[0,{'width':[0,'1240px'],'padding':[0,'30px 16px 30px 16px'],'m-padding':[0,'24px 16px 24px 16px'],'logo-width':[0,'137.27587890625px'],'cartIconSize':[0,'24px'],'link-spacing':[0,'32px'],'m-logo-width':[0,'137.27587890625px'],'m-link-spacing':[0,'20px'],'element-spacing':[0,'32px'],'contrastBackgroundColor':[0,'rgb(224, 224, 224)']}],'cartText':[0,''],'isSticky':[0,true],'showLogo':[0,true],'headerLayout':[0,'desktop-1'],'isCartVisible':[0,true],'logoImagePath':[0,'reclame-aqui-logo-YyvZxEwPbVUZQ03R.png'],'mHeaderLayout':[0,'mobile-1'],'logoImageOrigin':[0,'assets'],'mobileLinksAlignment':[0,'right']}],'zindexes':[1,[]],'background':[0,{'color':[0,'#ffffff'],'current':[0,'color'],'isTransparent':[0,false]}],'components':[1,[]],'fontWeight':[0,400],'logoAspectRatio':[0,5.813953488372093],'navLinkTextColor':[0,'#0d141a'],'navLinkTextColorHover':[0,'#0d141a']}],'zSiG-O':[0,{'slot':[0,'footer'],'type':[0,'BlockLayout'],'mobile':[0,{'minHeight':[0,379]}],'desktop':[0,{'minHeight':[0,344]}],'settings':[0,{'styles':[0,{'cols':[0,'12'],'rows':[0,10],'width':[0,'1224px'],'m-rows':[0,'1'],'col-gap':[0,'24px'],'row-gap':[0,'16px'],'row-size':[0,'48px'],'column-gap':[0,'24px'],'block-padding':[0,'16px 0 16px 0'],'m-block-padding':[0,'40px 16px 40px 16px']}]}],'zindexes':[1,[[0,'ai-iUNzhA'],[0,'ai-Ef1CZP'],[0,'ai-STocdi'],[0,'ai-FCoPqZ'],[0,'ai-U5Udrp'],[0,'ai-c5VI3m'],[0,'ai-KfzSMM']]],'background':[0,{'color':[0,'rgb(30, 146, 1)'],'current':[0,'color']}],'components':[1,[[0,'ai-iUNzhA'],[0,'ai-Ef1CZP'],[0,'ai-STocdi'],[0,'ai-FCoPqZ'],[0,'ai-U5Udrp'],[0,'ai-c5VI3m'],[0,'ai-KfzSMM']]],'initialBlockId':[0,'W7N_1fYuy']}],'ai-9_dLhw':[0,{'type':[0,'BlockLayout'],'mobile':[0,{'minHeight':[0,697]}],'desktop':[0,{'minHeight':[0,459]}],'settings':[0,{'styles':[0,{'rows':[0,12],'row-gap':[0,'16px'],'row-size':[0,'48px'],'column-gap':[0,'24px'],'block-padding':[0,'16px 0'],'m-block-padding':[0,'56px 16px 56px 16px'],'grid-gap-history':[0,'16px 24px']}]}],'zindexes':[1,[[0,'ai-JHIA28'],[0,'ai-kbJB5n'],[0,'ai-K_m8Gh'],[0,'ai-U30OR0'],[0,'ai-bG__PY'],[0,'ai-UdmjqW'],[0,'ai-fwm6Qf'],[0,'ai-aig_DM']]],'attachment':[0,'fixed'],'background':[0,{'alt':[0,'woman wearing yellow long-sleeved dress under white clouds and blue sky during daytime'],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.45_c4a0b096-AMqlEVJxKqTo3BnM.jpg'],'image':[0,'https://assets.zyrosite.com/AQEDqQbKJoT251MN/imagem-do-whatsapp-de-2025-01-24-a-s-23.08.45_c4a0b096-AMqlEVJxKqTo3BnM.jpg'],'origin':[0,'assets'],'current':[0,'image'],'overlay-opacity':[0,'0.45']}],'components':[1,[[0,'ai-JHIA28'],[0,'ai-kbJB5n'],[0,'ai-K_m8Gh'],[0,'ai-U30OR0'],[0,'ai-bG__PY'],[0,'ai-UdmjqW'],[0,'ai-fwm6Qf'],[0,'ai-aig_DM']]],'initialBlockId':[0,'zL5S8c']}],'ai-CDWkaW':[0,{'type':[0,'BlockLayout'],'mobile':[0,{'minHeight':[0,540]}],'desktop':[0,{'minHeight':[0,609]}],'settings':[0,{'styles':[0,{'block-padding':[0,'16px 0 16px 0'],'m-block-padding':[0,'16px']}]}],'zindexes':[1,[[0,'ai-KR9Sks'],[0,'ai-78_Gwu'],[0,'ai-y1cWnY'],[0,'ai-3UiLLD'],[0,'ai-1_6y69'],[0,'ai-vHlyDh'],[0,'ai-AtSDy6']]],'attachment':[0,'fixed'],'background':[0,{'color':[0,'#ffffff'],'current':[0,'color'],'gradient':[0,{'angle':[0,135],'colors':[1,[[0,{'value':[0,'#4A90E2']}],[0,{'value':[0,'rgb(143, 17, 168)']}]]],'isAnimated':[0,false]}],'overlay-opacity':[0,'0.90']}],'components':[1,[[0,'ai-KR9Sks'],[0,'ai-78_Gwu'],[0,'ai-y1cWnY'],[0,'ai-3UiLLD'],[0,'ai-1_6y69'],[0,'ai-vHlyDh'],[0,'ai-AtSDy6']]],'initialBlockId':[0,'zwaaLr']}],'ai-Crojhm':[0,{'type':[0,'BlockLayout'],'mobile':[0,{'minHeight':[0,1158]}],'desktop':[0,{'minHeight':[0,849]}],'settings':[0,{'styles':[0,{'block-padding':[0,'16px 0 16px 0'],'m-block-padding':[0,'16px']}]}],'zindexes':[1,[[0,'ai-YEMGnC'],[0,'ai-cxx3-H'],[0,'ai-73Dov4'],[0,'zTL-CU'],[0,'z6c3Lb'],[0,'zxU7yl']]],'attachment':[0,'fixed'],'background':[0,{'color':[0,'#ffffff'],'current':[0,'color'],'gradient':[0,{'angle':[0,135],'colors':[1,[[0,{'value':[0,'#4A90E2']}],[0,{'value':[0,'rgb(143, 17, 168)']}]]],'isAnimated':[0,false]}],'overlay-opacity':[0,'0.90']}],'components':[1,[[0,'ai-YEMGnC'],[0,'ai-cxx3-H'],[0,'ai-73Dov4'],[0,'zTL-CU'],[0,'z6c3Lb'],[0,'zxU7yl']]],'initialBlockId':[0,'z8kYQI']}],'ai-NtVeA8':[0,{'type':[0,'BlockLayout'],'mobile':[0,{'minHeight':[0,469]}],'desktop':[0,{'minHeight':[0,698]}],'settings':[0,{'styles':[0,{'block-padding':[0,'16px 0 16px 0'],'m-block-padding':[0,'16px']}]}],'zindexes':[1,[[0,'ai-za1-kj'],[0,'ai-Ac3cVV'],[0,'zvCetq'],[0,'zS5vXu']]],'attachment':[0,'fixed'],'background':[0,{'alt':[0,'black and white bed linen'],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.40_1ed04360-AVL18WlzZpfVK5LQ.jpg'],'image':[0,'https://assets.zyrosite.com/AQEDqQbKJoT251MN/imagem-do-whatsapp-de-2025-01-24-a-s-23.08.40_1ed04360-AVL18WlzZpfVK5LQ.jpg'],'video':[0,{'videoSrc':[0,'https://videos.pexels.com/video-files/3197580/3197580-hd_1920_1080_25fps.mp4'],'videoThumbnailSrc':[0,'https://images.pexels.com/videos/3197580/free-video-3197580.jpg?auto=compress&amp;cs=tinysrgb&amp;fit=crop&amp;h=630&amp;w=1200']}],'origin':[0,'assets'],'current':[0,'image'],'gradient':[0,{'angle':[0,135],'colors':[1,[[0,{'value':[0,'#4A90E2']}],[0,{'value':[0,'rgb(143, 17, 168)']}]]],'isAnimated':[0,false]}],'overlay-opacity':[0,'0.45']}],'components':[1,[[0,'ai-za1-kj'],[0,'ai-Ac3cVV'],[0,'zvCetq'],[0,'zS5vXu']]],'initialBlockId':[0,'z0KtBA']}],'ai-obBnub':[0,{'type':[0,'BlockLayout'],'mobile':[0,{'minHeight':[0,1205]}],'desktop':[0,{'minHeight':[0,846]}],'settings':[0,{'styles':[0,{'block-padding':[0,'16px 0 16px 0'],'m-block-padding':[0,'16px']}]}],'zindexes':[1,[[0,'ai-qH-AL9'],[0,'ai-HBYbDf'],[0,'ai-VY23_T'],[0,'ai-6ROjav'],[0,'ai-6agaS1'],[0,'ai-ft6bG5'],[0,'ai-Audoli'],[0,'ai-VMub4i'],[0,'ai-GQhKv_'],[0,'ai-jt7JyN'],[0,'ai-YdQaE8'],[0,'ai-VYllXR'],[0,'ai-8-ZftQ'],[0,'ai-IerjSC']]],'attachment':[0,'fixed'],'background':[0,{'color':[0,'rgb(30, 146, 1)'],'current':[0,'color'],'gradient':[0,{'angle':[0,135],'colors':[1,[[0,{'value':[0,'#4A90E2']}],[0,{'value':[0,'rgb(143, 17, 168)']}]]],'isAnimated':[0,false]}],'overlay-opacity':[0,'0.90']}],'components':[1,[[0,'ai-VY23_T'],[0,'ai-6ROjav'],[0,'ai-HBYbDf'],[0,'ai-6agaS1'],[0,'ai-qH-AL9'],[0,'ai-ft6bG5'],[0,'ai-Audoli'],[0,'ai-YdQaE8'],[0,'ai-VMub4i'],[0,'ai-VYllXR'],[0,'ai-GQhKv_'],[0,'ai-jt7JyN'],[0,'ai-IerjSC'],[0,'ai-8-ZftQ']]],'initialBlockId':[0,'z0K2P-']}]}],'elements':[0,{'z6c3Lb':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,1135],'left':[0,11],'width':[0,132],'height':[0,99]}],'desktop':[0,{'top':[0,490],'left':[0,28],'width':[0,243],'height':[0,174]}],'settings':[0,{'alt':[0,''],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.10.36_69040f59-A1aBxoOQRwsL505N.jpg'],'origin':[0,'assets'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'fullResolutionWidth':[0,266],'fullResolutionHeight':[0,190]}],'zS5vXu':[0,{'type':[0,'GridEmbed'],'mobile':[0,{'top':[0,205],'left':[0,0],'width':[0,328],'height':[0,155]}],'content':[0,'<!-- Event snippet for Visualização de página conversion page -->\n<script>\n  gtag('event', 'conversion', {\n      'send_to': 'AW-16714525524/n5bmCNiWjtYZENTWjaI-',\n      'value': 1.0,\n      'currency': 'BRL'\n  });\n</script>\n'],'desktop':[0,{'top':[0,526],'left':[0,0],'width':[0,400],'height':[0,155]}],'settings':[0,{'styles':[0,{}]}]}],'zTL-CU':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,14],'left':[0,85],'width':[0,158],'height':[0,26]}],'desktop':[0,{'top':[0,40],'left':[0,122],'width':[0,260],'height':[0,45]}],'settings':[0,{'alt':[0,''],'path':[0,'reclame-aqui-logo-YyvZxEwPbVUZQ03R.png'],'origin':[0,'assets'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'fullResolutionWidth':[0,3500],'fullResolutionHeight':[0,602]}],'zvCetq':[0,{'type':[0,'GridEmbed'],'mobile':[0,{'top':[0,5],'left':[0,0],'width':[0,328],'height':[0,155]}],'content':[0,'<!-- Google tag (gtag.js) -->\n<script async src=\'https://www.googletagmanager.com/gtag/js?id=AW-16714525524\'>\n</script>\n<script>\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'AW-16714525524');\n</script>'],'desktop':[0,{'top':[0,45],'left':[0,357],'width':[0,400],'height':[0,155]}],'settings':[0,{'styles':[0,{}]}]}],'zxU7yl':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,1134],'left':[0,164],'width':[0,146],'height':[0,100]}],'desktop':[0,{'top':[0,490],'left':[0,309],'width':[0,243],'height':[0,174]}],'settings':[0,{'alt':[0,''],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.45_c4a0b096-AMqlEVJxKqTo3BnM.jpg'],'origin':[0,'assets'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'fullResolutionWidth':[0,800],'fullResolutionHeight':[0,600]}],'ai-1_6y69':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,214],'left':[0,126],'width':[0,94],'height':[0,42]}],'content':[0,'<h3 dir=\'auto\' style=\'color: rgb(74, 144, 226)\'>100%</h3>'],'desktop':[0,{'top':[0,378],'left':[0,206],'width':[0,194],'height':[0,62]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zXs4eV']}],'ai-3UiLLD':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,213],'left':[0,0],'width':[0,328],'height':[0,42]}],'content':[0,'<h3 dir=\'auto\' style=\'color: rgb(74, 144, 226)\'>15000+</h3>'],'desktop':[0,{'top':[0,378],'left':[0,0],'width':[0,194],'height':[0,62]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'z6s9Al']}],'ai-6ROjav':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,129],'left':[0,0],'width':[0,328],'height':[0,72]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body\'>Ajudamos a resolver reclamações de consumidores com empresas que não respeitam seus direitos.</p>'],'desktop':[0,{'top':[0,161],'left':[0,309],'width':[0,606],'height':[0,48]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zQflXe']}],'ai-6agaS1':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,385],'left':[0,14],'width':[0,300],'height':[0,23]}],'content':[0,'<h6 dir=\'auto\' style=\'color: #0d141a\'><strong>Análise de Reclamações</strong></h6>'],'desktop':[0,{'top':[0,584],'left':[0,47],'width':[0,309],'height':[0,23]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'za4S0r']}],'ai-73Dov4':[0,{'type':[0,'GridForm'],'formId':[0,'Reclamação1'],'mobile':[0,{'top':[0,264],'left':[0,0],'width':[0,328],'height':[0,870]}],'desktop':[0,{'top':[0,24],'left':[0,612],'width':[0,606],'height':[0,825],'inputTextSize':[0,16],'labelTextSize':[0,14],'formElementsVerticalSpacing':[0,15]}],'settings':[0,{'theme':[0,'light'],'schema':[1,[[0,{'id':[0,'firstName'],'svg':[0,'align-left-short'],'name':[0,'Full name'],'type':[0,'GridInput'],'fieldType':[0,'short-answer'],'inputLabel':[0,'Seu nome completo'],'validation':[1,[[1,[[0,'optional']]]]],'placeholder':[0,'Digite seu nome aqui'],'validationType':[0,'text'],'validation-messages':[0,{'required':[0,'Nome é obrigatório']}]}],[0,{'id':[0,'ztL_Qk'],'svg':[0,'align-left-short'],'name':[0,'Telefone'],'type':[0,'GridInput'],'fieldType':[0,'short-answer'],'inputLabel':[0,'Telefone'],'validation':[1,[[1,[[0,'bail']]],[1,[[0,'required']]],[1,[[0,'phone'],[0,'/^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-s./0-9]*$/']]]]],'placeholder':[0,'Insira seu WhatsApp'],'validationType':[0,'phone'],'validation-messages':[0,{'phone':[0,'Please enter a valid phone number'],'required':[0,'This field is required']}]}],[0,{'id':[0,'z4_c42'],'svg':[0,'align-left-short'],'name':[0,'CPF'],'type':[0,'GridInput'],'fieldType':[0,'short-answer'],'inputLabel':[0,'CPF'],'validation':[1,[[1,[[0,'required']]]]],'placeholder':[0,'Insira seu CPF'],'validationType':[0,'text'],'validation-messages':[0,{'required':[0,'This field is required']}]}],[0,{'id':[0,'email'],'svg':[0,'align-left-short'],'name':[0,'Email'],'type':[0,'GridInput'],'fieldType':[0,'short-answer'],'inputLabel':[0,'Seu e-mail'],'validation':[1,[[1,[[0,'bail']]],[1,[[0,'email']]],[1,[[0,'required']]]]],'placeholder':[0,'Digite seu e-mail aqui'],'validationType':[0,'email'],'validation-messages':[0,{'email':[0,'Please enter a valid email address'],'required':[0,'E-mail é obrigatório']}]}],[0,{'id':[0,'zvIsIm'],'svg':[0,'align-left-short'],'name':[0,'Empresa'],'type':[0,'GridInput'],'fieldType':[0,'short-answer'],'inputLabel':[0,'Empresa'],'validation':[1,[[1,[[0,'required']]]]],'placeholder':[0,'Qual empresa deseja reclamar?'],'validationType':[0,'text'],'validation-messages':[0,{'required':[0,'This field is required']}]}],[0,{'id':[0,'message'],'svg':[0,'align-left'],'tag':[0,'textarea'],'name':[0,'Paragraph'],'type':[0,'GridInput'],'inputLabel':[0,'Sua reclamação'],'validation':[1,[[1,[[0,'required']]]]],'placeholder':[0,'Descreva sua reclamação aqui'],'validationType':[0,'text'],'validation-messages':[0,{'required':[0,'Mensagem é obrigatória']}]}],[0,{'id':[0,'zey4KI'],'svg':[0,'circle-input'],'tag':[0,'radio'],'name':[0,'Dispositivo:'],'type':[0,'GridSelectInput'],'options':[1,[[0,{'id':[0,'zFLkkn'],'value':[0,'Android']}],[0,{'id':[0,'zCvsGJ'],'value':[0,'IOS (IPHONE)']}]]],'inputLabel':[0,'Dispositivo:'],'validation':[1,[[1,[[0,'required']]]]],'validationType':[0,'text'],'validation-messages':[0,{'required':[0,'Este campo é obrigatório ']}]}]]],'styles':[0,{'justify':[0,'center'],'formSpacing':[0,'22px 10px'],'m-element-margin':[0,'0 0 16px 0']}],'successMessage':[0,'Reclamação enviada com sucesso']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'formPadding':[0,30],'inputFillColor':[0,'#ffffff'],'inputTextColor':[0,'#0d141a'],'labelTextColor':[0,'#0d141a'],'formBorderWidth':[0,0],'innerBackground':[0,{'color':[0,'#EAF8F2'],'image':[0,''],'current':[0,'']}],'formBorderRadius':[0,0],'initialElementId':[0,'z12aUc'],'inputBorderColor':[0,'rgb(184, 192, 204)'],'inputBorderWidth':[0,1],'submitButtonData':[0,{'type':[0,'GridButton'],'content':[0,'Enviar reclamação'],'settings':[0,{'type':[0,'primary'],'styles':[0,{'align':[0,'start'],'justify':[0,'center'],'position':[0,'8/8/9/10']}],'isFormButton':[0,true]}]}],'inputBorderRadius':[0,10],'formBackgroundColor':[0,'transparent'],'inputFillColorHover':[0,'#ffffff'],'inputTextColorHover':[0,'#0d141a'],'inputBorderColorHover':[0,'#0d141a'],'submitButtonFontColor':[0,'#ffffff'],'submitButtonBorderColor':[0,'#0d141a'],'submitButtonBorderRadius':[0,50],'submitButtonFontColorHover':[0,'#ffffff'],'submitButtonBackgroundColor':[0,'#4A90E2'],'submitButtonBorderColorHover':[0,'#0d141a'],'submitButtonBackgroundColorHover':[0,'#4A90E2']}],'ai-78_Gwu':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,80],'left':[0,0],'width':[0,328],'height':[0,120]}],'content':[0,'<p dir=\'auto\' style=\'color: rgb(86, 88, 94)\' class=\'body\'>Somos a empresa do Reclame Aqui, dedicada a receber e resolver reclamações de consumidores, garantindo que seus direitos sejam respeitados e atendidos com as medidas cabíveis.</p>'],'desktop':[0,{'top':[0,240],'left':[0,0],'width':[0,503],'height':[0,72]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zxFVSV']}],'ai-8-ZftQ':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,1064],'left':[0,17],'width':[0,291],'height':[0,23]}],'content':[0,'<h6 dir=\'auto\' style=\'color: #0d141a\'><strong>Defesa do Consumidor</strong></h6>'],'desktop':[0,{'top':[0,584],'left':[0,870],'width':[0,309],'height':[0,23]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zmrIq-']}],'ai-Ac3cVV':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,288],'left':[0,0],'width':[0,328],'height':[0,72]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body\'>Estamos aqui para ajudar a resolver suas insatisfações com empresas. Entre em contato conosco.</p>'],'desktop':[0,{'top':[0,428],'left':[0,360],'width':[0,503],'height':[0,48]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zkb_2e']}],'ai-AtSDy6':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,255],'left':[0,0],'width':[0,328],'height':[0,24]}],'content':[0,'<p dir=\'auto\' style=\'color: rgb(86, 88, 94)\' class=\'body\'>Solução rápida</p>'],'desktop':[0,{'top':[0,440],'left':[0,0],'width':[0,194],'height':[0,24]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zZja0I']}],'ai-Audoli':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,520],'left':[0,0],'width':[0,328],'height':[0,224]}],'desktop':[0,{'top':[0,280],'left':[0,412],'width':[0,400],'height':[0,304],'borderRadius':[0,'20px']}],'settings':[0,{'alt':[0,''],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.10.36_69040f59-A1aBxoOQRwsL505N.jpg'],'origin':[0,'assets'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zwr-4U'],'fullResolutionWidth':[0,266],'fullResolutionHeight':[0,190]}],'ai-Ef1CZP':[0,{'type':[0,'GridSocialIcons'],'links':[1,[[0,{'svg':[0,'<svg width=\'24\' height=\'24\' viewBox=\'0 0 24 24\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M24 12.0726C24 5.44354 18.629 0.0725708 12 0.0725708C5.37097 0.0725708 0 5.44354 0 12.0726C0 18.0619 4.38823 23.0264 10.125 23.9274V15.5414H7.07661V12.0726H10.125V9.4287C10.125 6.42144 11.9153 4.76031 14.6574 4.76031C15.9706 4.76031 17.3439 4.99451 17.3439 4.99451V7.94612H15.8303C14.34 7.94612 13.875 8.87128 13.875 9.82015V12.0726H17.2031L16.6708 15.5414H13.875V23.9274C19.6118 23.0264 24 18.0619 24 12.0726Z\' fill=\'currentColor\'></path></svg>'],'icon':[0,'facebook'],'link':[0,'https://www.facebook.com/']}],[0,{'svg':[0,'<svg width=\'24\' height=\'24\' viewBox=\'0 0 24 24\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M12.0027 5.84808C8.59743 5.84808 5.85075 8.59477 5.85075 12C5.85075 15.4053 8.59743 18.1519 12.0027 18.1519C15.4079 18.1519 18.1546 15.4053 18.1546 12C18.1546 8.59477 15.4079 5.84808 12.0027 5.84808ZM12.0027 15.9996C9.80212 15.9996 8.00312 14.2059 8.00312 12C8.00312 9.7941 9.79677 8.00046 12.0027 8.00046C14.2086 8.00046 16.0022 9.7941 16.0022 12C16.0022 14.2059 14.2032 15.9996 12.0027 15.9996ZM19.8412 5.59644C19.8412 6.39421 19.1987 7.03135 18.4062 7.03135C17.6085 7.03135 16.9713 6.38885 16.9713 5.59644C16.9713 4.80402 17.6138 4.16153 18.4062 4.16153C19.1987 4.16153 19.8412 4.80402 19.8412 5.59644ZM23.9157 7.05277C23.8247 5.13063 23.3856 3.42801 21.9775 2.02522C20.5747 0.622429 18.8721 0.183388 16.9499 0.0870135C14.9689 -0.0254238 9.03112 -0.0254238 7.05008 0.0870135C5.1333 0.178034 3.43068 0.617075 2.02253 2.01986C0.614389 3.42265 0.180703 5.12527 0.0843279 7.04742C-0.0281093 9.02845 -0.0281093 14.9662 0.0843279 16.9472C0.175349 18.8694 0.614389 20.572 2.02253 21.9748C3.43068 23.3776 5.12794 23.8166 7.05008 23.913C9.03112 24.0254 14.9689 24.0254 16.9499 23.913C18.8721 23.822 20.5747 23.3829 21.9775 21.9748C23.3803 20.572 23.8193 18.8694 23.9157 16.9472C24.0281 14.9662 24.0281 9.03381 23.9157 7.05277ZM21.3564 19.0728C20.9388 20.1223 20.1303 20.9307 19.0755 21.3537C17.496 21.9802 13.7481 21.8356 12.0027 21.8356C10.2572 21.8356 6.50396 21.9748 4.92984 21.3537C3.88042 20.9361 3.07195 20.1276 2.64897 19.0728C2.02253 17.4934 2.16709 13.7455 2.16709 12C2.16709 10.2546 2.02789 6.50129 2.64897 4.92717C3.06659 3.87776 3.87507 3.06928 4.92984 2.6463C6.50931 2.01986 10.2572 2.16443 12.0027 2.16443C13.7481 2.16443 17.5014 2.02522 19.0755 2.6463C20.1249 3.06392 20.9334 3.8724 21.3564 4.92717C21.9828 6.50665 21.8383 10.2546 21.8383 12C21.8383 13.7455 21.9828 17.4987 21.3564 19.0728Z\' fill=\'currentColor\'></path></svg>'],'icon':[0,'instagram'],'link':[0,'https://www.instagram.com/']}],[0,{'svg':[0,'<svg viewBox=\'0 0 24 24\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'>\n<path d=\'M22.5 9.84202C20.4357 9.84696 18.4221 9.20321 16.7435 8.00171V16.3813C16.7429 17.9333 16.2685 19.4482 15.3838 20.7233C14.499 21.9984 13.246 22.973 11.7923 23.5168C10.3387 24.0606 8.75362 24.1477 7.24914 23.7664C5.74466 23.3851 4.39245 22.5536 3.37333 21.383C2.3542 20.2125 1.71674 18.7587 1.54617 17.2161C1.3756 15.6735 1.68007 14.1156 2.41884 12.7507C3.15762 11.3858 4.2955 10.279 5.68034 9.57823C7.06517 8.87746 8.63095 8.61616 10.1683 8.82927V13.0439C9.46481 12.8227 8.70938 12.8293 8.0099 13.063C7.31041 13.2966 6.70265 13.7453 6.2734 14.345C5.84415 14.9446 5.61536 15.6646 5.6197 16.402C5.62404 17.1395 5.8613 17.8567 6.29759 18.4512C6.73387 19.0458 7.34688 19.4873 8.04906 19.7127C8.75125 19.9381 9.5067 19.9359 10.2075 19.7063C10.9084 19.4768 11.5188 19.0316 11.9515 18.4345C12.3843 17.8374 12.6173 17.1188 12.6173 16.3813V0H16.7435C16.7406 0.348435 16.7698 0.696395 16.8307 1.03948C16.9741 1.80537 17.2722 2.53396 17.7068 3.18068C18.1415 3.8274 18.7035 4.37867 19.3585 4.80075C20.2903 5.41688 21.3829 5.74528 22.5 5.74505V9.84202Z\' fill=\'currentColor\'></path>\n</svg>'],'icon':[0,'tiktok'],'link':[0,'https://tiktok.com/']}],[0,{'svg':[0,'<svg width=\'24\' height=\'24\' viewBox=\'0 0 24 24\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'>\n<path d=\'M18.244 2.25H21.552L14.325 10.51L22.827 21.75H16.17L10.956 14.933L4.99003 21.75H1.68003L9.41003 12.915L1.25403 2.25H8.08003L12.793 8.481L18.244 2.25ZM17.083 19.77H18.916L7.08403 4.126H5.11703L17.083 19.77Z\' fill=\'currentColor\'></path>\n</svg>'],'icon':[0,'twitter'],'link':[0,'https://x.com/']}]]],'mobile':[0,{'top':[0,153],'left':[0,0],'width':[0,158],'height':[0,24]}],'desktop':[0,{'top':[0,184],'left':[0,0],'width':[0,152],'height':[0,24]}],'settings':[0,{'styles':[0,{'icon-size':[0,'24px'],'icon-color':[0,'#ffffff'],'icon-spacing':[0,'space-between'],'icon-direction':[0,'row'],'icon-color-hover':[0,'#ffffff'],'m-element-margin':[0,'0 0 32px 0'],'space-between-icons':[0,'32px']}],'useBrandColors':[0,false]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'Jxpyzjxuzy']}],'ai-FCoPqZ':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,209],'left':[0,0],'width':[0,328],'height':[0,21]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body-small\'><span style=\'font-weight: 700\'><strong>Contato</strong></span></p>'],'desktop':[0,{'top':[0,80],'left':[0,618],'width':[0,194],'height':[0,21]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'center'],'m-element-margin':[0,'0 0 24px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'fRoA6n-q74']}],'ai-GQhKv_':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,732],'left':[0,15],'width':[0,296],'height':[0,23]}],'content':[0,'<h6 dir=\'auto\' style=\'color: #0d141a\'><strong>Contato com Empresas</strong></h6>'],'desktop':[0,{'top':[0,584],'left':[0,458],'width':[0,309],'height':[0,23]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zUfwMo']}],'ai-HBYbDf':[0,{'svg':[0,'<svg preserveAspectRatio=\'none\' viewBox=\'0 0 80 80\' fill=\'none\' stroke=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M0 0H80V80H0V0Z\'></path></svg>'],'type':[0,'GridShape'],'color':[0,'#ffffff'],'shape':[0,'rectangle'],'mobile':[0,{'top':[0,373],'left':[0,0],'width':[0,328],'height':[0,115]}],'desktop':[0,{'top':[0,544],'left':[0,0],'width':[0,400],'height':[0,200]}],'settings':[0,{'styles':[1,[]]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zUSjJp']}],'ai-IerjSC':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,1088],'left':[0,14],'width':[0,297],'height':[0,72]}],'content':[0,'<p dir=\'auto\' style=\'color: rgb(86, 88, 94)\' class=\'body\'>Nosso objetivo é garantir que os direitos dos consumidores sejam respeitados e atendidos.</p>'],'desktop':[0,{'top':[0,623],'left':[0,870],'width':[0,309],'height':[0,72]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zXIH9m']}],'ai-JHIA28':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,120],'left':[0,0],'width':[0,328],'height':[0,108]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body-large\'>O atendimento foi excelente e resolveram minha reclamação rapidamente. Recomendo a todos os consumidores!</p>'],'desktop':[0,{'top':[0,159],'left':[0,52],'width':[0,503],'height':[0,81]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zJvNix']}],'ai-KR9Sks':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,40],'left':[0,0],'width':[0,328],'height':[0,31]}],'content':[0,'<h3 dir=\'auto\' style=\'--lineHeightMobile: 1.3; --fontSizeMobile: 24px\'>Sobre a Reclame Aqui</h3>'],'desktop':[0,{'top':[0,120],'left':[0,0],'width':[0,503],'height':[0,62]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zjv4ht']}],'ai-K_m8Gh':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,240],'left':[0,136],'width':[0,57],'height':[0,56]}],'desktop':[0,{'top':[0,264],'left':[0,280],'width':[0,48],'height':[0,48],'borderRadius':[0,'50%']}],'settings':[0,{'alt':[0,'A sign featuring the word 'CONSULTATION' in bold, black capital letters. Beneath the text, there is Braille marked on a white background, surrounded by a dark wooden frame.'],'path':[0,'photo-1551062657-faa29d4266ab'],'origin':[0,'unsplash'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zzZH5O']}],'ai-KfzSMM':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,336],'left':[0,0],'width':[0,328],'height':[0,24]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff; --lineHeightDesktop: 1.3; --fontSizeDesktop: 14px\' class=\'body\'>© 2025. All rights reserved.</p>'],'desktop':[0,{'top':[0,286],'left':[0,0],'width':[0,503],'height':[0,18]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'center'],'m-element-margin':[0,'0 0 24px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'fRoA6n-q74']}],'ai-STocdi':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,83],'left':[0,0],'width':[0,328],'height':[0,48]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff; --lineHeightDesktop: 1.3; --fontSizeDesktop: 14px\' class=\'body\'>Apoio ao consumidor e resolução de conflitos.</p>'],'desktop':[0,{'top':[0,126],'left':[0,0],'width':[0,297],'height':[0,36]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'center'],'m-element-margin':[0,'0 0 24px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'fRoA6n-q74']}],'ai-U30OR0':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,423],'left':[0,0],'width':[0,328],'height':[0,81]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body-large\'>A equipe foi muito atenciosa e solucionou meu problema de maneira eficiente e rápida, agradeço!</p>'],'desktop':[0,{'top':[0,159],'left':[0,670],'width':[0,503],'height':[0,54]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'z3Be3T']}],'ai-U5Udrp':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,304],'left':[0,0],'width':[0,328],'height':[0,21]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body-small\'><span style=\'font-weight: 700\'><strong>Suporte</strong></span></p>'],'desktop':[0,{'top':[0,80],'left':[0,849],'width':[0,375],'height':[0,21]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'center'],'m-element-margin':[0,'0 0 24px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'fRoA6n-q74']}],'ai-UdmjqW':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,543],'left':[0,137],'width':[0,54],'height':[0,54]}],'desktop':[0,{'top':[0,264],'left':[0,897],'width':[0,48],'height':[0,48],'borderRadius':[0,'50%']}],'settings':[0,{'alt':[0,'A metal panel with a sign depicting a hand and a coin above it. Below the illustration, there are Chinese characters and the word 'REFUND' in English.'],'path':[0,'photo-1697992350118-9e19c604d808'],'origin':[0,'unsplash'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zI3HQz']}],'ai-VMub4i':[0,{'svg':[0,'<svg preserveAspectRatio=\'none\' viewBox=\'0 0 80 80\' fill=\'none\' stroke=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M0 0H80V80H0V0Z\'></path></svg>'],'type':[0,'GridShape'],'color':[0,'#ffffff'],'shape':[0,'rectangle'],'mobile':[0,{'top':[0,728],'left':[0,0],'width':[0,328],'height':[0,136]}],'desktop':[0,{'top':[0,544],'left':[0,412],'width':[0,400],'height':[0,200]}],'settings':[0,{'styles':[1,[]]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zO28cy']}],'ai-VY23_T':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,24],'left':[0,0],'width':[0,328],'height':[0,83]}],'content':[0,'<h3 dir=\'auto\' style=\'color: #ffffff\'>Serviços de Reclamação</h3>'],'desktop':[0,{'top':[0,80],'left':[0,0],'width':[0,1224],'height':[0,62]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'z8RsX6']}],'ai-VYllXR':[0,{'svg':[0,'<svg preserveAspectRatio=\'none\' viewBox=\'0 0 80 80\' fill=\'none\' stroke=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M0 0H80V80H0V0Z\'></path></svg>'],'type':[0,'GridShape'],'color':[0,'#ffffff'],'shape':[0,'rectangle'],'mobile':[0,{'top':[0,1040],'left':[0,0],'width':[0,328],'height':[0,133]}],'desktop':[0,{'top':[0,544],'left':[0,824],'width':[0,400],'height':[0,200]}],'settings':[0,{'styles':[1,[]]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zTfhC7']}],'ai-YEMGnC':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,64],'left':[0,0],'width':[0,328],'height':[0,83]}],'content':[0,'<h3 dir=\'auto\'>Entre em Contato Conosco</h3>'],'desktop':[0,{'top':[0,160],'left':[0,0],'width':[0,503],'height':[0,125]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'m-text':[0,'center'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zqYAAU']}],'ai-YdQaE8':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,880],'left':[0,0],'width':[0,328],'height':[0,172]}],'desktop':[0,{'top':[0,280],'left':[0,824],'width':[0,400],'height':[0,304],'borderRadius':[0,'20px']}],'settings':[0,{'alt':[0,''],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.08.23_aa4d790c-YbNqLOWZP5sKanKL.jpg'],'origin':[0,'assets'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zuA3Xb'],'fullResolutionWidth':[0,960],'fullResolutionHeight':[0,640]}],'ai-aig_DM':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,384],'left':[0,0],'width':[0,328],'height':[0,23]}],'content':[0,'<h6 dir=\'auto\' style=\'color: #ffffff; --lineHeightDesktop: 1.3; --fontSizeDesktop: 20px\'>★★★★★</h6>'],'desktop':[0,{'top':[0,120],'left':[0,824],'width':[0,194],'height':[0,26]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zguhbM']}],'ai-bG__PY':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,607],'left':[0,0],'width':[0,328],'height':[0,24]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body\'>Carlos Souza</p>'],'desktop':[0,{'top':[0,320],'left':[0,721],'width':[0,400],'height':[0,24]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zCqt29']}],'ai-c5VI3m':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,241],'left':[0,0],'width':[0,328],'height':[0,24]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body\'>contato@reclamesac.com</p>'],'desktop':[0,{'top':[0,144],'left':[0,618],'width':[0,194],'height':[0,24]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'center'],'m-element-margin':[0,'0 0 24px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'fRoA6n-q74']}],'ai-cxx3-H':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,168],'left':[0,0],'width':[0,328],'height':[0,96]}],'content':[0,'<p dir=\'auto\' style=\'color: rgb(86, 88, 94)\' class=\'body\'>Estamos aqui para ouvir suas reclamações e ajudar a resolver problemas com empresas. Preencha o formulário e entraremos em contato.</p>'],'desktop':[0,{'top':[0,352],'left':[0,0],'width':[0,503],'height':[0,72]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'z3pOS1']}],'ai-ft6bG5':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,416],'left':[0,13],'width':[0,302],'height':[0,48]}],'content':[0,'<p dir=\'auto\' style=\'color: rgb(86, 88, 94)\' class=\'body\'>Recebemos e analisamos reclamações para garantir a defesa do consumidor.</p>'],'desktop':[0,{'top':[0,623],'left':[0,46],'width':[0,309],'height':[0,48]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zk-5NV']}],'ai-fwm6Qf':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,80],'left':[0,0],'width':[0,328],'height':[0,23]}],'content':[0,'<h6 dir=\'auto\' style=\'color: #ffffff; --lineHeightDesktop: 1.3; --fontSizeDesktop: 20px\'>★★★★★</h6>'],'desktop':[0,{'top':[0,117],'left':[0,207],'width':[0,194],'height':[0,26]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zDrP7Y']}],'ai-iUNzhA':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,40],'left':[0,0],'width':[0,328],'height':[0,26]}],'content':[0,'<h5 dir=\'auto\' style=\'color: #ffffff\'>Reclamações</h5>'],'desktop':[0,{'top':[0,70],'left':[0,0],'width':[0,297],'height':[0,34]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'center'],'m-element-margin':[0,'0 0 24px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'fRoA6n-q74']}],'ai-jt7JyN':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,760],'left':[0,14],'width':[0,298],'height':[0,72]}],'content':[0,'<p dir=\'auto\' style=\'color: rgb(86, 88, 94)\' class=\'body\'>Entramos em contato com as empresas para resolver as reclamações de forma eficiente.</p>'],'desktop':[0,{'top':[0,623],'left':[0,458],'width':[0,309],'height':[0,72]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zbYHpp']}],'ai-kbJB5n':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,304],'left':[0,0],'width':[0,328],'height':[0,24]}],'content':[0,'<p dir=\'auto\' style=\'color: #ffffff\' class=\'body\'>Maria Silva</p>'],'desktop':[0,{'top':[0,320],'left':[0,104],'width':[0,400],'height':[0,24]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zeAkR4']}],'ai-qH-AL9':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,224],'left':[0,0],'width':[0,328],'height':[0,173]}],'desktop':[0,{'top':[0,280],'left':[0,0],'width':[0,400],'height':[0,304],'borderRadius':[0,'20px']}],'settings':[0,{'alt':[0,''],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.09.52_e2288d6a-AwvDaE6JnaIq2EZa.jpg'],'origin':[0,'assets'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'z4-y3d'],'fullResolutionWidth':[0,1023],'fullResolutionHeight':[0,443]}],'ai-vHlyDh':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,256],'left':[0,126],'width':[0,202],'height':[0,24]}],'content':[0,'<p dir=\'auto\' style=\'color: rgb(86, 88, 94)\' class=\'body\'>Confiança do consumidor</p>'],'desktop':[0,{'top':[0,440],'left':[0,206],'width':[0,194],'height':[0,24]}],'settings':[0,{'styles':[0,{'text':[0,'left'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zyLMR7']}],'ai-y1cWnY':[0,{'rel':[0,'nofollow'],'type':[0,'GridImage'],'mobile':[0,{'top':[0,304],'left':[0,0],'width':[0,328],'height':[0,184]}],'desktop':[0,{'top':[0,128],'left':[0,526],'width':[0,698],'height':[0,376],'borderRadius':[0,'20px']}],'settings':[0,{'alt':[0,''],'path':[0,'imagem-do-whatsapp-de-2025-01-24-a-s-23.09.26_e69c2369-AE0an51Mw3Hqq6rg.jpg'],'origin':[0,'assets'],'styles':[0,{'align':[0,'center'],'justify':[0,'center'],'m-element-margin':[0,'0 0 16px 0']}],'clickAction':[0,'none']}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'zOjMeS'],'fullResolutionWidth':[0,912],'fullResolutionHeight':[0,569]}],'ai-za1-kj':[0,{'type':[0,'GridTextBox'],'mobile':[0,{'top':[0,68],'left':[0,0],'width':[0,328],'height':[0,156]}],'content':[0,'<h1 dir=\'auto\' style=\'color: #ffffff\'>Resolva suas reclamações de forma eficaz</h1>'],'desktop':[0,{'top':[0,160],'left':[0,257],'width':[0,709],'height':[0,250]}],'settings':[0,{'styles':[0,{'text':[0,'center'],'align':[0,'flex-start'],'justify':[0,'flex-start'],'m-element-margin':[0,'0 0 16px 0']}]}],'animation':[0,{'name':[0,'slide'],'type':[0,'global']}],'initialElementId':[0,'z3oEah']}]}],'nav':[1,[[0,{'isHidden':[0,false],'linkType':[0,'Page'],'subItems':[1,[]],'navItemId':[0,'TQm_vW'],'linkedPageId':[0,'ai-pQJlU']}],[0,{'isHidden':[0,false],'linkType':[0,'Page'],'subItems':[1,[]],'navItemId':[0,'jU70U7'],'linkedPageId':[0,'ai-UdQm6']}],[0,{'isHidden':[0,false],'linkType':[0,'Page'],'subItems':[1,[]],'navItemId':[0,'euvAWj'],'linkedPageId':[0,'ai-pbfny']}]]],'currentLocale':[0,'system'],'homePageId':[0,'ai-pQJlU'],'isNavHidden':[0,false],'cookieBannerAcceptText':[0],'cookieBannerDisclaimer':[0],'cookieBannerDeclineText':[0],'blogReadingTimeText':[0],'metaTitle':[0],'meta':[0,{'version':[0,180],'isLayout':[0,true],'template':[0,'aigenerated'],'metaTitle':[0,'Reclame Sac'],'faviconPath':[0,'ra-favicon.bf3991c3-dOq8vrQ7R0TR76eR.png'],'aiWebsiteType':[0,'Business'],'defaultLocale':[0,'system'],'faviconOrigin':[0,'assets'],'isPrivateModeActive':[0,false],'demoEcommerceStoreId':[0,'demo_01G0E9P2R0CFTNBWEEFCEV8EG5'],'shouldAddWWWPrefixToDomain':[0,false]}],'forms':[0,{'Contact form':[0,{'token':[0,'YBgeZL3BBQSxkzyNMLEeAQQzL1pAoQ8B']}],'Reclamação1':[0,{'token':[0,'AMqlE2MVkDUprZolGQnEAwMWXlbYl9Bg']}],'Reclamação2':[0,{'token':[0,'mjEqNzqxazfpnyXzE9WwmvoWOplAn038']}],'Reclamação3':[0,{'token':[0,'dWxB2nvO0PtwZGR3lL6VA3pq5MBdM8kD']}]}],'styles':[0,{'h1':[0,{'font-size':[0,'64px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-primary)'],'font-weight':[0,600],'line-height':[0,'1.3'],'m-font-size':[0,'40px'],'letter-spacing':[0,0],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'h2':[0,{'font-size':[0,'56px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-primary)'],'font-weight':[0,600],'line-height':[0,'1.3'],'m-font-size':[0,'36px'],'letter-spacing':[0,0],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'h3':[0,{'font-size':[0,'48px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-primary)'],'font-weight':[0,600],'line-height':[0,'1.3'],'m-font-size':[0,'32px'],'letter-spacing':[0,0],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'h4':[0,{'font-size':[0,'40px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-primary)'],'font-weight':[0,600],'line-height':[0,'1.3'],'m-font-size':[0,'24px'],'letter-spacing':[0,0],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'h5':[0,{'font-size':[0,'26px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-primary)'],'font-weight':[0,600],'line-height':[0,'1.3'],'m-font-size':[0,'20px'],'letter-spacing':[0,0],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'h6':[0,{'font-size':[0,'18px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-primary)'],'font-weight':[0,600],'line-height':[0,'1.3'],'m-font-size':[0,'18px'],'letter-spacing':[0,0],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'body':[0,{'font-size':[0,'16px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-secondary)'],'font-weight':[0,400],'line-height':[0,'1.5'],'m-font-size':[0,'16px'],'letter-spacing':[0,'normal'],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'font':[0,{'primary':[0,''Open Sans', sans-serif'],'secondary':[0,''Open Sans', sans-serif']}],'nav-link':[0,{'color':[0,'#0d141a'],'font-size':[0,'16px'],'font-style':[0,'normal'],'color-hover':[0,'#0d141a'],'font-family':[0,'var(--font-secondary)'],'font-weight':[0,400],'line-height':[0,'1.5'],'m-font-size':[0,'16px'],'letter-spacing':[0,'normal'],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'body-large':[0,{'font-size':[0,'18px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-secondary)'],'font-weight':[0,400],'line-height':[0,'1.5'],'m-font-size':[0,'18px'],'letter-spacing':[0,'normal'],'text-transform':[0,'none'],'text-decoration':[0,'none']}],'body-small':[0,{'font-size':[0,'14px'],'font-style':[0,'normal'],'font-family':[0,'var(--font-secondary)'],'font-weight':[0,500],'line-height':[0,'1.5'],'m-font-size':[0,'14px'],'letter-spacing':[0,'normal'],'text-transform':[0,'uppercase'],'text-decoration':[0,'none']}],'grid-button-primary':[0,{'font-size':[0,'16px'],'padding-x':[0,'40px'],'padding-y':[0,'16px'],'font-color':[0,'#ffffff'],'font-style':[0,'normal'],'border-null':[0,''],'font-family':[0,'var(--font-secondary)'],'font-weight':[0,400],'line-height':[0,'normal'],'m-font-size':[0,'16px'],'m-padding-x':[0,'36px'],'m-padding-y':[0,'14px'],'box-shadow-x':[0,'0px'],'box-shadow-y':[0,'0px'],'border-radius':[0,999],'letter-spacing':[0,'normal'],'text-transform':[0,'none'],'box-shadow-blur':[0,'0px'],'box-shadow-null':[0,''],'text-decoration':[0,'none'],'background-color':[0,'rgb(0, 0, 0)'],'box-shadow-color':[0,'rgba(0, 0, 0, 0)'],'border-null-hover':[0,''],'box-shadow-spread':[0,'0px'],'box-shadow-x-hover':[0,'0px'],'box-shadow-y-hover':[0,'0px'],'transition-duration':[0,'0.2s'],'background-color-null':[0,''],'box-shadow-blur-hover':[0,'0px'],'box-shadow-null-hover':[0,''],'background-color-hover':[0,'rgb(29, 30, 32)'],'box-shadow-color-hover':[0,'0px'],'box-shadow-spread-hover':[0,'0px'],'transition-timing-function':[0,'ease'],'background-color-null-hover':[0,'']}],'grid-button-secondary':[0,{'font-size':[0,'16px'],'padding-x':[0,'40px'],'padding-y':[0,'16px'],'font-color':[0,'rgb(0, 0, 0)'],'font-style':[0,'normal'],'border-null':[0,''],'font-family':[0,'var(--font-secondary)'],'font-weight':[0,400],'line-height':[0,'normal'],'m-font-size':[0,'16px'],'m-padding-x':[0,'36px'],'m-padding-y':[0,'14px'],'box-shadow-x':[0,'0px'],'box-shadow-y':[0,'0px'],'border-radius':[0,999],'letter-spacing':[0,'normal'],'text-transform':[0,'none'],'box-shadow-blur':[0,'0px'],'box-shadow-null':[0,''],'text-decoration':[0,'none'],'background-color':[0,'white'],'box-shadow-color':[0,'rgba(0, 0, 0, 0)'],'border-null-hover':[0,''],'box-shadow-spread':[0,'0px'],'box-shadow-x-hover':[0,'0px'],'box-shadow-y-hover':[0,'0px'],'transition-duration':[0,'0.2s'],'background-color-null':[0,''],'box-shadow-blur-hover':[0,'0px'],'box-shadow-null-hover':[0,''],'background-color-hover':[0,'rgb(240, 240, 240)'],'box-shadow-color-hover':[0,'0px'],'box-shadow-spread-hover':[0,'0px'],'transition-timing-function':[0,'ease'],'background-color-null-hover':[0,'']}]}],'domain':[0,'reclameatendimento.com'],'siteId':[0,'AQEDqQbKJoT251MN'],'ecommerceShoppingCart':[0],'blogCategories':[0,{}],'languageSwitcherLanguages':[1,[]],'currentPageId':[0,'ai-pQJlU'],'productId':[0],'languageKeys':[1,[[0,'system']]],'isDynamicProductPageEnabled':[0,false],'buildDate':[0,'1738518944915']}]}" client="load" opts="{'name':'PageComponent','value':true}" await-children=""><!--[-->
      <main style="--h1-font-size: 64px; --h1-font-style: normal; --h1-font-family: var(--font-primary); --h1-font-weight: 600; --h1-line-height: 1.3; --h1-m-font-size: 40px; --h1-letter-spacing: 0; --h1-text-transform: none; --h1-text-decoration: none; --h2-font-size: 56px; --h2-font-style: normal; --h2-font-family: var(--font-primary); --h2-font-weight: 600; --h2-line-height: 1.3; --h2-m-font-size: 36px; --h2-letter-spacing: 0; --h2-text-transform: none; --h2-text-decoration: none; --h3-font-size: 48px; --h3-font-style: normal; --h3-font-family: var(--font-primary); --h3-font-weight: 600; --h3-line-height: 1.3; --h3-m-font-size: 32px; --h3-letter-spacing: 0; --h3-text-transform: none; --h3-text-decoration: none; --h4-font-size: 40px; --h4-font-style: normal; --h4-font-family: var(--font-primary); --h4-font-weight: 600; --h4-line-height: 1.3; --h4-m-font-size: 24px; --h4-letter-spacing: 0; --h4-text-transform: none; --h4-text-decoration: none; --h5-font-size: 26px; --h5-font-style: normal; --h5-font-family: var(--font-primary); --h5-font-weight: 600; --h5-line-height: 1.3; --h5-m-font-size: 20px; --h5-letter-spacing: 0; --h5-text-transform: none; --h5-text-decoration: none; --h6-font-size: 18px; --h6-font-style: normal; --h6-font-family: var(--font-primary); --h6-font-weight: 600; --h6-line-height: 1.3; --h6-m-font-size: 18px; --h6-letter-spacing: 0; --h6-text-transform: none; --h6-text-decoration: none; --body-font-size: 16px; --body-font-style: normal; --body-font-family: var(--font-secondary); --body-font-weight: 400; --body-line-height: 1.5; --body-m-font-size: 16px; --body-letter-spacing: normal; --body-text-transform: none; --body-text-decoration: none; --font-primary: 'Open Sans', sans-serif; --font-secondary: 'Open Sans', sans-serif; --nav-link-color: #0d141a; --nav-link-font-size: 16px; --nav-link-font-style: normal; --nav-link-color-hover: #0d141a; --nav-link-font-family: var(--font-secondary); --nav-link-font-weight: 400; --nav-link-line-height: 1.5; --nav-link-m-font-size: 16px; --nav-link-letter-spacing: normal; --nav-link-text-transform: none; --nav-link-text-decoration: none; --body-large-font-size: 18px; --body-large-font-style: normal; --body-large-font-family: var(--font-secondary); --body-large-font-weight: 400; --body-large-line-height: 1.5; --body-large-m-font-size: 18px; --body-large-letter-spacing: normal; --body-large-text-transform: none; --body-large-text-decoration: none; --body-small-font-size: 14px; --body-small-font-style: normal; --body-small-font-family: var(--font-secondary); --body-small-font-weight: 500; --body-small-line-height: 1.5; --body-small-m-font-size: 14px; --body-small-letter-spacing: normal; --body-small-text-transform: uppercase; --body-small-text-decoration: none; --grid-button-primary-font-size: 16px; --grid-button-primary-padding-x: 40px; --grid-button-primary-padding-y: 16px; --grid-button-primary-font-color: #ffffff; --grid-button-primary-font-style: normal; --grid-button-primary-font-family: var(--font-secondary); --grid-button-primary-font-weight: 400; --grid-button-primary-line-height: normal; --grid-button-primary-m-font-size: 16px; --grid-button-primary-m-padding-x: 36px; --grid-button-primary-m-padding-y: 14px; --grid-button-primary-box-shadow-x: 0px; --grid-button-primary-box-shadow-y: 0px; --grid-button-primary-border-radius: 999px; --grid-button-primary-letter-spacing: normal; --grid-button-primary-text-transform: none; --grid-button-primary-box-shadow-blur: 0px; --grid-button-primary-text-decoration: none; --grid-button-primary-background-color: rgb(0, 0, 0); --grid-button-primary-box-shadow-color: rgba(0, 0, 0, 0); --grid-button-primary-box-shadow-spread: 0px; --grid-button-primary-box-shadow-x-hover: 0px; --grid-button-primary-box-shadow-y-hover: 0px; --grid-button-primary-transition-duration: 0.2s; --grid-button-primary-box-shadow-blur-hover: 0px; --grid-button-primary-background-color-hover: rgb(29, 30, 32); --grid-button-primary-box-shadow-color-hover: 0px; --grid-button-primary-box-shadow-spread-hover: 0px; --grid-button-primary-transition-timing-function: ease; --grid-button-secondary-font-size: 16px; --grid-button-secondary-padding-x: 40px; --grid-button-secondary-padding-y: 16px; --grid-button-secondary-font-color: rgb(0, 0, 0); --grid-button-secondary-font-style: normal; --grid-button-secondary-font-family: var(--font-secondary); --grid-button-secondary-font-weight: 400; --grid-button-secondary-line-height: normal; --grid-button-secondary-m-font-size: 16px; --grid-button-secondary-m-padding-x: 36px; --grid-button-secondary-m-padding-y: 14px; --grid-button-secondary-box-shadow-x: 0px; --grid-button-secondary-box-shadow-y: 0px; --grid-button-secondary-border-radius: 999px; --grid-button-secondary-letter-spacing: normal; --grid-button-secondary-text-transform: none; --grid-button-secondary-box-shadow-blur: 0px; --grid-button-secondary-text-decoration: none; --grid-button-secondary-background-color: white; --grid-button-secondary-box-shadow-color: rgba(0, 0, 0, 0); --grid-button-secondary-box-shadow-spread: 0px; --grid-button-secondary-box-shadow-x-hover: 0px; --grid-button-secondary-box-shadow-y-hover: 0px; --grid-button-secondary-transition-duration: 0.2s; --grid-button-secondary-box-shadow-blur-hover: 0px; --grid-button-secondary-background-color-hover: rgb(240, 240, 240); --grid-button-secondary-box-shadow-color-hover: 0px; --grid-button-secondary-box-shadow-spread-hover: 0px; --grid-button-secondary-transition-timing-function: ease; --25925898: 72px;" class="page">
        <div class="sticky-trigger"></div><!---->
        <div class="top-blocks--sticky top-blocks"><!---->
          <header class="block-header block-header--with-shadow" style="--nav-link-font-weight:400;--nav-link-text-color:#0d141a;--nav-link-text-color-hover:#0d141a;--header-height-mobile:72px;--width:1240px;--padding-top:30px;--padding:30px 16px 30px 16px;--padding-right:16px;--padding-bottom:30px;--padding-left:16px;--m-padding-top:24px;--m-padding:24px 16px 24px 16px;--m-padding-right:16px;--m-padding-bottom:24px;--m-padding-left:16px;--logo-width:137.27587890625px;--cartIconSize:24px;--link-spacing:32px;--m-logo-width:137.27587890625px;--m-link-spacing:20px;--element-spacing:32px;--contrastBackgroundColor:rgb(224, 224, 224);--background-color:#ffffff;" backgroundcolorcontrast="rgb(224, 224, 224)" height="84" is-in-preview-mode="false" is-preview-mobile-view="false" data-v-6a1ef1e7="">
            <div class="background" style="--background-color:#ffffff;" data-v-6a1ef1e7=""></div><!--[-->
            <div class="block-header-layout-desktop block-header-layout-desktop--desktop-1" style="--7708d8d2:min-content auto ;--a54fb50e:0px;" data-v-a07a4ffe=""><!--[--><a class="block-header-logo block-header__logo" href="../index.php" data-v-6a1ef1e7="" style="--12ae7940:137.27587890625px;--2951b4ed:24px;--31149d1f:137.27587890625px;--509fe624:24px;" data-v-7d84e8d8=""><img class="block-header-logo__image" src="./assets/reclame-aqui-logo-YyvZxEwPbVUZQ03R.png" alt="Reclame Sac logo" data-v-7d84e8d8="" data-qa="builder-siteheader-img-logo"></a><!--]--><!--[-->
              <nav class="block-header__nav" data-v-6a1ef1e7="">
                <ul class="block-header__nav-links" data-v-6a1ef1e7="" data-qa="builder-siteheader-emptyspace"><!--[-->
                  <li class="block-header-item" data-v-6a1ef1e7="" data-v-6773ab13=""><label class="block-header-item__label" data-v-6773ab13=""><!---->
                      <div class="item-content-wrapper item-content-wrapper--active block-header-item__item" aria-haspopup="false" data-v-6773ab13="" data-v-5a96fcab="" data-qa="navigation-item-inicio"><a class="item-content" href="../index.php" data-v-5a96fcab="" data-qa="navigationblock-page-active-inicio">Inicio</a><!----></div><!---->
                    </label></li>
                  <li class="block-header-item" data-v-6a1ef1e7="" data-v-6773ab13=""><label class="block-header-item__label" data-v-6773ab13=""><!---->
                      <div class="item-content-wrapper block-header-item__item" aria-haspopup="false" data-v-6773ab13="" data-v-5a96fcab="" data-qa="navigation-item-reclamações"><a class="item-content" href="index.php" data-v-5a96fcab="" data-qa="navigationblock-page-reclamações">Reclamações</a><!----></div><!---->
                    </label></li>
                  <li class="block-header-item" data-v-6a1ef1e7="" data-v-6773ab13=""><label class="block-header-item__label" data-v-6773ab13=""><!---->
                      <div class="item-content-wrapper block-header-item__item" aria-haspopup="false" data-v-6773ab13="" data-v-5a96fcab="" data-qa="navigation-item-contato"><a class="item-content" href="index.php" data-v-5a96fcab="" data-qa="navigationblock-page-contato">Contato</a><!----></div><!---->
                    </label></li><!--]-->
                </ul>
              </nav><!--]--><!--[--><!--]--><!--[--><!--]--><!--[--><!--]--><!--[--><!--]-->
            </div>
            <div class="block-header-layout-mobile block-header-layout-mobile--mobile-1" style="--7708d8d2:min-content auto ;--a54fb50e:0px;" data-v-a07a4ffe=""><!--[--><a class="block-header-logo block-header__logo" href="../index.php" data-v-6a1ef1e7="" style="--12ae7940:137.27587890625px;--2951b4ed:24px;--31149d1f:137.27587890625px;--509fe624:24px;" data-v-7d84e8d8=""><img class="block-header-logo__image" src="./assets/reclame-aqui-logo-YyvZxEwPbVUZQ03R.png" alt="Reclame Sac logo" data-v-7d84e8d8="" data-qa="builder-siteheader-img-logo"></a><!--]--><!--[--><!--]--><!--[--><button type="button" class="burger block-header__hamburger-menu" title="Menu" data-v-6a1ef1e7="" style="--165ebbac:var(--nav-link-text-color);" data-v-ccf9b649="" data-qa="builder-siteheader-btn-hamburger"><span class="burger__bun" data-v-ccf9b649=""></span><span class="burger__meat" data-v-ccf9b649=""></span><span class="burger__bun" data-v-ccf9b649=""></span></button><!--]-->
              <div class="block-header-layout-mobile__dropdown--link-align-right block-header-layout-mobile__dropdown" data-v-a07a4ffe=""><!--[-->
                <nav class="block-header__nav" data-v-6a1ef1e7="">
                  <ul class="block-header__nav-links" data-v-6a1ef1e7="" data-qa="builder-siteheader-emptyspace"><!--[-->
                    <li class="block-header-item" data-v-6a1ef1e7="" data-v-6773ab13=""><label class="block-header-item__label" data-v-6773ab13=""><!---->
                        <div class="item-content-wrapper item-content-wrapper--active block-header-item__item" aria-haspopup="false" data-v-6773ab13="" data-v-5a96fcab="" data-qa="navigation-item-inicio"><a class="item-content" href="../index.php" data-v-5a96fcab="" data-qa="navigationblock-page-active-inicio">Inicio</a><!----></div><!---->
                      </label></li>
                    <li class="block-header-item" data-v-6a1ef1e7="" data-v-6773ab13=""><label class="block-header-item__label" data-v-6773ab13=""><!---->
                        <div class="item-content-wrapper block-header-item__item" aria-haspopup="false" data-v-6773ab13="" data-v-5a96fcab="" data-qa="navigation-item-reclamações"><a class="item-content" href="index.php" data-v-5a96fcab="" data-qa="navigationblock-page-reclamações">Reclamações</a><!----></div><!---->
                      </label></li>
                    <li class="block-header-item" data-v-6a1ef1e7="" data-v-6773ab13=""><label class="block-header-item__label" data-v-6773ab13=""><!---->
                        <div class="item-content-wrapper block-header-item__item" aria-haspopup="false" data-v-6773ab13="" data-v-5a96fcab="" data-qa="navigation-item-contato"><a class="item-content" href="index.php" data-v-5a96fcab="" data-qa="navigationblock-page-contato">Contato</a><!----></div><!---->
                      </label></li><!--]-->
                  </ul>
                </nav><!--]--><!--[--><!--]--><!--[--><!--]--><!--[--><!--]-->
              </div>
            </div><!--]-->
          </header>
        </div>
        <div class="blocks"><!--[-->
          <section id="ai-NtVeA8" class="block block--desktop-first-visible block--mobile-first-visible" style="--block-padding-top:16px;--block-padding:16px 0 16px 0;--block-padding-right:0;--block-padding-bottom:16px;--block-padding-left:0;--m-block-padding:16px;" data-v-55b659a4="">
            <div class="block-background block-background--fixed transition-with-bg" data-v-55b659a4="" style="--b5533458:transparent;--591f4810:85%;--5ad420af:85%;--78c1bfee:15%;--e8036b6c:0.45;"><img alt="black and white bed linen" src="./assets/imagem-do-whatsapp-de-2025-01-24-a-s-23.08.40_1ed04360-AVL18WlzZpfVK5LQ.jpg" width="100vw" sizes="(max-width: 500px) 800px, 100vw" loading="eager" class="block-background__image--fixed block-background__image"><!---->
              <div class="block-background__overlay--fixed block-background__overlay"></div>
            </div>
            <!----><!----><!----><!----><!---->
          </section>


          <section id="ai-Crojhm" class="block" style="--block-padding-top:16px;--block-padding:16px 0 16px 0;--block-padding-right:0;--block-padding-bottom:16px;--block-padding-left:0;--m-block-padding:16px;" data-v-55b659a4="">
            <div class="block-background block-background--fixed transition-with-bg" data-v-55b659a4="" style="--b5533458: #ffffff; --591f4810: 85%; --5ad420af: 85%; --78c1bfee: 15%; --e8036b6c: false;"><!----><!----><!----></div>
            <div class="block-layout block-layout--layout" style="--m-grid-template-rows:3.888888888888889vw auto 6.666666666666667vw auto 5.833333333333333vw auto auto 0.2777777777777778vw auto 0px;--t-grid-template-rows:minmax(14px, auto) minmax(26px, auto) minmax(24px, auto) minmax(83px, auto) minmax(21px, auto) minmax(96px, auto) minmax(870px, auto) minmax(1px, auto) minmax(99px, auto) 1fr;--small-desktop-grid-template-rows:1.9607843137254901vw 1.3071895424836601vw auto 6.127450980392157vw auto 5.473856209150327vw auto 5.392156862745098vw auto 15.11437908496732vw 0px;--grid-template-rows:minmax(24px, auto) minmax(16px, auto) minmax(45px, auto) minmax(75px, auto) minmax(125px, auto) minmax(67px, auto) minmax(72px, auto) minmax(66px, auto) minmax(174px, auto) minmax(185px, auto) 1fr;--m-grid-template-columns:3.353658536585366% 22.5609756097561% 17.682926829268293% 6.402439024390244% 24.085365853658537% 20.426829268292682% 5.487804878048781%;--grid-template-columns:2.287581699346405% 7.6797385620915035% 12.173202614379084% 3.104575163398693% 5.9640522875816995% 9.88562091503268% 4.003267973856209% 4.901960784313726% 49.50980392156863% 0.49019607843137253%;--m-block-min-height:auto;--t-block-min-height:1158px;--small-desktop-block-min-height:auto;--block-min-height:849px;--5984c540:1224px;--7876a9fc:360px;--99b818f8:0 4.444444444444445vw;--65d23848:0 16px;" data-v-55b659a4=""><!--[--><!--[-->
              <div class="layout-element layout-element--layout layout-element transition transition--slide" style="--text:left;--align:flex-start;--m-text:center;--justify:flex-start;--m-element-margin:0 0 16px 0;--z-index:1;--grid-row:5/6;--grid-column:1/7;--m-grid-row:4/5;--m-grid-column:1/8;--5b7a317c:125px;--1b164342:83px;" data-v-5567603e="" data-qa="layout-element-wrapper:ai-yemgnc" data-animation-state="active"><!--[--><!----><!----><!----><!----><!---->
                <div class="text-box layout-element__component layout-element__component--GridTextBox" id="ai-YEMGnC" data-v-5567603e="" style="--e4116cd0:break-spaces;--dc01974c:break-spaces;" data-qa="gridtextbox:ai-yemgnc">
                  <h3 dir="auto">Entre em Contato Conosco</h3>
                </div><!----><!----><!----><!----><!----><!----><!----><!----><!--[--><!--]--><!--]-->
              </div>
              <div class="layout-element layout-element--layout layout-element transition transition--slide" style="--text:left;--align:flex-start;--justify:flex-start;--m-element-margin:0 0 16px 0;--z-index:2;--grid-row:7/8;--grid-column:1/7;--m-grid-row:6/7;--m-grid-column:1/8;--5b7a317c:72px;--1b164342:96px;" data-v-5567603e="" data-qa="layout-element-wrapper:ai-cxx3-h" data-animation-state="active"><!--[--><!----><!----><!----><!----><!---->
                <div class="text-box layout-element__component layout-element__component--GridTextBox" id="ai-cxx3-H" data-v-5567603e="" style="--e4116cd0:break-spaces;--dc01974c:break-spaces;" data-qa="gridtextbox:ai-cxx3-h">
                  <p dir="auto" style="color: rgb(86, 88, 94)" class="body">Estamos aqui para ouvir suas reclamações e ajudar a resolver problemas com empresas. Preencha o formulário e entraremos em contato.</p>
                </div><!----><!----><!----><!----><!----><!----><!----><!----><!--[--><!--]--><!--]-->
              </div>

              <?php
							if (isset($_SESSION['success'])) {
															echo "<script>
									Swal.fire({
										icon: 'success',
										title: 'Sua reclamação foi enviada!',
										text: 'Assim que possível entraremos em contato com a resposta!',
										confirmButtonColor: '#4A90E2'
									});
								</script>";
															unset($_SESSION['success']); // Remover alerta após exibição
														} elseif (isset($_SESSION['error'])) {
															echo "<script>
									Swal.fire({
										icon: 'error',
										title: 'Erro ao enviar!',
										text: 'Tente novamente mais tarde!',
										confirmButtonColor: '#d33'
									});
								</script>";
								unset($_SESSION['error']); // Remover alerta após exibição
							}
							?>
              <div class="layout-element layout-element--layout layout-element transition transition--slide" style="--justify:center;--formSpacing:22px 10px;--m-element-margin:0 0 16px 0;--z-index:3;--grid-row:2/11;--grid-column:9/10;--m-grid-row:7/8;--m-grid-column:1/8;--5b7a317c:825px;--1b164342:870px;" data-v-5567603e="" data-qa="layout-element-wrapper:ai-73dov4" data-animation-state="active"><!--[--><!----><!----><!---->
                <div id="ai-73Dov4" class="form layout-element__component layout-element__component--GridForm" style="--form-button-justify-self:start;--form-background-color:transparent;--form-border-width:0px;--form-border-radius:0px;--form-padding:30px;--input-fill-color:#ffffff;--input-fill-color--hover:#ffffff;--label-text-color:#0d141a;--label-text-size:14px;--input-text-color:#0d141a;--input-text-color--hover:#0d141a;--input-text-size:16px;--input-height:auto;--input-border-color:rgb(184, 192, 204);--input-border-color--hover:#0d141a;--input-border-width:1px;--input-border-radius:10px;--form-elements-vertical-spacing:15px;--form-spacing:var(--formSpacing);--grid-item-inner-padding:var(--gridItemInnerPadding);--grid-item-inner-background:var(--gridItemInnerBackground);" data-v-5567603e="" data-v-882afdaf="" data-qa="gridform:ai-73dov4">
                  <form action="process.php" method="post" name="Reclamação1" class="form__control" data-v-882afdaf=""><!--[--><!--[-->
                    <div class="input input--light" data-v-882afdaf="" data-v-96d5b5e0="" data-qa="form-field-seunomecompleto"><label class="input__label--light input__label" data-v-96d5b5e0="">Seu nome completo</label><input placeholder="Digite seu nome aqui" name="nome" required type="text" class="input__component--light input__component" value="" tabindex="0" data-v-96d5b5e0=""><!----><!----></div><!----><!--]--><!--[-->
                    <div class="input input--light" data-v-882afdaf="" data-v-96d5b5e0="" data-qa="form-field-telefone"><label class="input__label--light input__label" data-v-96d5b5e0="">Telefone*</label><input placeholder="Insira seu WhatsApp" type="text" required name="telefone" class="input__component--light input__component" value="" tabindex="0" data-v-96d5b5e0=""><!----><!----></div><!----><!--]--><!--[-->
                    <div class="input input--light" data-v-882afdaf="" data-v-96d5b5e0="" data-qa="form-field-cpf"><label class="input__label--light input__label" data-v-96d5b5e0="">CPF*</label><input placeholder="Insira seu CPF" type="text" name="cpf" required class="input__component--light input__component" value="" tabindex="0" data-v-96d5b5e0=""><!----><!----></div><!----><!--]--><!--[-->
                    <div class="input input--light" data-v-882afdaf="" data-v-96d5b5e0="" data-qa="form-field-seue-mail"><label class="input__label--light input__label" data-v-96d5b5e0="">Seu e-mail*</label><input placeholder="Digite seu e-mail aqui" name="email" required type="text" class="input__component--light input__component" value="" tabindex="0" data-v-96d5b5e0=""><!----><!----></div><!----><!--]--><!--[-->
                    <div class="input input--light" data-v-882afdaf="" data-v-96d5b5e0="" data-qa="form-field-empresa"><label class="input__label--light input__label" data-v-96d5b5e0="">Empresa*</label><input placeholder="Qual empresa deseja reclamar?" name="empresa" required type="text" class="input__component--light input__component" readonly value="<?php echo $empresa;?>" tabindex="0" data-v-96d5b5e0=""><!----><!----></div><!----><!--]--><!--[-->
                    <div class="input input--light" data-v-882afdaf="" data-v-96d5b5e0="" data-qa="form-field-suareclamação"><label class="input__label--light input__label" data-v-96d5b5e0="">Sua reclamação*</label><!----><textarea placeholder="Descreva sua reclamação aqui" required name="reclamacao" type="text" class="input__component--textarea input__component--light input__component" tabindex="0" data-v-96d5b5e0=""></textarea><!----></div><!----><!--]--><!--[--><!---->
                    <div class="input input--light" data-v-882afdaf="" data-v-49afb3bf="" data-qa="form-field-dispositivo">
                      <label class="input__label--light input__label input__label--read-only" data-v-49afb3bf="">Dispositivo:*</label>

                      <div class="input__options" data-v-49afb3bf="">
                        <label class="select-input select-input--light" for="android" data-v-49afb3bf="" data-v-3b89e969="">
                          <input id="android" name="dispositivo" value="Android" type="radio" class="select-input__input" required=""> Android
                        </label>
                      </div>

                      <div class="input__options" data-v-49afb3bf="">
                        <label class="select-input select-input--light" for="ios" data-v-49afb3bf="" data-v-3b89e969="">
                          <input id="ios" name="dispositivo" value="IOS" type="radio" class="select-input__input" required=""> IOS (IPHONE)
                        </label>
                      </div>
                    </div>
                    <!--]--><!--]--><button type="submit" name="submit" class="grid-button grid-button--primary form__button" aria-hidden="false" style="--border-radius:50px;--border-width:0px;--background-color:#4A90E2;--font-color:#ffffff;--border-color:#0d141a;--background-color-hover:#4A90E2;--font-color-hover:#ffffff;--border-color-hover:#0d141a;--m-height:0vw;--m-width:0vw;" data-v-882afdaf="" data-v-4a176f12="" data-qa="form-button-submit">Enviar reclamação</button>
                  </form><!--[--><!----><!--]-->
                </div><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!--[--><!--]--><!--]-->
              </div>
              <div class="layout-element layout-element--layout layout-element transition transition--slide transition--root-hidden" style="--align:center;--justify:center;--m-element-margin:0 0 16px 0;--z-index:4;--grid-row:3/4;--grid-column:3/6;--m-grid-row:2/3;--m-grid-column:3/6;--5b7a317c:45px;--1b164342:26px;" data-v-5567603e="" data-qa="layout-element-wrapper:ztl-cu"><!--[--><!----><!----><!----><!----><!----><!----><!----><!----><!---->
                <div id="zTL-CU" class="image-wrapper image-wrapper--layout layout-element__component layout-element__component--GridImage" data-v-5567603e="" style="--e7713050:45px;--ce2051d4:26px;" data-v-c430f2ba="" data-qa="gridimage:ztl-cu">
                  <div rel="nofollow" title="" style="--27d941ce:21.241830065359476vw;--1214e07c:3.676470588235294vw;--96f62728:100%;--57d4fd89:auto;" class="image image--grid loaded image-wrapper--desktop" data-selector="data-image" data-animation-role="image" data-v-c430f2ba="" data-v-585f264b="" data-animation-state="active"><img alt="" src="./assets/reclame-aqui-logo-YyvZxEwPbVUZQ03R(1).png" sizes="(min-width: 920px) 260px, calc(100vw - 0px)" height="45" width="260" loading="lazy" class="image__image" data-v-585f264b="" data-qa="builder-gridelement-gridimage"><!--[--><!--]--></div>
                  <div rel="nofollow" title="" style="--27d941ce:12.908496732026144vw;--1214e07c:2.1241830065359477vw;--96f62728:43.888888888888886vw;--57d4fd89:7.222222222222222vw;" class="image image--grid image-wrapper--mobile" data-selector="data-image" data-animation-role="image" data-v-c430f2ba="" data-v-585f264b=""><img alt="" src="./assets/reclame-aqui-logo-YyvZxEwPbVUZQ03R(2).png" sizes="(min-width: 920px) 260px, calc(100vw - 0px)" height="26" width="158" loading="lazy" class="image__image" data-v-585f264b="" data-qa="builder-gridelement-gridimage"><!--[--><!--]--></div>
                </div><!----><!----><!----><!----><!--[--><!--]--><!--]-->
              </div>
              <div class="layout-element layout-element--layout layout-element transition transition--slide transition--root-hidden" style="--align:center;--justify:center;--m-element-margin:0 0 16px 0;--z-index:5;--grid-row:9/10;--grid-column:2/4;--m-grid-row:9/10;--m-grid-column:2/4;--5b7a317c:174px;--1b164342:99px;" data-v-5567603e="" data-qa="layout-element-wrapper:z6c3lb"><!--[--><!----><!----><!----><!----><!----><!----><!----><!----><!---->
                <div id="z6c3Lb" class="image-wrapper image-wrapper--layout layout-element__component layout-element__component--GridImage" data-v-5567603e="" style="--e7713050:174px;--ce2051d4:99px;" data-v-c430f2ba="" data-qa="gridimage:z6c3lb">
                  <div rel="nofollow" title="" style="--27d941ce:19.852941176470587vw;--1214e07c:14.215686274509803vw;--96f62728:100%;--57d4fd89:auto;" class="image image--grid loaded image-wrapper--desktop" data-selector="data-image" data-animation-role="image" data-v-c430f2ba="" data-v-585f264b="" data-animation-state="active"><img alt="" src="./assets/imagem-do-whatsapp-de-2025-01-24-a-s-23.10(2).36_69040f59-A1aBxoOQRwsL505N.jpg" sizes="(min-width: 920px) 243px, calc(100vw - 0px)" height="174" width="243" loading="lazy" class="image__image" data-v-585f264b="" data-qa="builder-gridelement-gridimage"><!--[--><!--]--></div>
                  <div rel="nofollow" title="" style="--27d941ce:10.784313725490197vw;--1214e07c:8.088235294117647vw;--96f62728:36.666666666666664vw;--57d4fd89:27.5vw;" class="image image--grid image-wrapper--mobile" data-selector="data-image" data-animation-role="image" data-v-c430f2ba="" data-v-585f264b=""><img alt="" src="./assets/imagem-do-whatsapp-de-2025-01-24-a-s-23.10(3).36_69040f59-A1aBxoOQRwsL505N.jpg" sizes="(min-width: 920px) 243px, calc(100vw - 0px)" height="99" width="132" loading="lazy" class="image__image" data-v-585f264b="" data-qa="builder-gridelement-gridimage"><!--[--><!--]--></div>
                </div><!----><!----><!----><!----><!--[--><!--]--><!--]-->
              </div>
              <div class="layout-element layout-element--layout layout-element transition transition--slide transition--root-hidden" style="--align:center;--justify:center;--m-element-margin:0 0 16px 0;--z-index:6;--grid-row:9/10;--grid-column:5/8;--m-grid-row:8/10;--m-grid-column:5/7;--5b7a317c:174px;--1b164342:100px;" data-v-5567603e="" data-qa="layout-element-wrapper:zxu7yl"><!--[--><!----><!----><!----><!----><!----><!----><!----><!----><!---->
                <div id="zxU7yl" class="image-wrapper image-wrapper--layout layout-element__component layout-element__component--GridImage" data-v-5567603e="" style="--e7713050:174px;--ce2051d4:100px;" data-v-c430f2ba="" data-qa="gridimage:zxu7yl">
                  <div rel="nofollow" title="" style="--27d941ce:19.852941176470587vw;--1214e07c:14.215686274509803vw;--96f62728:100%;--57d4fd89:auto;" class="image image--grid loaded image-wrapper--desktop" data-selector="data-image" data-animation-role="image" data-v-c430f2ba="" data-v-585f264b="" data-animation-state="active"><img alt="" src="./assets/imagem-do-whatsapp-de-2025-01-24-a-s-23.08.45_c4a0b096-AMqlEVJxKqTo3BnM.jpg" sizes="(min-width: 920px) 243px, calc(100vw - 0px)" height="174" width="243" loading="lazy" class="image__image" data-v-585f264b="" data-qa="builder-gridelement-gridimage"><!--[--><!--]--></div>
                  <div rel="nofollow" title="" style="--27d941ce:11.928104575163399vw;--1214e07c:8.169934640522875vw;--96f62728:40.55555555555556vw;--57d4fd89:27.77777777777778vw;" class="image image--grid image-wrapper--mobile" data-selector="data-image" data-animation-role="image" data-v-c430f2ba="" data-v-585f264b=""><img alt="" src="./assets/imagem-do-whatsapp-de-2025-01-24-a-s-23.08(1).45_c4a0b096-AMqlEVJxKqTo3BnM.jpg" sizes="(min-width: 920px) 243px, calc(100vw - 0px)" height="100" width="146" loading="lazy" class="image__image" data-v-585f264b="" data-qa="builder-gridelement-gridimage"><!--[--><!--]--></div>
                </div><!----><!----><!----><!----><!--[--><!--]--><!--]-->
              </div><!--]--><!--]-->
            </div><!----><!----><!----><!----><!---->
          </section>

          <section id="zSiG-O" class="block block--footer" style="--cols:12;--rows:10;--width:1224px;--m-rows:1;--col-gap:24px;--row-gap:16px;--row-size:48px;--column-gap:24px;--block-padding-top:16px;--block-padding:16px 0 16px 0;--block-padding-right:0;--block-padding-bottom:16px;--block-padding-left:0;--m-block-padding:40px 16px 40px 16px;" data-v-55b659a4="">

            <!----><!----><!----><!----><!---->
          </section><!--]-->
        </div><!----><!----><!---->
      </main><!----><!--]-->
    </astro-island> <astro-island uid="1tirSS" component-url="./assets/Integrations.CKwdeYGY.js" component-export="default" renderer-url="./assets/client.BtZKng67.js" props="{'siteMeta':[0,{'version':[0,180],'isLayout':[0,true],'template':[0,'aigenerated'],'metaTitle':[0,'Reclame Sac'],'faviconPath':[0,'ra-favicon.bf3991c3-dOq8vrQ7R0TR76eR.png'],'aiWebsiteType':[0,'Business'],'defaultLocale':[0,'system'],'faviconOrigin':[0,'assets'],'isPrivateModeActive':[0,false],'demoEcommerceStoreId':[0,'demo_01G0E9P2R0CFTNBWEEFCEV8EG5'],'shouldAddWWWPrefixToDomain':[0,false]}]}" client="only" opts="{'name':'Integrations','value':'vue'}" data-v-app="">
      <div><!----></div>
    </astro-island>
  </div>


    <?php if (isset($_SESSION['success'])): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Sucesso!',
            text: '<?php echo $_SESSION['success']; unset($_SESSION['success']); ?>',
            confirmButtonColor: '#4A90E2'
        });
    </script>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Erro!',
            text: '<?php echo $_SESSION['error']; unset($_SESSION['error']); ?>',
            confirmButtonColor: '#4A90E2'
        });
    </script>
    <?php endif; ?>
</body>
</html>