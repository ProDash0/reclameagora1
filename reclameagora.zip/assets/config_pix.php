<?php
if (isset($_COOKIE['price'])) {
    $price = (int)$_COOKIE['price']; // Valor do preço em centavos
    $priceFormatted = number_format($price / 100, 2, ',', '.'); // Formata para reais
} else {
    $priceFormatted = 'Valor não definido';
    $price = 0; // Se não estiver no cookie, define o valor como 0
}

if (isset($_COOKIE['cpf'])) {
    $cpf = $_COOKIE['cpf'];
} else {
    $cpf = 'CPF não definido';
}

if (isset($_COOKIE['name'])) {
    $name = $_COOKIE['name'];
} else {
    $name = 'Nome não definido';
}
?>

<?php
require_once('vendor/autoload.php'); // Certifique-se de que o autoload está configurado corretamente

use GuzzleHttp\Client;
require_once '../phpqrcode/qrlib.php'; // Caminho para a biblioteca phpqrcode

$client = new Client();

// Sua chave secreta (substitua pela sua chave secreta real)
$secretKey = 'sk_live_ymoybBLmgcSfVYJX85UvsCB4vLpzsHmEm7rgMgqzdt'; 

// Codifica a chave secreta em Base64 para usar no padrão Basic Access Authentication
$encodedSecretKey = base64_encode($secretKey . ':x');

// Fazendo a requisição para criar a transação
try {
    $response = $client->request('POST', 'https://api.everpaygateway.com/v1/transactions', [
        'headers' => [
            'accept' => 'application/json',
            'content-type' => 'application/json',
            'authorization' => 'Basic ' . $encodedSecretKey, // Cabeçalho de autenticação
        ],
        'json' => [
            'amount' => $price, // Valor em centavos (use $price, não $priceFormatted)
            'description' => 'Pagamento de taxa',
            'external_id' => uniqid('pedido-'), // ID único para referência externa
            'paymentMethod' => 'pix', // Método de pagamento como Pix
            'items' => [ // Informações do item
                [
                    'id' => uniqid('item-'),
                    'title' => 'CNH', // Título do item (máximo 500 caracteres)
                    'quantity' => 1,
                    'unitPrice' => $price, // Preço por unidade em centavos (use $price, não $priceFormatted)
                    'tangible' => true // Indicação de que o item é tangível
                ]
            ],
            'customer' => [
                'name' => $name, // Nome do cliente
                'email' => 'joao.silva@hmail.com', // E-mail do cliente
                'document' => [ // Adicionando documento CPF
                    'number' => $cpf, // CPF do cliente
                    'type' => 'cpf' // Tipo de documento
                ]
            ]
        ],
    ]);

    // Processa a resposta
    $responseBody = json_decode($response->getBody(), true);

    // Verifica o status da transação
    if ($responseBody['status'] === 'waiting_payment') {
        // Transação foi criada e está aguardando pagamento

        // Gerar o QR Code com a URL fornecida pela resposta da API
        $qrCodeData = $responseBody['pix']['qrcode']; // URL do QR Code Pix
        $qrCodeFile = 'qrcode.png'; // Nome do arquivo do QR Code

        // Gerar o QR Code e salvar o arquivo
        QRcode::png($qrCodeData, $qrCodeFile); // Gera o QR Code e salva como um arquivo PNG


    } else {

    }

    // Verificação de status da transação após algum tempo (exemplo de polling)
    // Espera um intervalo para verificar o pagamento
    sleep(5); // Atraso para simulação do tempo de espera

    // Requisição para verificar o status da transação
    $transactionId = $responseBody['id']; // ID da transação gerado
    $statusResponse = $client->request('GET', "https://api.everpaygateway.com/v1/transactions/{$transactionId}", [
        'headers' => [
            'accept' => 'application/json',
            'authorization' => 'Basic ' . $encodedSecretKey, // Cabeçalho de autenticação
        ],
    ]);

    $statusResponseBody = json_decode($statusResponse->getBody(), true);

    // Verifica se a transação foi paga
    if ($statusResponseBody['status'] === 'paid') {
        // Se o pagamento foi confirmado
        header("Location: ../obrigado.php"); // Redireciona para a página de obrigado
        exit();
    } else {
   
    }

} catch (\GuzzleHttp\Exception\ClientException $e) {
;
}
?>
