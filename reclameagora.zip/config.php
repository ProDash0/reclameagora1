<?php
// Enable error reporting for debugging on localhost
if ($_SERVER['REMOTE_ADDR'] === '127.0.0.1' || $_SERVER['REMOTE_ADDR'] === '::1') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

// Global Configuration
$baseDir = dirname(__FILE__);
define('DATA_PATH', $baseDir . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'reclamacoes.json');
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'admin123'); // User should change this

// Create data directory if it doesn't exist
$dataDir = $baseDir . DIRECTORY_SEPARATOR . 'data';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0777, true);
}

// Ensure JSON file exists and is writable
if (!file_exists(DATA_PATH)) {
    file_put_contents(DATA_PATH, json_encode([]));
}

if (!is_writable(DATA_PATH)) {
    @chmod(DATA_PATH, 0666);
}

function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function get_reclamacoes() {
    if (!file_exists(DATA_PATH)) return [];
    $content = file_get_contents(DATA_PATH);
    return json_decode($content, true) ?: [];
}

function save_reclamacao($data) {
    try {
        $reclamacoes = get_reclamacoes();
        $data = sanitize($data); // Sanitize all input
        $data['id'] = uniqid('rec_', true);
        $data['data_envio'] = date('Y-m-d H:i:s');
        $reclamacoes[] = $data;
        
        $json = json_encode($reclamacoes, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($json === false) return false;
        
        return file_put_contents(DATA_PATH, $json, LOCK_EX) !== false;
    } catch (Exception $e) {
        return false;
    }
}

function delete_reclamacao($id) {
    try {
        $reclamacoes = get_reclamacoes();
        $reclamacoes = array_filter($reclamacoes, function($item) use ($id) {
            return (isset($item['id']) ? $item['id'] : '') !== $id;
        });
        
        $json = json_encode(array_values($reclamacoes), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($json === false) return false;

        return file_put_contents(DATA_PATH, $json, LOCK_EX) !== false;
    } catch (Exception $e) {
        return false;
    }
}

function redirect($url) {
    if (strpos($url, 'http') !== 0 && $url[0] !== '/') {
        // If relative, try to make it work better on localhost
        $scriptPath = dirname($_SERVER['SCRIPT_NAME']);
        if ($scriptPath === DIRECTORY_SEPARATOR || $scriptPath === '/') {
            $url = '/' . $url;
        }
    }
    header("Location: $url");
    exit;
}

// Ensure session save path is writable on localhost if needed
if (ini_get('session.save_handler') == 'files') {
    $sessionPath = session_save_path();
    if ($sessionPath && !is_writable($sessionPath)) {
        $localSession = $baseDir . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'sessions';
        if (!is_dir($localSession)) mkdir($localSession, 0777, true);
        session_save_path($localSession);
    }
}
?>
