<?php
session_start();
require_once 'config.php';
?>
<!DOCTYPE html>

<html lang="pt-BR">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta property="og:title" content="Reclame Aqui - Pesquise antes de comprar. Reclame. Resolva">
  <meta name="description" content="Pesquise reputação de empresas antes de comprar. Se tiver problema, reclame e resolva rápido. Toda empresa tem problema, boa é aquela que resolve.">
  <meta property="og:description" content="Pesquise reputação de empresas antes de comprar. Se tiver problema, reclame e resolva rápido. Toda empresa tem problema, boa é aquela que resolve.">
  <meta property="og:image" content="./assets/reclameaqui-logo-34d55283afa63ded0616a3e268891ba4.jpg">
  <meta property="og:type" content="website">


  <link rel="icon" href="./assets/favicon.ico" type="image/x-icon">
  <link rel="shortcut icon" href="./assets/favicon.ico" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.googleapis.com/">
  <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">

  <link rel="stylesheet" href="./assets/css2" as="style">
  <title>Reclame Aqui - Pesquise antes de comprar. Reclame. Resolva</title>



  <link rel="icon" href="./assets/favicon.ico" type="image/x-icon">
  <link rel="shortcut icon" href="./assets/favicon.ico" type="image/x-icon">








  <link rel="stylesheet" href="./assets/style(1).css">
  <link rel="stylesheet" href="./assets/style(2).css">
  <link rel="stylesheet" href="./assets/index.090364b9.css">
  <link rel="stylesheet" href="./assets/RankingSegment.ebd88924.css">
  <link rel="stylesheet" href="./assets/design_system.css">
</head>
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-17024935081"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-17024935081');
</script>
<body class="vsc-initialized">









  <div id="header" class="astro-3EF6KSR2">
    <div>
      <div data-testid="complete-header">
        <div id="desktop-header">
          <div class="lg:pb-[69px] relative z-40">
            <header class="hide-in-mobile svelte-14e248y fixed">
              <div id="header-desktop-container" class="flex max-w-full lg:max-w-[1100px] m-auto items-center gap-x-8 box-border justify-start"><a data-google-interstitial="false" href="https://www.reclameaqui.com.br/" class="ra-logo svelte-14e248y" title="Logotipo cabeçalho ReclameAQUI" data-testid="brand"></a>
                <div class="search-container relative flex flex-1 items-center h-[40px] w-[40px] border-solid border border-pickles rounded px-[16px] svelte-14e248y"><button class="border-none bg-transparent">
                    <icon class="block w-6 h-6 text-[#02793e]"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                        <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
                      </svg></icon>
                  </button> <input id="search-input" placeholder="O que você procura?" class="search svelte-14e248y" type="text" data-testid="search-input">
                  <div class="search-actions-wrapper flex gap-4"> <button class="voice-btn svelte-15gmm4n" type="button" title="Busca por voz" id="ra_search_microphone_click" aria-details="Botão que ativa a gravação de sua fala, permitindo que conversemos e transcrevamos suas palavras em texto para facilitar a busca."></button> </div>
                </div>
                <div class="actions flex gap-x-6"><button data-google-interstitial="false" class="auth bg-white text-pickles svelte-14e248y" id="home_menu_cta_entrar" type="button" title="Entrar" data-testid="btn-enter">Entrar</button> <a data-google-interstitial="false" class="auth bg-pickles text-white svelte-14e248y" id="home_menu_cta_cadastrar" title="Cadastrar" href="https://www.reclameaqui.com.br/cadastro" data-testid="btn-register">Cadastrar</a></div>
                <div></div>
              </div>
            </header>
          </div>
          <nav class="hide-in-mobile top-0 w-full py-1 border-solid border-t-0 border-l-0 border-r-0 border-b border-iron bg-white">
            <ul class="lg:max-w-[1100px] m-auto flex gap-2 justify-between pl-0">
              <li class="relative flex items-center"><button title="Para você - Reclame Aqui" class="flex items-center gap-x-2 text-steel text-base p-2 rounded-lg ease-in-out duration-100 bg-transparent border-none hover:bg-green-150 hover:font-semibold hover:text-green-900 focus:bg-green-150 focus:font-semibold focus:text-green-900 svelte-qk5gqz">Para você <div class="w-4 h-4" style="background-image: url(./assets/chevron-down.svg)"></div></button> </li>
              <li class="relative flex items-center"><button title="Melhores empresas" class="flex items-center gap-x-2 text-steel text-base p-2 rounded-lg ease-in-out duration-100 bg-transparent border-none hover:bg-green-150 hover:font-semibold hover:text-green-900 focus:bg-green-150 focus:font-semibold focus:text-green-900 svelte-qk5gqz">Melhores empresas <div class="w-4 h-4" style="background-image: url(./assets/chevron-down.svg)"></div></button> </li>
              <li class="relative flex items-center"><a data-google-interstitial="false" class="flex items-center text-base p-2 rounded-lg ease-in-out duration-100 link-style svelte-1p7j37q" href="https://www.reclameaqui.com.br/detector-site/" title="Detector de Site Confiável - Reclame Aqui" target="_self">Detector de Site Confiável </a> </li>
              <li class="relative flex items-center"><a data-google-interstitial="false" class="flex items-center text-base p-2 rounded-lg ease-in-out duration-100 link-style svelte-1p7j37q" href="https://www.reclameaqui.com.br/compare/" title="Compare - Reclame Aqui" target="_self">Compare </a> </li>
              <li class="relative flex items-center"><a data-google-interstitial="false" class="flex items-center text-base p-2 rounded-lg ease-in-out duration-100 link-style svelte-1p7j37q" href="https://www.reclameaqui.com.br/descontos/" title="Descontos - Reclame Aqui" target="_self">Descontos </a> </li>
              <li class="relative flex items-center"><button title="Para empresas" class="flex items-center gap-x-2 text-steel text-base p-2 rounded-lg ease-in-out duration-100 bg-transparent border-none hover:bg-green-150 hover:font-semibold hover:text-green-900 focus:bg-green-150 focus:font-semibold focus:text-green-900 svelte-qk5gqz">Para empresas <div class="w-4 h-4" style="background-image: url(./assets/chevron-down.svg)"></div></button> </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>

  <style>
    astro-island,
    astro-slot,
    astro-static-slot {
      display: contents
    }
  </style><astro-island uid="B4esQ" component-export="default" props="{}" client="load" opts="{'name':'BannerBF','value':true}">
    <div class="w-screen overflow-hidden ra-banner-black-friday pb-8 svelte-c64y1t">
      <div class="flex justify-center my-4"><img src="./assets/Principal-Black 1.svg" alt="Logo ReclameAQUI - Black Friday" class="ra-black-friday-logo svelte-c64y1t"></div>
      <div class="ra-background-green flex flex-col gap-3 p-4 svelte-c64y1t">
        <h3 class="text-white text-[16px] md:text-lg font-bold text-center">Descubra se o site onde você viu <br>aquela oferta imperdível é
          confiável</h3> <button id="button-redirect-bf" title="Saiba mais" aria-label="Saiba mais" class="p-2 text-sm font-semibold px-10 bg-[#02793E] text-white rounded-sm">Saiba mais</button>
      </div>
    </div>
  </astro-island>



  <section class="py-5 mb-[24px] md:py-4 px-0 flex flex-col gap-4 justify-center items-center w-full relative bg-[rgb(249_249_249)] z-[1] astro-VF6PH3Q6" id="homeConsumerShortcutList" data-gtm-vis-recent-on-screen115820467_19="8081" data-gtm-vis-first-on-screen115820467_19="8081" data-gtm-vis-total-visible-time115820467_19="100" data-gtm-vis-has-fired115820467_19="1">
    <h1 class="text-[rgb(75_89_99)] font-extrabold text-xl text-center w-[95%] astro-VF6PH3Q6">
      O Reclame <em class="not-italic uppercase astro-VF6PH3Q6">Aqui</em> te aproxima das marcas que têm a confiança do consumidor!
    </h1>
    <p class="mb-3 lg:mb-8 text-sm text-center text-[rgb(75_89_99)] astro-VF6PH3Q6">
      Compre de modo mais seguro, pesquisando empresas e buscando uma solução para
      algum problema.
    </p>

    <div class="links p-0 flex flex-nowrap md:flex-wrap md:justify-center justify-start gap-4 z-[1] px-4 max-w-[900px] overflow-x-auto w-full astro-VF6PH3Q6">
      <astro-island uid="Z1w53D7" component-export="default" props="{'class':[0,'astro-VF6PH3Q6']}" client="load" opts="{'name':'ShortcutListSvelte','value':true}" await-children="">
        <div class="hide-in-desktop"><a href="reclame/index.php" class="secondary content-card border-green-700 svelte-1093ms2" id="home_atalho_rapido_card_faca_uma_reclamacao">
            <div class="hide-in-desktop  w-6 h-6 fill-green-800"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_246537)">
                  <path d="M5.9 14V18H-0.5V14H5.9ZM9.1 27.22C7.564 28.64 5.564 30.52 3.98 32C3.34 30.94 2.7 29.86 2.06 28.8C3.644 27.32 5.644 25.44 7.18 24C7.82 25.08 8.46 26.16 9.1 27.22ZM2.06 3.2C2.7 2.14 3.34 1.06 3.98 0C5.564 1.48 7.564 3.36 9.1 4.8C8.46 5.86 7.82 6.94 7.18 8C5.644 6.56 3.644 4.7 2.06 3.2ZM28.3 10C30.06 10 31.5 11.8 31.5 14V18C31.5 20.2 30.06 22 28.3 22H26.7V30H23.5V22H21.9L13.9 28V4L21.9 10H28.3ZM9.9 16C9.9 13.34 10.828 10.94 12.3 9.3V22.68C10.828 21.06 9.9 18.66 9.9 16Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_246537">
                    <rect width="32" height="32" fill="currentColor"></rect>
                  </clippath>
                </defs>
              </svg></div>
            <h2 class="hide-in-desktop w-[100%] text-sm text-center">Faça uma reclamação</h2>
            <h2 class="hide-in-mobile max-w-[120px] text-left">Faça uma reclamação</h2>
            <div class="hide-in-mobile  w-6 h-6 fill-green-800"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_246537)">
                  <path d="M5.9 14V18H-0.5V14H5.9ZM9.1 27.22C7.564 28.64 5.564 30.52 3.98 32C3.34 30.94 2.7 29.86 2.06 28.8C3.644 27.32 5.644 25.44 7.18 24C7.82 25.08 8.46 26.16 9.1 27.22ZM2.06 3.2C2.7 2.14 3.34 1.06 3.98 0C5.564 1.48 7.564 3.36 9.1 4.8C8.46 5.86 7.82 6.94 7.18 8C5.644 6.56 3.644 4.7 2.06 3.2ZM28.3 10C30.06 10 31.5 11.8 31.5 14V18C31.5 20.2 30.06 22 28.3 22H26.7V30H23.5V22H21.9L13.9 28V4L21.9 10H28.3ZM9.9 16C9.9 13.34 10.828 10.94 12.3 9.3V22.68C10.828 21.06 9.9 18.66 9.9 16Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_246537">
                    <rect width="32" height="32" fill="currentColor"></rect>
                  </clippath>
                </defs>
              </svg></div>
          </a></div>
        <div class="hide-in-mobile"><a href="reclame/index.php" class="secondary content-card border-green-700 svelte-1093ms2" id="home_atalho_rapido_card_faca_uma_reclamacao">
            <div class="hide-in-desktop  w-6 h-6 fill-green-800"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_246537)">
                  <path d="M5.9 14V18H-0.5V14H5.9ZM9.1 27.22C7.564 28.64 5.564 30.52 3.98 32C3.34 30.94 2.7 29.86 2.06 28.8C3.644 27.32 5.644 25.44 7.18 24C7.82 25.08 8.46 26.16 9.1 27.22ZM2.06 3.2C2.7 2.14 3.34 1.06 3.98 0C5.564 1.48 7.564 3.36 9.1 4.8C8.46 5.86 7.82 6.94 7.18 8C5.644 6.56 3.644 4.7 2.06 3.2ZM28.3 10C30.06 10 31.5 11.8 31.5 14V18C31.5 20.2 30.06 22 28.3 22H26.7V30H23.5V22H21.9L13.9 28V4L21.9 10H28.3ZM9.9 16C9.9 13.34 10.828 10.94 12.3 9.3V22.68C10.828 21.06 9.9 18.66 9.9 16Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_246537">
                    <rect width="32" height="32" fill="currentColor"></rect>
                  </clippath>
                </defs>
              </svg></div>
            <h2 class="hide-in-desktop w-[100%] text-sm text-center">Faça uma reclamação</h2>
            <h2 class="hide-in-mobile max-w-[120px] text-left">Faça uma reclamação</h2>
            <div class="hide-in-mobile  w-6 h-6 fill-green-800"><svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_246537)">
                  <path d="M5.9 14V18H-0.5V14H5.9ZM9.1 27.22C7.564 28.64 5.564 30.52 3.98 32C3.34 30.94 2.7 29.86 2.06 28.8C3.644 27.32 5.644 25.44 7.18 24C7.82 25.08 8.46 26.16 9.1 27.22ZM2.06 3.2C2.7 2.14 3.34 1.06 3.98 0C5.564 1.48 7.564 3.36 9.1 4.8C8.46 5.86 7.82 6.94 7.18 8C5.644 6.56 3.644 4.7 2.06 3.2ZM28.3 10C30.06 10 31.5 11.8 31.5 14V18C31.5 20.2 30.06 22 28.3 22H26.7V30H23.5V22H21.9L13.9 28V4L21.9 10H28.3ZM9.9 16C9.9 13.34 10.828 10.94 12.3 9.3V22.68C10.828 21.06 9.9 18.66 9.9 16Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_246537">
                    <rect width="32" height="32" fill="currentColor"></rect>
                  </clippath>
                </defs>
              </svg></div>
          </a> </div>
        <div class="hide-in-desktop"><a href="" class="secondary content-card border-green-700 svelte-1093ms2" id="home_atalho_rapido_card_minhas_reclamacoes">
            <div class="hide-in-desktop  w-6 h-6 fill-green-800"><svg viewBox="0 0 34 37" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_249539)">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M3.7 0H16.5L26.1 9.83571V19.1555C25.8622 19.1379 25.6221 19.1289 25.3799 19.1289C22.2571 19.1289 19.4746 20.6223 17.6758 22.95H6.9V26.2286H15.9915C15.7103 27.1651 15.559 28.16 15.559 29.191C15.559 30.4575 15.7873 31.6694 16.2042 32.7857H3.684C1.924 32.7857 0.5 31.3104 0.5 29.5071L0.516 3.27857C0.516 1.47536 1.94 0 3.7 0ZM6.9 19.6714H19.7V16.3929H6.9V19.6714ZM14.9 2.45893V11.475H23.7L14.9 2.45893Z" fill="currentColor"></path>
                  <path d="M24.9678 34.1968C25.9321 34.1727 26.824 33.9437 27.6437 33.5098C28.4392 33.0517 29.0901 32.449 29.5964 31.7017C29.4999 30.9303 28.9214 30.3397 27.8606 29.9298C26.7999 29.52 25.8356 29.3151 24.9678 29.3151C24.0999 29.3151 23.1356 29.52 22.0749 29.9298C21.0142 30.3397 20.4356 30.9303 20.3392 31.7017C20.8455 32.449 21.5084 33.0517 22.3281 33.5098C23.1236 33.9437 24.0035 34.1727 24.9678 34.1968ZM24.9678 23.2401C24.3169 23.2401 23.7745 23.4571 23.3406 23.891C22.9066 24.3249 22.6897 24.8794 22.6897 25.5544C22.6897 26.2053 22.9066 26.7477 23.3406 27.1816C23.7745 27.6156 24.3169 27.8325 24.9678 27.8325C25.6187 27.8325 26.1611 27.6156 26.595 27.1816C27.0289 26.7477 27.2459 26.2053 27.2459 25.5544C27.2459 24.8794 27.0289 24.3249 26.595 23.891C26.1611 23.4571 25.6187 23.2401 24.9678 23.2401ZM24.9678 20.9258C27.1615 20.974 28.9816 21.7214 30.4281 23.1678C31.8745 24.6142 32.6218 26.4343 32.67 28.6281C32.6218 30.8218 31.8745 32.6419 30.4281 34.0883C28.9816 35.5348 27.1615 36.2821 24.9678 36.3303C22.774 36.2821 20.9539 35.5348 19.5075 34.0883C18.0611 32.6419 17.3138 30.8218 17.2656 28.6281C17.3138 26.4343 18.0731 24.6142 19.5437 23.1678C20.9901 21.7214 22.7981 20.974 24.9678 20.9258Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_249539">
                    <rect width="33" height="37" fill="white" transform="translate(0.5)"></rect>
                  </clippath>
                </defs>
              </svg></div>
            <h2 class="hide-in-desktop w-[100%] text-sm text-center">Minhas Reclamações</h2>
            <h2 class="hide-in-mobile max-w-[120px] text-left">Minhas Reclamações</h2>
            <div class="hide-in-mobile  w-6 h-6 fill-green-800"><svg viewBox="0 0 34 37" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_249539)">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M3.7 0H16.5L26.1 9.83571V19.1555C25.8622 19.1379 25.6221 19.1289 25.3799 19.1289C22.2571 19.1289 19.4746 20.6223 17.6758 22.95H6.9V26.2286H15.9915C15.7103 27.1651 15.559 28.16 15.559 29.191C15.559 30.4575 15.7873 31.6694 16.2042 32.7857H3.684C1.924 32.7857 0.5 31.3104 0.5 29.5071L0.516 3.27857C0.516 1.47536 1.94 0 3.7 0ZM6.9 19.6714H19.7V16.3929H6.9V19.6714ZM14.9 2.45893V11.475H23.7L14.9 2.45893Z" fill="currentColor"></path>
                  <path d="M24.9678 34.1968C25.9321 34.1727 26.824 33.9437 27.6437 33.5098C28.4392 33.0517 29.0901 32.449 29.5964 31.7017C29.4999 30.9303 28.9214 30.3397 27.8606 29.9298C26.7999 29.52 25.8356 29.3151 24.9678 29.3151C24.0999 29.3151 23.1356 29.52 22.0749 29.9298C21.0142 30.3397 20.4356 30.9303 20.3392 31.7017C20.8455 32.449 21.5084 33.0517 22.3281 33.5098C23.1236 33.9437 24.0035 34.1727 24.9678 34.1968ZM24.9678 23.2401C24.3169 23.2401 23.7745 23.4571 23.3406 23.891C22.9066 24.3249 22.6897 24.8794 22.6897 25.5544C22.6897 26.2053 22.9066 26.7477 23.3406 27.1816C23.7745 27.6156 24.3169 27.8325 24.9678 27.8325C25.6187 27.8325 26.1611 27.6156 26.595 27.1816C27.0289 26.7477 27.2459 26.2053 27.2459 25.5544C27.2459 24.8794 27.0289 24.3249 26.595 23.891C26.1611 23.4571 25.6187 23.2401 24.9678 23.2401ZM24.9678 20.9258C27.1615 20.974 28.9816 21.7214 30.4281 23.1678C31.8745 24.6142 32.6218 26.4343 32.67 28.6281C32.6218 30.8218 31.8745 32.6419 30.4281 34.0883C28.9816 35.5348 27.1615 36.2821 24.9678 36.3303C22.774 36.2821 20.9539 35.5348 19.5075 34.0883C18.0611 32.6419 17.3138 30.8218 17.2656 28.6281C17.3138 26.4343 18.0731 24.6142 19.5437 23.1678C20.9901 21.7214 22.7981 20.974 24.9678 20.9258Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_249539">
                    <rect width="33" height="37" fill="white" transform="translate(0.5)"></rect>
                  </clippath>
                </defs>
              </svg></div>
          </a></div>
        <div class="hide-in-mobile"><a href="" class="secondary content-card border-green-700 svelte-1093ms2" id="home_atalho_rapido_card_minhas_reclamacoes">
            <div class="hide-in-desktop  w-6 h-6 fill-green-800"><svg viewBox="0 0 34 37" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_249539)">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M3.7 0H16.5L26.1 9.83571V19.1555C25.8622 19.1379 25.6221 19.1289 25.3799 19.1289C22.2571 19.1289 19.4746 20.6223 17.6758 22.95H6.9V26.2286H15.9915C15.7103 27.1651 15.559 28.16 15.559 29.191C15.559 30.4575 15.7873 31.6694 16.2042 32.7857H3.684C1.924 32.7857 0.5 31.3104 0.5 29.5071L0.516 3.27857C0.516 1.47536 1.94 0 3.7 0ZM6.9 19.6714H19.7V16.3929H6.9V19.6714ZM14.9 2.45893V11.475H23.7L14.9 2.45893Z" fill="currentColor"></path>
                  <path d="M24.9678 34.1968C25.9321 34.1727 26.824 33.9437 27.6437 33.5098C28.4392 33.0517 29.0901 32.449 29.5964 31.7017C29.4999 30.9303 28.9214 30.3397 27.8606 29.9298C26.7999 29.52 25.8356 29.3151 24.9678 29.3151C24.0999 29.3151 23.1356 29.52 22.0749 29.9298C21.0142 30.3397 20.4356 30.9303 20.3392 31.7017C20.8455 32.449 21.5084 33.0517 22.3281 33.5098C23.1236 33.9437 24.0035 34.1727 24.9678 34.1968ZM24.9678 23.2401C24.3169 23.2401 23.7745 23.4571 23.3406 23.891C22.9066 24.3249 22.6897 24.8794 22.6897 25.5544C22.6897 26.2053 22.9066 26.7477 23.3406 27.1816C23.7745 27.6156 24.3169 27.8325 24.9678 27.8325C25.6187 27.8325 26.1611 27.6156 26.595 27.1816C27.0289 26.7477 27.2459 26.2053 27.2459 25.5544C27.2459 24.8794 27.0289 24.3249 26.595 23.891C26.1611 23.4571 25.6187 23.2401 24.9678 23.2401ZM24.9678 20.9258C27.1615 20.974 28.9816 21.7214 30.4281 23.1678C31.8745 24.6142 32.6218 26.4343 32.67 28.6281C32.6218 30.8218 31.8745 32.6419 30.4281 34.0883C28.9816 35.5348 27.1615 36.2821 24.9678 36.3303C22.774 36.2821 20.9539 35.5348 19.5075 34.0883C18.0611 32.6419 17.3138 30.8218 17.2656 28.6281C17.3138 26.4343 18.0731 24.6142 19.5437 23.1678C20.9901 21.7214 22.7981 20.974 24.9678 20.9258Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_249539">
                    <rect width="33" height="37" fill="white" transform="translate(0.5)"></rect>
                  </clippath>
                </defs>
              </svg></div>
            <h2 class="hide-in-desktop w-[100%] text-sm text-center">Minhas Reclamações</h2>
            <h2 class="hide-in-mobile max-w-[120px] text-left">Minhas Reclamações</h2>
            <div class="hide-in-mobile  w-6 h-6 fill-green-800"><svg viewBox="0 0 34 37" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2905_249539)">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M3.7 0H16.5L26.1 9.83571V19.1555C25.8622 19.1379 25.6221 19.1289 25.3799 19.1289C22.2571 19.1289 19.4746 20.6223 17.6758 22.95H6.9V26.2286H15.9915C15.7103 27.1651 15.559 28.16 15.559 29.191C15.559 30.4575 15.7873 31.6694 16.2042 32.7857H3.684C1.924 32.7857 0.5 31.3104 0.5 29.5071L0.516 3.27857C0.516 1.47536 1.94 0 3.7 0ZM6.9 19.6714H19.7V16.3929H6.9V19.6714ZM14.9 2.45893V11.475H23.7L14.9 2.45893Z" fill="currentColor"></path>
                  <path d="M24.9678 34.1968C25.9321 34.1727 26.824 33.9437 27.6437 33.5098C28.4392 33.0517 29.0901 32.449 29.5964 31.7017C29.4999 30.9303 28.9214 30.3397 27.8606 29.9298C26.7999 29.52 25.8356 29.3151 24.9678 29.3151C24.0999 29.3151 23.1356 29.52 22.0749 29.9298C21.0142 30.3397 20.4356 30.9303 20.3392 31.7017C20.8455 32.449 21.5084 33.0517 22.3281 33.5098C23.1236 33.9437 24.0035 34.1727 24.9678 34.1968ZM24.9678 23.2401C24.3169 23.2401 23.7745 23.4571 23.3406 23.891C22.9066 24.3249 22.6897 24.8794 22.6897 25.5544C22.6897 26.2053 22.9066 26.7477 23.3406 27.1816C23.7745 27.6156 24.3169 27.8325 24.9678 27.8325C25.6187 27.8325 26.1611 27.6156 26.595 27.1816C27.0289 26.7477 27.2459 26.2053 27.2459 25.5544C27.2459 24.8794 27.0289 24.3249 26.595 23.891C26.1611 23.4571 25.6187 23.2401 24.9678 23.2401ZM24.9678 20.9258C27.1615 20.974 28.9816 21.7214 30.4281 23.1678C31.8745 24.6142 32.6218 26.4343 32.67 28.6281C32.6218 30.8218 31.8745 32.6419 30.4281 34.0883C28.9816 35.5348 27.1615 36.2821 24.9678 36.3303C22.774 36.2821 20.9539 35.5348 19.5075 34.0883C18.0611 32.6419 17.3138 30.8218 17.2656 28.6281C17.3138 26.4343 18.0731 24.6142 19.5437 23.1678C20.9901 21.7214 22.7981 20.974 24.9678 20.9258Z" fill="currentColor"></path>
                </g>
                <defs>
                  <clippath id="clip0_2905_249539">
                    <rect width="33" height="37" fill="white" transform="translate(0.5)"></rect>
                  </clippath>
                </defs>
              </svg></div>
          </a> </div>
        <div class="hide-in-desktop"><a href="" class="primary content-card border-green-700 svelte-1093ms2" id="home_atalho_rapido_card_reclame_aqui_para_empresas">
            <div class="hide-in-desktop  w-6 h-6 fill-green-800"><svg width="26" height="19" viewBox="0 0 26 19" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 17.8647C13.298 17.8647 13.5462 17.7653 13.7449 17.5667C13.9435 17.3681 14.0428 17.1198 14.0428 16.8218C14.0428 16.5239 13.9435 16.2756 13.7449 16.0769C13.5462 15.8783 13.298 15.779 13 15.779C12.702 15.779 12.4538 15.8783 12.2551 16.0769C12.0565 16.2756 11.9572 16.5239 11.9572 16.8218C11.9572 17.1198 12.0565 17.3681 12.2551 17.5667C12.4538 17.7653 12.702 17.8647 13 17.8647ZM4.50831 3.06628L4.50831 14.6865H21.4917V3.06628L4.50831 3.06628ZM21.4917 16.8218H25.7127C25.7127 17.4177 25.4975 17.9143 25.0671 18.3116C24.6699 18.7089 24.1733 18.9241 23.5774 18.9572H2.42263C1.82672 18.9241 1.31358 18.7089 0.883201 18.3116C0.485929 17.9143 0.287292 17.4177 0.287292 16.8218H4.50831C3.9124 16.8218 3.41581 16.6232 3.01854 16.2259C2.62127 15.7955 2.42263 15.2824 2.42263 14.6865L2.42263 3.06628C2.42263 2.43726 2.62127 1.92412 3.01854 1.52685C3.41581 1.12957 3.9124 0.930939 4.50831 0.930939L21.4917 0.930939C22.0876 0.930939 22.5842 1.12957 22.9815 1.52685C23.3787 1.92412 23.5774 2.43726 23.5774 3.06628V14.6865C23.5774 15.2824 23.3787 15.7955 22.9815 16.2259C22.5842 16.6232 22.0876 16.8218 21.4917 16.8218Z" fill="currentColor"></path>
              </svg></div>
            <h2 class="hide-in-desktop w-[100%] text-sm text-center">Reclame AQUI para empresas</h2>
            <h2 class="hide-in-mobile max-w-[120px] text-left">Reclame AQUI para empresas</h2>
            <div class="hide-in-mobile  w-6 h-6 fill-green-800"><svg width="26" height="19" viewBox="0 0 26 19" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 17.8647C13.298 17.8647 13.5462 17.7653 13.7449 17.5667C13.9435 17.3681 14.0428 17.1198 14.0428 16.8218C14.0428 16.5239 13.9435 16.2756 13.7449 16.0769C13.5462 15.8783 13.298 15.779 13 15.779C12.702 15.779 12.4538 15.8783 12.2551 16.0769C12.0565 16.2756 11.9572 16.5239 11.9572 16.8218C11.9572 17.1198 12.0565 17.3681 12.2551 17.5667C12.4538 17.7653 12.702 17.8647 13 17.8647ZM4.50831 3.06628L4.50831 14.6865H21.4917V3.06628L4.50831 3.06628ZM21.4917 16.8218H25.7127C25.7127 17.4177 25.4975 17.9143 25.0671 18.3116C24.6699 18.7089 24.1733 18.9241 23.5774 18.9572H2.42263C1.82672 18.9241 1.31358 18.7089 0.883201 18.3116C0.485929 17.9143 0.287292 17.4177 0.287292 16.8218H4.50831C3.9124 16.8218 3.41581 16.6232 3.01854 16.2259C2.62127 15.7955 2.42263 15.2824 2.42263 14.6865L2.42263 3.06628C2.42263 2.43726 2.62127 1.92412 3.01854 1.52685C3.41581 1.12957 3.9124 0.930939 4.50831 0.930939L21.4917 0.930939C22.0876 0.930939 22.5842 1.12957 22.9815 1.52685C23.3787 1.92412 23.5774 2.43726 23.5774 3.06628V14.6865C23.5774 15.2824 23.3787 15.7955 22.9815 16.2259C22.5842 16.6232 22.0876 16.8218 21.4917 16.8218Z" fill="currentColor"></path>
              </svg></div>
          </a></div>
        <div class="hide-in-mobile"><a href="" class="primary content-card border-green-700 svelte-1093ms2" id="home_atalho_rapido_card_reclame_aqui_para_empresas">
            <div class="hide-in-desktop  w-6 h-6 fill-green-800"><svg width="26" height="19" viewBox="0 0 26 19" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 17.8647C13.298 17.8647 13.5462 17.7653 13.7449 17.5667C13.9435 17.3681 14.0428 17.1198 14.0428 16.8218C14.0428 16.5239 13.9435 16.2756 13.7449 16.0769C13.5462 15.8783 13.298 15.779 13 15.779C12.702 15.779 12.4538 15.8783 12.2551 16.0769C12.0565 16.2756 11.9572 16.5239 11.9572 16.8218C11.9572 17.1198 12.0565 17.3681 12.2551 17.5667C12.4538 17.7653 12.702 17.8647 13 17.8647ZM4.50831 3.06628L4.50831 14.6865H21.4917V3.06628L4.50831 3.06628ZM21.4917 16.8218H25.7127C25.7127 17.4177 25.4975 17.9143 25.0671 18.3116C24.6699 18.7089 24.1733 18.9241 23.5774 18.9572H2.42263C1.82672 18.9241 1.31358 18.7089 0.883201 18.3116C0.485929 17.9143 0.287292 17.4177 0.287292 16.8218H4.50831C3.9124 16.8218 3.41581 16.6232 3.01854 16.2259C2.62127 15.7955 2.42263 15.2824 2.42263 14.6865L2.42263 3.06628C2.42263 2.43726 2.62127 1.92412 3.01854 1.52685C3.41581 1.12957 3.9124 0.930939 4.50831 0.930939L21.4917 0.930939C22.0876 0.930939 22.5842 1.12957 22.9815 1.52685C23.3787 1.92412 23.5774 2.43726 23.5774 3.06628V14.6865C23.5774 15.2824 23.3787 15.7955 22.9815 16.2259C22.5842 16.6232 22.0876 16.8218 21.4917 16.8218Z" fill="currentColor"></path>
              </svg></div>
            <h2 class="hide-in-desktop w-[100%] text-sm text-center">Reclame AQUI para empresas</h2>
            <h2 class="hide-in-mobile max-w-[120px] text-left">Reclame AQUI para empresas</h2>
            <div class="hide-in-mobile  w-6 h-6 fill-green-800"><svg width="26" height="19" viewBox="0 0 26 19" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 17.8647C13.298 17.8647 13.5462 17.7653 13.7449 17.5667C13.9435 17.3681 14.0428 17.1198 14.0428 16.8218C14.0428 16.5239 13.9435 16.2756 13.7449 16.0769C13.5462 15.8783 13.298 15.779 13 15.779C12.702 15.779 12.4538 15.8783 12.2551 16.0769C12.0565 16.2756 11.9572 16.5239 11.9572 16.8218C11.9572 17.1198 12.0565 17.3681 12.2551 17.5667C12.4538 17.7653 12.702 17.8647 13 17.8647ZM4.50831 3.06628L4.50831 14.6865H21.4917V3.06628L4.50831 3.06628ZM21.4917 16.8218H25.7127C25.7127 17.4177 25.4975 17.9143 25.0671 18.3116C24.6699 18.7089 24.1733 18.9241 23.5774 18.9572H2.42263C1.82672 18.9241 1.31358 18.7089 0.883201 18.3116C0.485929 17.9143 0.287292 17.4177 0.287292 16.8218H4.50831C3.9124 16.8218 3.41581 16.6232 3.01854 16.2259C2.62127 15.7955 2.42263 15.2824 2.42263 14.6865L2.42263 3.06628C2.42263 2.43726 2.62127 1.92412 3.01854 1.52685C3.41581 1.12957 3.9124 0.930939 4.50831 0.930939L21.4917 0.930939C22.0876 0.930939 22.5842 1.12957 22.9815 1.52685C23.3787 1.92412 23.5774 2.43726 23.5774 3.06628V14.6865C23.5774 15.2824 23.3787 15.7955 22.9815 16.2259C22.5842 16.6232 22.0876 16.8218 21.4917 16.8218Z" fill="currentColor"></path>
              </svg></div>
          </a> </div>
      </astro-island>
    </div>
  </section>

  <div class="hidden lg:block mb-[24px]">

  </div>

  <div class="lg:hidden mb-[24px]">
    <astro-island uid="ZOkCbR" component-export="default" props="{'slotId':[0,'div-gpt-ad-1638277001432-0'],'mode':[0,'mobile'],'minWidth':[0,336]}" client="only" opts="{'name':'PureGoogleAdsSlot','value':'svelte'}"></astro-island>
  </div>


  <a style="display: flex; width: 100%;  margin: 0px auto 15px auto; background: none; text-align: center;  align-items: center;  justify-content: center;" href="" target="_blank" id="bannerpremio"><img src="./assets/premio-mobile-2024.png"></a>
  <section class="bg-gray-50 px-4 xl:px-0" id="homeRankings" data-gtm-vis-recent-on-screen115820467_70="13850" data-gtm-vis-first-on-screen115820467_70="13850" data-gtm-vis-total-visible-time115820467_70="100" data-gtm-vis-has-fired115820467_70="1">
    <div class="mx-auto flex flex-col sm:flex-col md:flex-grow lg:flex-row justify-center sm:items-center md:items-center lg:items-start">
      <div class="flex flex-col sm:flex-col md:flex-grow lg:flex-row lg:justify-center lg:items-start">
        <div class="lg:mr-16 flex flex-col  lg:mt-[120px]">
          <div class="flex lg:w-[510px] sm:w-full flex-col lg:items-center lg:justify-center flex-1 lg:p-4 py-6">
            <div>
              <div>
                <h2 class="font-semibold text-steel lg:text-4xl  xs:text-md sm:text-[20px] text-[20px] lg:pb-6 ">
                  Melhores empresas no <br> Reclame AQUI
                </h2>
                <p class="font-light text-base text-steel w-full hidden lg:block">
                  Veja quais são as <b class="font-bold">empresas mais confiáveis de cada categoria<br> do Reclame AQUI</b>. Explore nossa página e tome<br> decisões importantes
                  com mais segurança.
                </p>

                <a id="home_ranking_segmento_cta_veja_todas_as_categorias" class="text-pickles md:hidden text-center hover:text-white hover:bg-pickles border rounded-lg border-pickles mt-[24px] lg:inline-block p-4 w-[250px] font-bold text-base hide-in-mobile" href="https://www.reclameaqui.com.br/segmentos">
                  Veja todas as categorias
                </a>
              </div>
            </div>

          </div>
        </div>
        <div class="lg:ml-16 xs:w-full sm:w-[360px] lg:w-[400px] lg:my-[32px] flex flex-col item-center justify-center">
          <astro-island uid="2nYBTM" component-export="default" props="{}" client="only" opts="{'name':'RankingSegment','value':true}">
            <div class="ranking-segment w-full">
              <div class="z-[50]"><label for="Selecione uma categoria:" class="text-sm font-[400] text-steel">Selecione uma categoria:</label>
                <div role="menu" as="select" class="relative z-[5] box-border w-full flex items-center bg-white cursor-pointer mt-2 svelte-13kut5s" aria-hidden="true">
                  <div class="flex items-center px-4 justify-between w-full rounded border border-green-neutral-700"><input type="text" placeholder="Selecione ou busque uma categoria" class="text-steel text-sm py-4 w-full border-none focus:outline-none cursor-pointer">
                    <div class="w-4 h-4" style="background-image: url(./assets/chevron-down.svg)"></div>
                  </div>
                </div>
              </div>
              <div class="lg:bg-white lg:shadow-lg rounded-md lg:px-5 pt-3 mt-4">
                <ul class="tab-ranking-wrapper flex w-full justify-between bg-white svelte-1n79oku">
                  <li data-testid="tab-best" class="text-center w-full p-5 py-4 cursor-pointer border text-[#303633] svelte-1n79oku tab-best">Melhores </li>
                  <li data-testid="tab-worst" class="text-center w-full p-5 py-4 cursor-pointer border text-[#303633] svelte-1n79oku">Piores </li>
                </ul>
                <div class="list svelte-lzrvt6">
                  <div class="my-4"><span class="italic text-sm font-normal text-slate-gray">Referente aos últimos 6 meses</span></div> <a data-testid="listing-ranking" href="" id="home_ranking_segmento_card_empresa" class="flex w-full rounded-lg bg-white pb-2 cursor-pointer   my-4 items-center justify-between border border-iron relative  svelte-lzrvt6">
                    <div class="flex items-center">
                      <div class="flex items-center pb-2"><span class="text-steel w-[23px] ml-3 text-center text-xs pt-[2px] font-bold h-[21px] absolute top-0 rounded-br-xl rounded-bl-xl bg-iron">01</span>
                        <div class="flex justify-center items-start pt-[22px] px-4">
                          <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  mr-2
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_copel-energia_hhLovf.png" src="./assets/logo_copel-energia_hhLovf.png" alt="Copel Distribuidora - Energia"></div>
                          <div class="flex items-start justify-start px-2">
                            <div>
                              <div class="flex items-center justify-start"><span class="text-sm max-w-[222px] text-steel font-semibold mr-2">Copel Distribuidora - Energia</span> </div>
                              <div class="flex mt-3"><img class="h-5 w-5 mr-2" src="./assets/otimo.webp" alt="Reputação da empresa">
                                <div><span class="text-sm font-bold text-black">8.5</span> <span class="text-xs text-steel">/10</span></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </a><a data-testid="listing-ranking" href="" id="home_ranking_segmento_card_empresa" class="flex w-full rounded-lg bg-white pb-2 cursor-pointer   my-4 items-center justify-between border border-iron relative  svelte-lzrvt6">
                    <div class="flex items-center">
                      <div class="flex items-center pb-2"><span class="text-steel w-[23px] ml-3 text-center text-xs pt-[2px] font-bold h-[21px] absolute top-0 rounded-br-xl rounded-bl-xl bg-iron">02</span>
                        <div class="flex justify-center items-start pt-[22px] px-4">
                          <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  mr-2
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/company_4c082060-b1eb-47d7-88aa-9bae0d75d1d1.jpg" src="./assets/company_4c082060-b1eb-47d7-88aa-9bae0d75d1d1.jpg" alt="CPFL"></div>
                          <div class="flex items-start justify-start px-2">
                            <div>
                              <div class="flex items-center justify-start"><span class="text-sm max-w-[222px] text-steel font-semibold mr-2">CPFL</span> <img src="./assets/seal-ra-verified.svg" alt="Selo RA Verificada" title="RA Verificada" class="w-[16px] h-auto"></div>
                              <div class="flex mt-3"><img class="h-5 w-5 mr-2" src="./assets/bom.webp" alt="Reputação da empresa">
                                <div><span class="text-sm font-bold text-black">7.7</span> <span class="text-xs text-steel">/10</span></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </a><a data-testid="listing-ranking" href="" id="home_ranking_segmento_card_empresa" class="flex w-full rounded-lg bg-white pb-2 cursor-pointer   my-4 items-center justify-between border border-iron relative  svelte-lzrvt6">
                    <div class="flex items-center">
                      <div class="flex items-center pb-2"><span class="text-steel w-[23px] ml-3 text-center text-xs pt-[2px] font-bold h-[21px] absolute top-0 rounded-br-xl rounded-bl-xl bg-iron">03</span>
                        <div class="flex justify-center items-start pt-[22px] px-4">
                          <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  mr-2
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/company_8805ca6d-885c-4ca5-aba2-6c11f474b087.jpg" src="./assets/company_8805ca6d-885c-4ca5-aba2-6c11f474b087.jpg" alt="RGE - Rio Grande Energia"></div>
                          <div class="flex items-start justify-start px-2">
                            <div>
                              <div class="flex items-center justify-start"><span class="text-sm max-w-[222px] text-steel font-semibold mr-2">RGE - Rio Grande Energia</span> </div>
                              <div class="flex mt-3"><img class="h-5 w-5 mr-2" src="./assets/bom.webp" alt="Reputação da empresa">
                                <div><span class="text-sm font-bold text-black">7.6</span> <span class="text-xs text-steel">/10</span></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
                <div class="footer-ranking-segment mb-[16px] mt-[16px] flex flex-col items-center pb-4"><a id="home_ranking_segmento_cta_veja_todas_as_empresas" href="" class="py-5 text-center lg:hover:text-white text-pickles lg:hover:bg-pickles border lg:border-none rounded-lg border-pickles font-bold text-sm w-full">Veja todas as empresas</a> <span class="my-2 lg:hidden">ou</span> <a id="home_ranking_segmento_cta_veja_todas_as_categorias" href="https://www.reclameaqui.com.br/segmentos" class="text-center lg:hidden py-5 text-pickles rounded-lg border-pickles font-bold text-sm w-full active:bg-pickles active:text-white">Veja todas as categorias</a></div>
              </div>
            </div>
          </astro-island>
        </div>
      </div>

    </div>
  </section>

  <astro-island uid="Z1n9ix1" component-export="default" props="{}" client="visible" opts="{'name':'BannerExtension','value':true}" await-children="">
    <div class="hide-in-mobile lg:flex lg:justify-center h-[240px] w-full mx-3 lg:mx-auto pt-[80px]">
      <div role="banner" class="w-full lg:w-[994px] rounded-md flex items-center pl-4 pr-16 py-6 svelte-1kraxgk"><img class="mr-1" width="130" height="106" alt="Desconto" src="./assets/ramais-desconto.23713937.webp">
        <p class="text-white text-2xl w-[60%]">Receba desconto enquanto navega nas<br>maiores lojas do Brasil</p> <a href="" target="_blank" class="flex text-lg items-center text-white border-2 font-medium border-white rounded-md py-3 w-[260px] justify-center"><svg class="mr-2" stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 1024 1024" height="1.3em" width="1.3em" xmlns="http://www.w3.org/2000/svg">
            <path d="M928 512.3v-.3c0-229.8-186.2-416-416-416S96 282.2 96 512v.4c0 229.8 186.2 416 416 416s416-186.2 416-416v-.3.2zm-6.7-74.6l.6 3.3-.6-3.3zM676.7 638.2c53.5-82.2 52.5-189.4-11.1-263.7l162.4-8.4c20.5 44.4 32 93.8 32 145.9 0 185.2-144.6 336.6-327.1 347.4l143.8-221.2zM512 652.3c-77.5 0-140.2-62.7-140.2-140.2 0-77.7 62.7-140.2 140.2-140.2S652.2 434.5 652.2 512 589.5 652.3 512 652.3zm369.2-331.7l-3-5.7 3 5.7zM512 164c121.3 0 228.2 62.1 290.4 156.2l-263.6-13.9c-97.5-5.7-190.2 49.2-222.3 141.1L227.8 311c63.1-88.9 166.9-147 284.2-147zM102.5 585.8c26 145 127.1 264 261.6 315.1C229.6 850 128.5 731 102.5 585.8zM164 512c0-55.9 13.2-108.7 36.6-155.5l119.7 235.4c44.1 86.7 137.4 139.7 234 121.6l-74 145.1C302.9 842.5 164 693.5 164 512zm324.7 415.4c4 .2 8 .4 12 .5-4-.2-8-.3-12-.5z"></path>
          </svg>
          Baixe a extensão</a>
      </div>
    </div>
  </astro-island>

  <div class="min-h-[640px] mt-16">
    <section class="relative bg-[#25292C] py-5 px-6 text-white min-w-full">
      <div class="w-full lg:max-w-[1152px] mx-auto relative z-[1]">
        <header class="w-full mt-12 lg:w-[500px]">
          <h2 class="mt-3 lg:mt-6 text-xl lg:text-[32px] lg:leading-10 lg:w-[450px] font-bold">
            Detector de site confiável do Reclame AQUI
          </h2>
          <p class="text-base lg:text-xl font-semibold lg:w-[550px] mt-3 mb-10">
            Descubra se o site onde você viu aquela oferta imperdível é falso e se
            estão tentando te dar um golpe!
          </p>
          <img src="./assets/axur-e-ra.f022ddae.svg" width="227" height="19" alt="Axur e ReclameAQUI">
          <a href="">
            <button class="border rounded-md border-[#95F060] h-[56px] w-full lg:w-[231px] mt-[40px] mb-[56px] text-sm font-semibold bg-[#95f060] text-black hover:bg-[#88db58] hover:border-[#88db58] transition-colors">
              Acessar
            </button>
          </a>
        </header>


        <astro-island uid="1VosLJ" component-export="default" props="{}" client="visible" opts="{'name':'SiteDetectorSvelte','value':true}" await-children="">
          <form class="grid row-auto mb-4 w-full lg:w-[545px] relative" method="POST">
            <div class="relative flex-1"></div>
          </form>
        </astro-island>
      </div>
      <img class="z-[0] absolute right-[10px] lg:right-[250px] top-[20px] mix-blend-screen" loading="lazy" src="./assets/detector-background.webp" alt="Mulher utilizando um notebook">
    </section>
  </div>

  <section class="lg:min-h-[590px]">
    <div class="px-4 lg:h-64 xl:px-0 w-full max-w-7xl lg:max-w-6xl color-red-100 flex flex-wrap justify-between items-center mx-0 lg:mx-auto mt-[-110px] lg:mt-[-80px] mb-6">
      <div class="flex w-full justify-center lg:hidden">
        <img width="160" height="130" alt="Descontos!" src="./assets/ramais-desconto.webp" aria-label="RA Mais Vitrine">
      </div>
      <div class="ca15uz-4 ckKCJN">
        <h2 class="text-lg lg:text-3xl font-bold lg:font-semibold text-[#333] lg:text-steel">
          Encontre os melhores descontos
        </h2>
        <p class="color-[#4b5963] mt-3 text-lg lg:text-base font-medium text-steel">
          Compre com desconto e em segurança nas empresas mais confiáveis.
        </p>
        <a target="_blank" href="" class="
          w-full md:w-[250px] mt-5 border flex justify-center lg:inline-block border-green-800
          rounded-[4px] px-8 py-4 text-green-800 text-base font-semibold s-Ep-x6olwmg5C
        ">
          <span>Ver todos os descontos</span>
        </a>
      </div>
      <div class="hidden lg:block">
        <img alt="Descontos!" src="./assets/ramais-desconto.webp" width="312" height="256" aria-label="Ra Mais Vitrine">
      </div>
    </div>

    <div class="w-full px-4 xl:px-0 lg:max-w-[62rem] xl:max-w-6xl mx-auto">
      <h2 class="mb-6 ml-0 lg:ml-2 text-[19px] lg:text-xl font-bold text-steel">
        Os melhores descontos das empresas que o consumidor confia:
      </h2>

      <astro-island uid="1t8j1h" component-export="default" props="{}" client="visible" opts="{'name':'DiscountBlockSvelte','value':true}" await-children="">
        <div data-testid="discount-block">
          <div class="relative">
            <div id="ECZrW" class="glider draggable">
              <div class="glider-track" style="width: 3840px;"><a href="" title="PagBank" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide active visible center" data-gslide="0" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_pagseguro_S2TUL3.png" src="./assets/logo_pagseguro_S2TUL3.png" alt="Descontos PagBank"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">PagBank</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRsoHAABXRUJQVlA4TL0HAAAvP8APECK62v4rcpu9Hl9FbiktMzPDzArMJGaWZmbDzMzMzImezPwP7CgXcCozQ52K0SgIH9O/DXPMVOVRt+WeMKOgM3Rh1mP2BYSTiiX5dKldp5BD27axV/uvksq2bdtOOtu2v/+rYttWZxvPtjudP3aqZ31Sbm1Tw2h+TzVzoE1mPpxTx0ySHFeTY+Zl5l1JjjUoSiqXeQO31ra3ickZ/sMEcYDY41CRU0clNvgnwNrA2kBiAnsD2e6o4gCOPWGBy8Bt2zhSg2RX1w3d8QZxbTcWPtSUNSakCEJaZUQQnGwPv0OcwIRCA1SFxMLv7ARO/MWEliZ0YILuwGCD0AHiR2CVAR9N6E9Xf+82IgYhTW8dIqIBSYWoMaFtxAgXpVxRLeWKWMoVgRMDvoqI2HXeLATOa2gEPTG55MeP3av+/Usv//37e5/XL24DMAuCExOSgfF+FIEQPd3L4Io/f2pX///fLeUKJx6+f12xcPRgBbdgXjAJQnMTmi+qcTGh78jlDJd5BjhWzPC48u/f5yn6yr9//zPWbz8FYDYDMDM80wQRK+5tQEiMkGglIzoakyefbKdN2qiwWyEfLSpvRMRyIS78+rVx9f//Q60v/Pr1LTi6c9rCoGRR8DgEKdaneKLCTMdmLcJoeiCqR4qjxl3x509fa33KSZYHYMJSzvlGHp/kREoKHckw+iRBnFiL428872vXEw7evQRgVkq5YkbwsYjYA+zPVRhQqW4TzqdTWuvHQg+fPAZgFgWvO8EfAlK9kOS0EncE26/9Ou162a9fU+vew7MAzLwIi1tzooDktrCw0wm3X/HiostPfx2yFq43Q7oteJjV2BiBfeQlOpIXi7V2bhly0VXGi/MoF6fWy4BAbJzBN9UBS/njgMkFl3/7AsYARMQb2QRgZg1Id6+KsxLNRngkOSHuKGZSBy+u0J7nH2fi1HqA4MgiALO0JqLzrQB2rzhxPp06oOOG9moD4kUFdxQxicM3D4C4/PsXO7cMgzNwHgcBmJnn10PcXxOhrdXanEM5fd6Xtw6bWbR7Yxc+CksTh27s04B9xmdZfCsnCsDM5eZw9c141kqot5qYtfPQeVrrcz+/8lEYcfDiqp5StlVhXuajweCpbXhoLUQ29KiQ1Dzu3POPtNaXXOeO2z1Sw4pDNw7A+KeYSUgp3RS5l6PFwodRJrRExKAoS84JbRdbaadsdtyHp8AQT33xALVoOmB+GYxT3z1WyCTcLGWcqEDEyAxG0VAO51yCNbH4qcyCWExitU3Dy4RmNmggZYdBuw1N04CLrnK71HeSwAQrQrxGGmhruyI0J8qRsqAk0SatzuYRZQomllz67TMwzqc/ApSwVknjoEdh71ZNu6mQzCCA0C709w1kvHeTO2U22Ca6Qlxpi2u6gIW70mKtoqo2F15mNOCwpVVjJaS4wHGB7x92ixUWYFzF/FRqXmi72Ao7ZjG3wXPs1tCpuKrNRZcZDTj6ziUlTEqSgvfYECE4GjFpS/iptPzI9rGVdsxmjxLtpnP2X9OAi69zdlkzCSB3NOCjYGvAp+7rRkLHpuVF7otjWjyqGdq17SSNVjLCqzm6CkJzxFayTBL2S84NTcvsncPgqO1DY1mY0ME8dpjQd7hAlp2zAtc7MxuonPXxpX5S0hcYjfxAIqKkWFSaaJ1aZ8B0Cq/sXNdB0kEEjScwKikWlCRiE6ttlRDoSnLg5DyLtejkJwKE7UYafyAkPRBImhn5sW1jKrSrGERwwtN7hjHyvwg1IB36W68a0MmYUOn30PV7rJ8B1+1S30EyaK/NEBEj5bcL1uYuiNiN/rWpiE+psVViCJzqsKU1UyHktHenbbUBH2sEh1MizC9GVmHsvoKJRS7nH73RT7KXIzX837zudP7ulBXYNKyU2+EbkkV3RBzCRyMiM+WXJIz4Ku3LB+mjtw/1ZJHqiRC9xP/J7Ralfyrqto4qd/Sje5jrom7mTcTU+4nxwkzIDuQUNWLm1rICkTc1IWGCNZJUZ45lxXuIyJtM+Lsh5XOrTciHCR0iYrITkmGY7EQQca4BKX4bMmTIIsFrxCu5GQ/qeeH/MCJ2j/IRhUc0hMeNCH2Qoxj/4K2s378w/nvgynejnBXiqPCYBYgRUc2IiP8lWJOsYJCf5IyXcnx0ccVPYDhx4voeAe/78CjHSHU7TyryN5CzB9raCeQyVkQ5+64Uw7o0sr7ZHLPv9hphE2RKJSQxPtraMWWTrQohbp8lwtYRuFKprGEEiFdSLbWlC/n8d0BaGVHOnhsUURCELyqlSt4Dj8QkZr1Hub1w2AgoeohUWhlrdinYREo5e67lCyGCQxcVryTw89wppJS4HV6vUlWf42CllArt2aYfLPboFMLa+7AuykWUI1Z/r5RS3/7ewYd5KIfS6AMWQeJRpRQgFj40fjTPJkiVIoYCSj+guAvZHSGG7QSfiMUQWwBdBf3mJR8JUdOhADp7+ENchE1UdQijQ1hc51rhC7YAPwCTIWAxtAcD4ZsWuTsXa88V4nsPm1wGKSIfPJw92wH41VFoH9pCTHf24N3lewG19yBzqfCP6WrwPhQEQbSXiKH8otRk4Z+2AIbLBdDeg1Qpm2yVdi9H+Ag5WBEiSAaH9iAXhK+5lIXLQ+Sylyjtf14EAA==" alt="RA1000">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">RA1000</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">5 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Gran Cursos Online" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-1" data-gslide="1" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_gran-cursos-online_Q7JyCC.png" src="./assets/logo_gran-cursos-online_Q7JyCC.png" alt="Descontos Gran Cursos Online"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Gran Cursos Online</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRsoHAABXRUJQVlA4TL0HAAAvP8APECK62v4rcpu9Hl9FbiktMzPDzArMJGaWZmbDzMzMzImezPwP7CgXcCozQ52K0SgIH9O/DXPMVOVRt+WeMKOgM3Rh1mP2BYSTiiX5dKldp5BD27axV/uvksq2bdtOOtu2v/+rYttWZxvPtjudP3aqZ31Sbm1Tw2h+TzVzoE1mPpxTx0ySHFeTY+Zl5l1JjjUoSiqXeQO31ra3ickZ/sMEcYDY41CRU0clNvgnwNrA2kBiAnsD2e6o4gCOPWGBy8Bt2zhSg2RX1w3d8QZxbTcWPtSUNSakCEJaZUQQnGwPv0OcwIRCA1SFxMLv7ARO/MWEliZ0YILuwGCD0AHiR2CVAR9N6E9Xf+82IgYhTW8dIqIBSYWoMaFtxAgXpVxRLeWKWMoVgRMDvoqI2HXeLATOa2gEPTG55MeP3av+/Usv//37e5/XL24DMAuCExOSgfF+FIEQPd3L4Io/f2pX///fLeUKJx6+f12xcPRgBbdgXjAJQnMTmi+qcTGh78jlDJd5BjhWzPC48u/f5yn6yr9//zPWbz8FYDYDMDM80wQRK+5tQEiMkGglIzoakyefbKdN2qiwWyEfLSpvRMRyIS78+rVx9f//Q60v/Pr1LTi6c9rCoGRR8DgEKdaneKLCTMdmLcJoeiCqR4qjxl3x509fa33KSZYHYMJSzvlGHp/kREoKHckw+iRBnFiL428872vXEw7evQRgVkq5YkbwsYjYA+zPVRhQqW4TzqdTWuvHQg+fPAZgFgWvO8EfAlK9kOS0EncE26/9Ou162a9fU+vew7MAzLwIi1tzooDktrCw0wm3X/HiostPfx2yFq43Q7oteJjV2BiBfeQlOpIXi7V2bhly0VXGi/MoF6fWy4BAbJzBN9UBS/njgMkFl3/7AsYARMQb2QRgZg1Id6+KsxLNRngkOSHuKGZSBy+u0J7nH2fi1HqA4MgiALO0JqLzrQB2rzhxPp06oOOG9moD4kUFdxQxicM3D4C4/PsXO7cMgzNwHgcBmJnn10PcXxOhrdXanEM5fd6Xtw6bWbR7Yxc+CksTh27s04B9xmdZfCsnCsDM5eZw9c141kqot5qYtfPQeVrrcz+/8lEYcfDiqp5StlVhXuajweCpbXhoLUQ29KiQ1Dzu3POPtNaXXOeO2z1Sw4pDNw7A+KeYSUgp3RS5l6PFwodRJrRExKAoS84JbRdbaadsdtyHp8AQT33xALVoOmB+GYxT3z1WyCTcLGWcqEDEyAxG0VAO51yCNbH4qcyCWExitU3Dy4RmNmggZYdBuw1N04CLrnK71HeSwAQrQrxGGmhruyI0J8qRsqAk0SatzuYRZQomllz67TMwzqc/ApSwVknjoEdh71ZNu6mQzCCA0C709w1kvHeTO2U22Ca6Qlxpi2u6gIW70mKtoqo2F15mNOCwpVVjJaS4wHGB7x92ixUWYFzF/FRqXmi72Ao7ZjG3wXPs1tCpuKrNRZcZDTj6ziUlTEqSgvfYECE4GjFpS/iptPzI9rGVdsxmjxLtpnP2X9OAi69zdlkzCSB3NOCjYGvAp+7rRkLHpuVF7otjWjyqGdq17SSNVjLCqzm6CkJzxFayTBL2S84NTcvsncPgqO1DY1mY0ME8dpjQd7hAlp2zAtc7MxuonPXxpX5S0hcYjfxAIqKkWFSaaJ1aZ8B0Cq/sXNdB0kEEjScwKikWlCRiE6ttlRDoSnLg5DyLtejkJwKE7UYafyAkPRBImhn5sW1jKrSrGERwwtN7hjHyvwg1IB36W68a0MmYUOn30PV7rJ8B1+1S30EyaK/NEBEj5bcL1uYuiNiN/rWpiE+psVViCJzqsKU1UyHktHenbbUBH2sEh1MizC9GVmHsvoKJRS7nH73RT7KXIzX837zudP7ulBXYNKyU2+EbkkV3RBzCRyMiM+WXJIz4Ku3LB+mjtw/1ZJHqiRC9xP/J7Ralfyrqto4qd/Sje5jrom7mTcTU+4nxwkzIDuQUNWLm1rICkTc1IWGCNZJUZ45lxXuIyJtM+Lsh5XOrTciHCR0iYrITkmGY7EQQca4BKX4bMmTIIsFrxCu5GQ/qeeH/MCJ2j/IRhUc0hMeNCH2Qoxj/4K2s378w/nvgynejnBXiqPCYBYgRUc2IiP8lWJOsYJCf5IyXcnx0ccVPYDhx4voeAe/78CjHSHU7TyryN5CzB9raCeQyVkQ5+64Uw7o0sr7ZHLPv9hphE2RKJSQxPtraMWWTrQohbp8lwtYRuFKprGEEiFdSLbWlC/n8d0BaGVHOnhsUURCELyqlSt4Dj8QkZr1Hub1w2AgoeohUWhlrdinYREo5e67lCyGCQxcVryTw89wppJS4HV6vUlWf42CllArt2aYfLPboFMLa+7AuykWUI1Z/r5RS3/7ewYd5KIfS6AMWQeJRpRQgFj40fjTPJkiVIoYCSj+guAvZHSGG7QSfiMUQWwBdBf3mJR8JUdOhADp7+ENchE1UdQijQ1hc51rhC7YAPwCTIWAxtAcD4ZsWuTsXa88V4nsPm1wGKSIfPJw92wH41VFoH9pCTHf24N3lewG19yBzqfCP6WrwPhQEQbSXiKH8otRk4Z+2AIbLBdDeg1Qpm2yVdi9H+Ag5WBEiSAaH9iAXhK+5lIXLQ+Sylyjtf14EAA==" alt="RA1000">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">RA1000</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">2 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Shopee" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-2" data-gslide="2" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_shopee_IgDCxI.png" src="./assets/logo_shopee_IgDCxI.png" alt="Descontos Shopee"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Shopee</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" alt="Ótimo">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Ótimo</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">4 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Netshoes" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-3" data-gslide="3" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/company_a26131b6-89f5-4355-87c7-4516d025b9b5.png" src="./assets/company_a26131b6-89f5-4355-87c7-4516d025b9b5.png" alt="Descontos Netshoes"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Netshoes</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRsoHAABXRUJQVlA4TL0HAAAvP8APECK62v4rcpu9Hl9FbiktMzPDzArMJGaWZmbDzMzMzImezPwP7CgXcCozQ52K0SgIH9O/DXPMVOVRt+WeMKOgM3Rh1mP2BYSTiiX5dKldp5BD27axV/uvksq2bdtOOtu2v/+rYttWZxvPtjudP3aqZ31Sbm1Tw2h+TzVzoE1mPpxTx0ySHFeTY+Zl5l1JjjUoSiqXeQO31ra3ickZ/sMEcYDY41CRU0clNvgnwNrA2kBiAnsD2e6o4gCOPWGBy8Bt2zhSg2RX1w3d8QZxbTcWPtSUNSakCEJaZUQQnGwPv0OcwIRCA1SFxMLv7ARO/MWEliZ0YILuwGCD0AHiR2CVAR9N6E9Xf+82IgYhTW8dIqIBSYWoMaFtxAgXpVxRLeWKWMoVgRMDvoqI2HXeLATOa2gEPTG55MeP3av+/Usv//37e5/XL24DMAuCExOSgfF+FIEQPd3L4Io/f2pX///fLeUKJx6+f12xcPRgBbdgXjAJQnMTmi+qcTGh78jlDJd5BjhWzPC48u/f5yn6yr9//zPWbz8FYDYDMDM80wQRK+5tQEiMkGglIzoakyefbKdN2qiwWyEfLSpvRMRyIS78+rVx9f//Q60v/Pr1LTi6c9rCoGRR8DgEKdaneKLCTMdmLcJoeiCqR4qjxl3x509fa33KSZYHYMJSzvlGHp/kREoKHckw+iRBnFiL428872vXEw7evQRgVkq5YkbwsYjYA+zPVRhQqW4TzqdTWuvHQg+fPAZgFgWvO8EfAlK9kOS0EncE26/9Ou162a9fU+vew7MAzLwIi1tzooDktrCw0wm3X/HiostPfx2yFq43Q7oteJjV2BiBfeQlOpIXi7V2bhly0VXGi/MoF6fWy4BAbJzBN9UBS/njgMkFl3/7AsYARMQb2QRgZg1Id6+KsxLNRngkOSHuKGZSBy+u0J7nH2fi1HqA4MgiALO0JqLzrQB2rzhxPp06oOOG9moD4kUFdxQxicM3D4C4/PsXO7cMgzNwHgcBmJnn10PcXxOhrdXanEM5fd6Xtw6bWbR7Yxc+CksTh27s04B9xmdZfCsnCsDM5eZw9c141kqot5qYtfPQeVrrcz+/8lEYcfDiqp5StlVhXuajweCpbXhoLUQ29KiQ1Dzu3POPtNaXXOeO2z1Sw4pDNw7A+KeYSUgp3RS5l6PFwodRJrRExKAoS84JbRdbaadsdtyHp8AQT33xALVoOmB+GYxT3z1WyCTcLGWcqEDEyAxG0VAO51yCNbH4qcyCWExitU3Dy4RmNmggZYdBuw1N04CLrnK71HeSwAQrQrxGGmhruyI0J8qRsqAk0SatzuYRZQomllz67TMwzqc/ApSwVknjoEdh71ZNu6mQzCCA0C709w1kvHeTO2U22Ca6Qlxpi2u6gIW70mKtoqo2F15mNOCwpVVjJaS4wHGB7x92ixUWYFzF/FRqXmi72Ao7ZjG3wXPs1tCpuKrNRZcZDTj6ziUlTEqSgvfYECE4GjFpS/iptPzI9rGVdsxmjxLtpnP2X9OAi69zdlkzCSB3NOCjYGvAp+7rRkLHpuVF7otjWjyqGdq17SSNVjLCqzm6CkJzxFayTBL2S84NTcvsncPgqO1DY1mY0ME8dpjQd7hAlp2zAtc7MxuonPXxpX5S0hcYjfxAIqKkWFSaaJ1aZ8B0Cq/sXNdB0kEEjScwKikWlCRiE6ttlRDoSnLg5DyLtejkJwKE7UYafyAkPRBImhn5sW1jKrSrGERwwtN7hjHyvwg1IB36W68a0MmYUOn30PV7rJ8B1+1S30EyaK/NEBEj5bcL1uYuiNiN/rWpiE+psVViCJzqsKU1UyHktHenbbUBH2sEh1MizC9GVmHsvoKJRS7nH73RT7KXIzX837zudP7ulBXYNKyU2+EbkkV3RBzCRyMiM+WXJIz4Ku3LB+mjtw/1ZJHqiRC9xP/J7Ralfyrqto4qd/Sje5jrom7mTcTU+4nxwkzIDuQUNWLm1rICkTc1IWGCNZJUZ45lxXuIyJtM+Lsh5XOrTciHCR0iYrITkmGY7EQQca4BKX4bMmTIIsFrxCu5GQ/qeeH/MCJ2j/IRhUc0hMeNCH2Qoxj/4K2s378w/nvgynejnBXiqPCYBYgRUc2IiP8lWJOsYJCf5IyXcnx0ccVPYDhx4voeAe/78CjHSHU7TyryN5CzB9raCeQyVkQ5+64Uw7o0sr7ZHLPv9hphE2RKJSQxPtraMWWTrQohbp8lwtYRuFKprGEEiFdSLbWlC/n8d0BaGVHOnhsUURCELyqlSt4Dj8QkZr1Hub1w2AgoeohUWhlrdinYREo5e67lCyGCQxcVryTw89wppJS4HV6vUlWf42CllArt2aYfLPboFMLa+7AuykWUI1Z/r5RS3/7ewYd5KIfS6AMWQeJRpRQgFj40fjTPJkiVIoYCSj+guAvZHSGG7QSfiMUQWwBdBf3mJR8JUdOhADp7+ENchE1UdQijQ1hc51rhC7YAPwCTIWAxtAcD4ZsWuTsXa88V4nsPm1wGKSIfPJw92wH41VFoH9pCTHf24N3lewG19yBzqfCP6WrwPhQEQbSXiKH8otRk4Z+2AIbLBdDeg1Qpm2yVdi9H+Ag5WBEiSAaH9iAXhK+5lIXLQ+Sylyjtf14EAA==" alt="RA1000">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">RA1000</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">21 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Nike" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-4" data-gslide="4" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/company_f2791a15-5194-4983-a223-901e43d04b65.jpg" src="./assets/company_f2791a15-5194-4983-a223-901e43d04b65.jpg" alt="Descontos Nike"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Nike</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" alt="Ótimo">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Ótimo</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">42 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Ray Ban" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-5" data-gslide="5" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/company_20de57fd-0adc-4be2-9d92-ff4410758abf.jpg" src="./assets/company_20de57fd-0adc-4be2-9d92-ff4410758abf.jpg" alt="Descontos Ray Ban"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Ray Ban</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" alt="Ótimo">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Ótimo</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">2 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Oakley" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-6" data-gslide="6" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/company_be963311-ac0b-4ea6-8529-9474f9b3a133.jpg" src="./assets/company_be963311-ac0b-4ea6-8529-9474f9b3a133.jpg" alt="Descontos Oakley"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Oakley</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" alt="Ótimo">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Ótimo</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">3 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Web Continental" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-7" data-gslide="7" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/company_c1097b44-f661-44e7-8796-d0c5632dab2e.jpg" src="./assets/company_c1097b44-f661-44e7-8796-d0c5632dab2e.jpg" alt="Descontos Web Continental"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Web Continental</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" alt="Bom">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Bom</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">19 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="KaBuM!" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-8" data-gslide="8" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_kabum_TPcDkR.png" src="./assets/logo_kabum_TPcDkR.png" alt="Descontos KaBuM!"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">KaBuM!</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRsoHAABXRUJQVlA4TL0HAAAvP8APECK62v4rcpu9Hl9FbiktMzPDzArMJGaWZmbDzMzMzImezPwP7CgXcCozQ52K0SgIH9O/DXPMVOVRt+WeMKOgM3Rh1mP2BYSTiiX5dKldp5BD27axV/uvksq2bdtOOtu2v/+rYttWZxvPtjudP3aqZ31Sbm1Tw2h+TzVzoE1mPpxTx0ySHFeTY+Zl5l1JjjUoSiqXeQO31ra3ickZ/sMEcYDY41CRU0clNvgnwNrA2kBiAnsD2e6o4gCOPWGBy8Bt2zhSg2RX1w3d8QZxbTcWPtSUNSakCEJaZUQQnGwPv0OcwIRCA1SFxMLv7ARO/MWEliZ0YILuwGCD0AHiR2CVAR9N6E9Xf+82IgYhTW8dIqIBSYWoMaFtxAgXpVxRLeWKWMoVgRMDvoqI2HXeLATOa2gEPTG55MeP3av+/Usv//37e5/XL24DMAuCExOSgfF+FIEQPd3L4Io/f2pX///fLeUKJx6+f12xcPRgBbdgXjAJQnMTmi+qcTGh78jlDJd5BjhWzPC48u/f5yn6yr9//zPWbz8FYDYDMDM80wQRK+5tQEiMkGglIzoakyefbKdN2qiwWyEfLSpvRMRyIS78+rVx9f//Q60v/Pr1LTi6c9rCoGRR8DgEKdaneKLCTMdmLcJoeiCqR4qjxl3x509fa33KSZYHYMJSzvlGHp/kREoKHckw+iRBnFiL428872vXEw7evQRgVkq5YkbwsYjYA+zPVRhQqW4TzqdTWuvHQg+fPAZgFgWvO8EfAlK9kOS0EncE26/9Ou162a9fU+vew7MAzLwIi1tzooDktrCw0wm3X/HiostPfx2yFq43Q7oteJjV2BiBfeQlOpIXi7V2bhly0VXGi/MoF6fWy4BAbJzBN9UBS/njgMkFl3/7AsYARMQb2QRgZg1Id6+KsxLNRngkOSHuKGZSBy+u0J7nH2fi1HqA4MgiALO0JqLzrQB2rzhxPp06oOOG9moD4kUFdxQxicM3D4C4/PsXO7cMgzNwHgcBmJnn10PcXxOhrdXanEM5fd6Xtw6bWbR7Yxc+CksTh27s04B9xmdZfCsnCsDM5eZw9c141kqot5qYtfPQeVrrcz+/8lEYcfDiqp5StlVhXuajweCpbXhoLUQ29KiQ1Dzu3POPtNaXXOeO2z1Sw4pDNw7A+KeYSUgp3RS5l6PFwodRJrRExKAoS84JbRdbaadsdtyHp8AQT33xALVoOmB+GYxT3z1WyCTcLGWcqEDEyAxG0VAO51yCNbH4qcyCWExitU3Dy4RmNmggZYdBuw1N04CLrnK71HeSwAQrQrxGGmhruyI0J8qRsqAk0SatzuYRZQomllz67TMwzqc/ApSwVknjoEdh71ZNu6mQzCCA0C709w1kvHeTO2U22Ca6Qlxpi2u6gIW70mKtoqo2F15mNOCwpVVjJaS4wHGB7x92ixUWYFzF/FRqXmi72Ao7ZjG3wXPs1tCpuKrNRZcZDTj6ziUlTEqSgvfYECE4GjFpS/iptPzI9rGVdsxmjxLtpnP2X9OAi69zdlkzCSB3NOCjYGvAp+7rRkLHpuVF7otjWjyqGdq17SSNVjLCqzm6CkJzxFayTBL2S84NTcvsncPgqO1DY1mY0ME8dpjQd7hAlp2zAtc7MxuonPXxpX5S0hcYjfxAIqKkWFSaaJ1aZ8B0Cq/sXNdB0kEEjScwKikWlCRiE6ttlRDoSnLg5DyLtejkJwKE7UYafyAkPRBImhn5sW1jKrSrGERwwtN7hjHyvwg1IB36W68a0MmYUOn30PV7rJ8B1+1S30EyaK/NEBEj5bcL1uYuiNiN/rWpiE+psVViCJzqsKU1UyHktHenbbUBH2sEh1MizC9GVmHsvoKJRS7nH73RT7KXIzX837zudP7ulBXYNKyU2+EbkkV3RBzCRyMiM+WXJIz4Ku3LB+mjtw/1ZJHqiRC9xP/J7Ralfyrqto4qd/Sje5jrom7mTcTU+4nxwkzIDuQUNWLm1rICkTc1IWGCNZJUZ45lxXuIyJtM+Lsh5XOrTciHCR0iYrITkmGY7EQQca4BKX4bMmTIIsFrxCu5GQ/qeeH/MCJ2j/IRhUc0hMeNCH2Qoxj/4K2s378w/nvgynejnBXiqPCYBYgRUc2IiP8lWJOsYJCf5IyXcnx0ccVPYDhx4voeAe/78CjHSHU7TyryN5CzB9raCeQyVkQ5+64Uw7o0sr7ZHLPv9hphE2RKJSQxPtraMWWTrQohbp8lwtYRuFKprGEEiFdSLbWlC/n8d0BaGVHOnhsUURCELyqlSt4Dj8QkZr1Hub1w2AgoeohUWhlrdinYREo5e67lCyGCQxcVryTw89wppJS4HV6vUlWf42CllArt2aYfLPboFMLa+7AuykWUI1Z/r5RS3/7ewYd5KIfS6AMWQeJRpRQgFj40fjTPJkiVIoYCSj+guAvZHSGG7QSfiMUQWwBdBf3mJR8JUdOhADp7+ENchE1UdQijQ1hc51rhC7YAPwCTIWAxtAcD4ZsWuTsXa88V4nsPm1wGKSIfPJw92wH41VFoH9pCTHf24N3lewG19yBzqfCP6WrwPhQEQbSXiKH8otRk4Z+2AIbLBdDeg1Qpm2yVdi9H+Ag5WBEiSAaH9iAXhK+5lIXLQ+Sylyjtf14EAA==" alt="RA1000">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">RA1000</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">106 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Udemy" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-9" data-gslide="9" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_udemy_quabPA.png" src="./assets/logo_udemy_quabPA.png" alt="Descontos Udemy"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Udemy</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" alt="Ótimo">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Ótimo</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">6 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Electrolux" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-10" data-gslide="10" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover ls-is-cached lazyloaded" width="48" height="48" data-src="./assets/logo_electrolux-loja-online_B6PWNW.jpg" src="./assets/logo_electrolux-loja-online_B6PWNW.jpg" alt="Descontos Electrolux"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Electrolux</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" alt="Bom">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Bom</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">11 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Casas Bahia - Loja Online" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-11" data-gslide="11" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo_null_5S2wZg.png" src="./assets/logo_null_5S2wZg.png" alt="Descontos Casas Bahia - Loja Online"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Casas Bahia - Loja Online</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" alt="Bom">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Bom</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">9 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="MadeiraMadeira" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-12" data-gslide="12" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo_madeiramadeira_Fx1GpO.png" src="./assets/logo_madeiramadeira_Fx1GpO.png" alt="Descontos MadeiraMadeira"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">MadeiraMadeira</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" alt="Bom">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Bom</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">14 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Leroy Merlin - Loja Virtual" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-13" data-gslide="13" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo_leroy-merlin-loja-virtual_tWR9RZ.png" src="./assets/logo_leroy-merlin-loja-virtual_tWR9RZ.png" alt="Descontos Leroy Merlin - Loja Virtual"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Leroy Merlin - Loja Virtual</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRsYGAABXRUJQVlA4TLkGAAAvP8APEF8HMbZtVc0+9wBx9/778+Dcd+JpAZIjSYokz6qoocUj7/7/d8MYlQk5kiRFUmQtH79Pf/GWmbrCQNo28W/2vYIpctuE6QROvAMADAh4YP8kEDDggYCAgFJeUkm1h/bQHpJKamRL6vvu54lSedkdpPS83RvH9jZPUuKMt/PJcMtKz9u9pF4PR/Uoj6et+fZiy8vzdm91vKOwmnfr88PyfrO9vsyvF7v72/v5rD2M5RqB9hMoYLi0CwXQ5vYWMFwoTPunauX6/w1kqedTwPF7CPRjBeLgqUAQAFmqcQMScPtBhNWmqwHuCIBEkL9ETFZvHnJvYmk4IIIozNaD+xwBAQo1WnhQwH3OfU5A4wZkyWqWxJL7DIRHq96KpXahMNqeR4OHAAICKc13AAVQMd8JlMJ8p4fffwLnHw3uZuuB9hBE4eB5whJIEW4z1oLVrJZ4UP4RCxSIGEYABIUxIxXD0S47P/V8akc7Jn2BwPI4nH9cTTR3/B4QpSZQEkigJAJCFEoACUgSIAASkCBUklBJIEsEIIS+H3rfar5TCiAC2/OndgFFbdvOSFK96WqzajuF7vWObbtR1VO13dWFHtu2uR7btm3btj3f+Cg2+f8/qBOI6D8DSZJkVO26ljHr9gWLTp1Oi4aZUpzdYp6uDAlI0CABQIrTLGwSVDWyTAcAqzkLXQlgtGplY4Vqiss4Titb452a+SSyvXGaVONlvr9OQU/tsUyRDZIKICZdydUl25KsElSluKR0WQ3nsMVLiDM6SLXJyhJbAvB7l8H/zF73v2v/HtzODyTYma1kM4LLSRJK/vr6nEQ+3/FnxLRQcgKKh3x9R9q+3DnKb8aEKw3FE56SXu9P8iPD6FIren0lI27vYjBoBvzTX5IxXxpbmILINzLudgMlBR0ekBl+a48UvXWAOZXoekek6duiwx3i+fDxgyYfhZlcD+tptMF/g1+yzAvA0/eTgK39CwG0WsZnstuP7zTvF/hPEMuiwoIVGz9vWVKAZRzLEBm1adeWlQWeBcR6MiA5NbBi0ksuyaKlxLoUi9hMiicfYZNawXfl5VAkaC3rcJ8Y5hbtIt7N2KxmUjyLq0TzsFmwjl3jaXOKGD55lpLI5W0UPCOOPSHepZ4PDG+nQnKJIgrGfSMvhXwo3Exb/ccukcjWy7l7sAPSBQ9VwZg800jsyuXUt8exl0IWtyLWGZAET0TBeGvgqgZzu1HbVfvEmXzAF0GzLHiprHrH9Spync1u/eL+3Vt5vV4PFfpbetu27b98K3fRtVrA8nYyEgTX3AX+OPW4rrSt9IYa1K1Zo0I5dwUPoczPFSpWqVm3cXNP3wVKUz+ugc4HJJfmPPXrObFtYdPaFd2sHHwSNRrktF3Qhud2GJkMiZj8gifYqFY5NcX6LJXbkLfSrwp1K7gZqzQAz7MRSGWIwwzBWW1R5nu3QgOUY6i9krrWKZ3lronybs7QBo63MxHHREVgn+hKr1oqS6ExGtetqJCzgRY3K/Ojuy6a167CHgl8Js7jbFAH8i4Qb5smzGGuAeQokWoWqNdu9dLZFUMIsYty+hHPRT/zbpcRuUqiUb0yv2Sr50iZrRCar94quZV+y2LyUHdX9FnApTw4mC07XyeBK5RS6gf2EOWsYFLpoxYmk3L1sZREhCHziEtunUqlfipbuSlW8FcjGlbLdrvL184pEt/V1zvArgf63A8I5gJtthDvvNZATghF3T6TkCvtkclylTT8vHHJwo0fNFNZuHAL8yzWMZOJdpcpOu5lccB3KEocDMDJXrdHo8Rp7skTg7OvosKz1YhnSMaYB1HhNnPfshteiM6azHODa3gXBd6cBlz8c3P1nSjwcKzg9W9DeA/PvxHlMavYvT/jctWVagZt23q9LSO9t/EcZubZWQlnnxHnu8e7p08ZrThygNDRo8dPWXPu3jvR+Cyswq/yTntI09eqTxnVDEjTw53UF6dw9JD0+GGrqr72u9xY1KwvyH+dO3ceNEdflKM+2LX+S4btITPdP1Dz28spBc7eNJFbZ3V8ftrhO/3QxOoT7EIYMHzMrPLoTD7SLTpMRieTyl226ivtT980o1VU9TT6zl5+Y/Ru3XPWp1k1Lj/f2MMPja12dHhAshv8bet09vAz/U+6PWfDiON/XQysNfDsgYd6eH9nz5mBAclmwo9nMnydzh698PCN+HDf2XN0dc8AUl0WM3QmWxEeNvPY0T2Xryteu3zg6LHVA8OQ0l0W07QnSgiEew4YN+6PceMGdAoHICXLLou5yrbU+BgJgBSTmGpz6M/PAgA=" alt="Regular">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Regular</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">29 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="World Tennis- Loja virtual" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-14" data-gslide="14" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo_world-tennis-loja-virtual_IZveB2.png" src="./assets/logo_world-tennis-loja-virtual_IZveB2.png" alt="Descontos World Tennis- Loja virtual"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">World Tennis- Loja virtual</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" alt="Ótimo">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Ótimo</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">3 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="PneuStore" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-15" data-gslide="15" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo_pneustore_4KxfZF.png" src="./assets/logo_pneustore_4KxfZF.png" alt="Descontos PneuStore"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">PneuStore</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" alt="Bom">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Bom</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">13 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Brastemp" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-16" data-gslide="16" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo_brastemp-consul_vCaf77.png" src="./assets/logo_brastemp-consul_vCaf77.png" alt="Descontos Brastemp"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Brastemp</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" alt="Ótimo">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Ótimo</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">17 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Nova Flor" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-17" data-gslide="17" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo.png" src="./assets/logo.png" alt="Descontos Nova Flor"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Nova Flor</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" alt="Bom">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Bom</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">3 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="Skinceuticals Brasil" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-18" data-gslide="18" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/logo_skinceuticals-brasil_Ffoywt.png" src="./assets/logo_skinceuticals-brasil_Ffoywt.png" alt="Descontos Skinceuticals Brasil"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">Skinceuticals Brasil</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRsYGAABXRUJQVlA4TLkGAAAvP8APEF8HMbZtVc0+9wBx9/778+Dcd+JpAZIjSYokz6qoocUj7/7/d8MYlQk5kiRFUmQtH79Pf/GWmbrCQNo28W/2vYIpctuE6QROvAMADAh4YP8kEDDggYCAgFJeUkm1h/bQHpJKamRL6vvu54lSedkdpPS83RvH9jZPUuKMt/PJcMtKz9u9pF4PR/Uoj6et+fZiy8vzdm91vKOwmnfr88PyfrO9vsyvF7v72/v5rD2M5RqB9hMoYLi0CwXQ5vYWMFwoTPunauX6/w1kqedTwPF7CPRjBeLgqUAQAFmqcQMScPtBhNWmqwHuCIBEkL9ETFZvHnJvYmk4IIIozNaD+xwBAQo1WnhQwH3OfU5A4wZkyWqWxJL7DIRHq96KpXahMNqeR4OHAAICKc13AAVQMd8JlMJ8p4fffwLnHw3uZuuB9hBE4eB5whJIEW4z1oLVrJZ4UP4RCxSIGEYABIUxIxXD0S47P/V8akc7Jn2BwPI4nH9cTTR3/B4QpSZQEkigJAJCFEoACUgSIAASkCBUklBJIEsEIIS+H3rfar5TCiAC2/OndgFFbdvOSFK96WqzajuF7vWObbtR1VO13dWFHtu2uR7btm3btj3f+Cg2+f8/qBOI6D8DSZJkVO26ljHr9gWLTp1Oi4aZUpzdYp6uDAlI0CABQIrTLGwSVDWyTAcAqzkLXQlgtGplY4Vqiss4Titb452a+SSyvXGaVONlvr9OQU/tsUyRDZIKICZdydUl25KsElSluKR0WQ3nsMVLiDM6SLXJyhJbAvB7l8H/zF73v2v/HtzODyTYma1kM4LLSRJK/vr6nEQ+3/FnxLRQcgKKh3x9R9q+3DnKb8aEKw3FE56SXu9P8iPD6FIren0lI27vYjBoBvzTX5IxXxpbmILINzLudgMlBR0ekBl+a48UvXWAOZXoekek6duiwx3i+fDxgyYfhZlcD+tptMF/g1+yzAvA0/eTgK39CwG0WsZnstuP7zTvF/hPEMuiwoIVGz9vWVKAZRzLEBm1adeWlQWeBcR6MiA5NbBi0ksuyaKlxLoUi9hMiicfYZNawXfl5VAkaC3rcJ8Y5hbtIt7N2KxmUjyLq0TzsFmwjl3jaXOKGD55lpLI5W0UPCOOPSHepZ4PDG+nQnKJIgrGfSMvhXwo3Exb/ccukcjWy7l7sAPSBQ9VwZg800jsyuXUt8exl0IWtyLWGZAET0TBeGvgqgZzu1HbVfvEmXzAF0GzLHiprHrH9Spync1u/eL+3Vt5vV4PFfpbetu27b98K3fRtVrA8nYyEgTX3AX+OPW4rrSt9IYa1K1Zo0I5dwUPoczPFSpWqVm3cXNP3wVKUz+ugc4HJJfmPPXrObFtYdPaFd2sHHwSNRrktF3Qhud2GJkMiZj8gifYqFY5NcX6LJXbkLfSrwp1K7gZqzQAz7MRSGWIwwzBWW1R5nu3QgOUY6i9krrWKZ3lronybs7QBo63MxHHREVgn+hKr1oqS6ExGtetqJCzgRY3K/Ojuy6a167CHgl8Js7jbFAH8i4Qb5smzGGuAeQokWoWqNdu9dLZFUMIsYty+hHPRT/zbpcRuUqiUb0yv2Sr50iZrRCar94quZV+y2LyUHdX9FnApTw4mC07XyeBK5RS6gf2EOWsYFLpoxYmk3L1sZREhCHziEtunUqlfipbuSlW8FcjGlbLdrvL184pEt/V1zvArgf63A8I5gJtthDvvNZATghF3T6TkCvtkclylTT8vHHJwo0fNFNZuHAL8yzWMZOJdpcpOu5lccB3KEocDMDJXrdHo8Rp7skTg7OvosKz1YhnSMaYB1HhNnPfshteiM6azHODa3gXBd6cBlz8c3P1nSjwcKzg9W9DeA/PvxHlMavYvT/jctWVagZt23q9LSO9t/EcZubZWQlnnxHnu8e7p08ZrThygNDRo8dPWXPu3jvR+Cyswq/yTntI09eqTxnVDEjTw53UF6dw9JD0+GGrqr72u9xY1KwvyH+dO3ceNEdflKM+2LX+S4btITPdP1Dz28spBc7eNJFbZ3V8ftrhO/3QxOoT7EIYMHzMrPLoTD7SLTpMRieTyl226ivtT980o1VU9TT6zl5+Y/Ru3XPWp1k1Lj/f2MMPja12dHhAshv8bet09vAz/U+6PWfDiON/XQysNfDsgYd6eH9nz5mBAclmwo9nMnydzh698PCN+HDf2XN0dc8AUl0WM3QmWxEeNvPY0T2Xryteu3zg6LHVA8OQ0l0W07QnSgiEew4YN+6PceMGdAoHICXLLou5yrbU+BgJgBSTmGpz6M/PAgA=" alt="Regular">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Regular</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">3 descontos </strong>disponíveis</div>
                  </div>
                </a><a href="" title="LOUNGERIE" data-testid="discount-item" class="border rounded-lg border-gray-200 py-6 px-3 w-[166px] inline-block bg-white hover:shadow-md mx-2 first:ml-0 lg:first:ml-2 glider-slide right-19" data-gslide="19" style="height: auto; width: 192px;">
                  <div class="flex flex-col justify-center items-center">
                    <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyload" width="48" height="48" data-src="./assets/company_3d089662-bcf0-43bf-8eff-ae8834df85f3.png" src="./assets/company_3d089662-bcf0-43bf-8eff-ae8834df85f3.png" alt="Descontos LOUNGERIE"></div>
                    <p class="font-semibold text-center truncate w-28 text-steel">LOUNGERIE</p>
                    <div class="flex gap-2 items-center mt-3.5 h-[38px]"><img width="20px" height="20px" src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" alt="Bom">
                      <caption class="reputation-label font-bold text-sm text-steel svelte-1f8qxsj">Bom</caption>
                    </div>
                    <div class="mt-4 flex flex-col items-center justify-center h-[60px] w-[100%] p-4 text-bowl bg-[rgb(31_105_193/10%)] rounded-md"><strong class="text-center font-bold">7 descontos </strong>disponíveis</div>
                  </div>
                </a></div>
            </div> <button aria-label="Anterior" class="ECZrW-glider-prev pt-1 absolute top-0 z-40 h-12 w-12 mt-24 rounded-full
     bg-white border border-[#e1e3e5] transition-all cursor-pointer
     text-green-800 hover:bg-gray-200 -left-12 hidden lg:block" title="Voltar itens" style="z-index: 1;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path>
              </svg></button> <button aria-label="Próximo" class="ECZrW-glider-next pt-1 absolute top-0 z-40 h-12 w-12 mt-24 rounded-full
     bg-white border border-[#e1e3e5] transition-all cursor-pointer
     text-green-800 hover:bg-gray-200 -right-12 hidden lg:block" title="Avançar itens" style="z-index: 1;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
              </svg></button>
            <div id="ECZrW-dots" role="tablist" class="dots svelte-d0i8ki glider-dots"><button data-index="0" aria-label="Page 1" role="tab" class="glider-dot active"></button><button data-index="1" aria-label="Page 2" role="tab" class="glider-dot "></button><button data-index="2" aria-label="Page 3" role="tab" class="glider-dot "></button><button data-index="3" aria-label="Page 4" role="tab" class="glider-dot "></button><button data-index="4" aria-label="Page 5" role="tab" class="glider-dot "></button><button data-index="5" aria-label="Page 6" role="tab" class="glider-dot "></button><button data-index="6" aria-label="Page 7" role="tab" class="glider-dot "></button><button data-index="7" aria-label="Page 8" role="tab" class="glider-dot "></button><button data-index="8" aria-label="Page 9" role="tab" class="glider-dot "></button><button data-index="9" aria-label="Page 10" role="tab" class="glider-dot "></button><button data-index="10" aria-label="Page 11" role="tab" class="glider-dot "></button></div>
          </div>
        </div>
      </astro-island>
    </div>
  </section>

  <astro-island uid="Z2l6fUN" component-export="default" props="{}" client="visible" opts="{'name':'TouchpointApp','value':true}" await-children="">
    <div class="touchpoint-container relative h-80 w-full mt-10 bg-no-repeat bg-cover svelte-1vcu23q" style="background-image: url(./assets/touchpoint-bg.5846d1ea.webp)">
      <div class="flex items-center max-w-[1200px] h-full w-full m-auto svelte-1vcu23q">
        <div class="content-container flex flex-col gap-4 max-w-md lg:mr-14">
          <h2 class="font-semibold text-[32px] svelte-1vcu23q">Agora o Reclame AQUI está na palma da sua mão!</h2> <span class="text-steel">Faça uma reclamação ou pesquise a reputação de uma empresa de onde estiver!</span> <a class="flex justify-center w-52 py-2 px-6 font-semibold text-sm text-white rounded bg-pickles svelte-1vcu23q" href="https://conteudo.reclameaqui.com.br/app-ra?utm_source=organic&amp;utm_medium=home-ra&amp;utm_campaign=touchpoint-desk-app-ra">Conheça o app do RA</a>
        </div> <img class="lg:mr-20 hide-in-mobile" src="./assets/app-touchpoint.9179ed5b.webp" alt="Celular apresentando o aplicativo do Reclame Aqui" width="283" height="322"> <img class="hide-in-desktop" src="./assets/app-touchpoint_mobile.49eb0c8e.webp" alt="Celular apresentando o aplicativo do Reclame Aqui" width="360" height="374"> <img class="absolute right-4 top-4 hide-in-desktop" src="data:image/webp;base64,UklGRpQGAABXRUJQVlA4TIcGAAAvUAAUEAcHobZtJ86+6Q0DMRD/vnoFZv7n2oBb27ZVZZ4DIfcVYAP2X5TpN5IDsmFFsu1a6fXeI8MxgAHMowQh/N7iBvJZDiLbFpIlAY8GNACj2cgmv4I2eCbg/gQ/oOka56poDvOaqOERYd41jFm1F/PvTCjGbKgxm2LOqhDGrIRxbYSCSnH7OlHfxr3ZPq+MWQnFnFWhGOeGsq0oFSlUBDoCIlukT9IRqEhBKIg0RKAoQtKBItKBIEFFCRNyARR+TVYh3RBFZNGJxQk2GoR/E5xdJKvpoSdS4Uonxz1v8rZTMy4uuufl1e8G1xzj/vtflM9xz573/xCqhAZKqkGqKYHqU0Kh6H9RfQpNYZJHzBYiLbkA1QgnzE7UsXEpfTwJf9Dcunz+qz3HoRN90dkv90vpuzP45vD78QTrUEgFivWk2M6i1pNtqoHahmIfpIptkFoHahsatqmGbaphu5AK1qHYzlrWE2JZT5b1hHh5f0GkalnD0/EkxdMxpGpZA/H89ixVT8ewrCEFdf559frx5tj31yR3lvjm83thoLBtmyG5qt5kGdu2bSfTuzm2T2w7WWMqtm3bNnpi28lv6a76vq+q9wdURfTfgSSpcTMrShiDfEo5nsCU9WXskF+GfZcW6Hvz25CR41mo+vL/L2kuLjNswPiwIkO+d+kyA77oZ9xfqa6aUn8er9n71QUU6WU62W4mQgjodL5IGZFOradkRrmkaOaMlp2w0j90OWP7C5HW6VFOkWndB34xBmiJ/uH6ap/OFZTZridY9Fl9TD8aaRXliopOhZw01axB/pi+p0OQkzpWib9d2ylXRyQ7ym1OOyD4l5JFmmnJ8GtbcGszegJNwbpoiVrb1RVaG1fZHWzbRLkemrq+otNcUENIjHRbcW0yPuktXVgjSUfVaNbOaN2KN8fWlPE4vulV/qyCCNJ+xEfQbTbDndbUIhqKxbSbtVm5vB3WxsBM4OGorUgnkR9AJuWS0DfxO/GOYhsAsYWHp8x0y21ORBzws8xyHrqaoiVzwkcKpQJ9ISBD7MaKzKNQv3KZYr7K1aGwtVq5UsWsNZXrIysfOMhawqlWjHNkJZRpgl1hMQOdU3WIHLH7FLACz4h3YCXACWUdYwzRaS8mk7YrOLgqApRWOacMYHOtuhlTA/ApKoMN8pmZVRrMFBELqhlfCm5zeZYugWnsEFVMIN4hqp5IgcDv6J5kKqYe0qODwZvfMrMBpI5DppzSRRpp8JbCJMUyS9ApEjwFOsXg4k9rQLY5xihs1nEU1ATcMWqVnm1jKtmyaiclqLdQuAKkIs7bRw9fy695MZEXD5/Q50A7gaVKe97GPPmsU6TMB96dJAKlwMShMMVQ7njmFfBOxgu+Zx4qJE5R56VnzCP/5J1A3ATc9cztt85rS2QmgdIYz3zMHXtbJC7A8xW75z0nhjMEVqgsik88UQLCRqInCKcSyJDlINUwnovcExBTYiKvMBqCDFCaUIkxgftiSumAhwJ38EUEZNRarpL4WDjrN+LzrhTwJhbwBF2mYUYzmLoOod0RZ1Q5aQ15fceLPSX0YBkzm+FWEm1J7+R1E7ht79AJFddEZoq4bC6E2RZPXmvB24ZaAy7T0mc4/vWiQZwE6fGUVTXb3mcg4cOxAc1NIL4rxd/Xsh/ywF8l0heCjVhrHE+xJqQZV7R2p+ZTbLses2QKxD3GLOWoqsSjBt3ORlCwZrr4VaVLFBzr94DV3BKcZHiF2IrcuDoVy1hbrmoT+fybZ4OZo+lf0mzjKiWT4xwTX6z8Vk7XwUtXDvtdukQH137DBFbw0LT3/HHwB05QLfJ1Q2h2aTeHmOb38nfxpWHZjUPoT9k/mQm1O3hT3AtVf/OJmRC7nWe8U9iPd6EHutn6ozduHcF+cwajgFqt/WjetQMc7wcyWItRTu9Seu09c3YHx/vhzEcltOP0pSO0gDnpe5cPEf6tCGowreeo9py/fuXs4f3g899/9Ox1D/Kwd/8jw7WSE3T04i3PXL9kLpyzl65c9wJdPb2P9C9Ad/dfRtEyTtKhExcv3xJqb12/ePbYDk5TZ/9YNC3kdO3YZ6yKWrg/MUNu4aiZbLSdoZAVrOYqLQzr9ydT0/IN2q3vf0xV62brZfoIeR4VlqwW/zA9WrdAF9GJH5k2LddTtGky06rlm9S91Uy71i1USd+waDULR6sXzSWx0Y+Eqe2rl87ftFGunbtwxartrJBonbW6xjMA" alt="Ervilho do Reclame Aqui sorrindo" width="48" height="48">
        <div class="flex items-end h-full p-12 hide-in-mobile"><img src="data:image/webp;base64,UklGRpQGAABXRUJQVlA4TIcGAAAvUAAUEAcHobZtJ86+6Q0DMRD/vnoFZv7n2oBb27ZVZZ4DIfcVYAP2X5TpN5IDsmFFsu1a6fXeI8MxgAHMowQh/N7iBvJZDiLbFpIlAY8GNACj2cgmv4I2eCbg/gQ/oOka56poDvOaqOERYd41jFm1F/PvTCjGbKgxm2LOqhDGrIRxbYSCSnH7OlHfxr3ZPq+MWQnFnFWhGOeGsq0oFSlUBDoCIlukT9IRqEhBKIg0RKAoQtKBItKBIEFFCRNyARR+TVYh3RBFZNGJxQk2GoR/E5xdJKvpoSdS4Uonxz1v8rZTMy4uuufl1e8G1xzj/vtflM9xz573/xCqhAZKqkGqKYHqU0Kh6H9RfQpNYZJHzBYiLbkA1QgnzE7UsXEpfTwJf9Dcunz+qz3HoRN90dkv90vpuzP45vD78QTrUEgFivWk2M6i1pNtqoHahmIfpIptkFoHahsatqmGbaphu5AK1qHYzlrWE2JZT5b1hHh5f0GkalnD0/EkxdMxpGpZA/H89ixVT8ewrCEFdf559frx5tj31yR3lvjm83thoLBtmyG5qt5kGdu2bSfTuzm2T2w7WWMqtm3bNnpi28lv6a76vq+q9wdURfTfgSSpcTMrShiDfEo5nsCU9WXskF+GfZcW6Hvz25CR41mo+vL/L2kuLjNswPiwIkO+d+kyA77oZ9xfqa6aUn8er9n71QUU6WU62W4mQgjodL5IGZFOradkRrmkaOaMlp2w0j90OWP7C5HW6VFOkWndB34xBmiJ/uH6ap/OFZTZridY9Fl9TD8aaRXliopOhZw01axB/pi+p0OQkzpWib9d2ylXRyQ7ym1OOyD4l5JFmmnJ8GtbcGszegJNwbpoiVrb1RVaG1fZHWzbRLkemrq+otNcUENIjHRbcW0yPuktXVgjSUfVaNbOaN2KN8fWlPE4vulV/qyCCNJ+xEfQbTbDndbUIhqKxbSbtVm5vB3WxsBM4OGorUgnkR9AJuWS0DfxO/GOYhsAsYWHp8x0y21ORBzws8xyHrqaoiVzwkcKpQJ9ISBD7MaKzKNQv3KZYr7K1aGwtVq5UsWsNZXrIysfOMhawqlWjHNkJZRpgl1hMQOdU3WIHLH7FLACz4h3YCXACWUdYwzRaS8mk7YrOLgqApRWOacMYHOtuhlTA/ApKoMN8pmZVRrMFBELqhlfCm5zeZYugWnsEFVMIN4hqp5IgcDv6J5kKqYe0qODwZvfMrMBpI5DppzSRRpp8JbCJMUyS9ApEjwFOsXg4k9rQLY5xihs1nEU1ATcMWqVnm1jKtmyaiclqLdQuAKkIs7bRw9fy695MZEXD5/Q50A7gaVKe97GPPmsU6TMB96dJAKlwMShMMVQ7njmFfBOxgu+Zx4qJE5R56VnzCP/5J1A3ATc9cztt85rS2QmgdIYz3zMHXtbJC7A8xW75z0nhjMEVqgsik88UQLCRqInCKcSyJDlINUwnovcExBTYiKvMBqCDFCaUIkxgftiSumAhwJ38EUEZNRarpL4WDjrN+LzrhTwJhbwBF2mYUYzmLoOod0RZ1Q5aQ15fceLPSX0YBkzm+FWEm1J7+R1E7ht79AJFddEZoq4bC6E2RZPXmvB24ZaAy7T0mc4/vWiQZwE6fGUVTXb3mcg4cOxAc1NIL4rxd/Xsh/ywF8l0heCjVhrHE+xJqQZV7R2p+ZTbLses2QKxD3GLOWoqsSjBt3ORlCwZrr4VaVLFBzr94DV3BKcZHiF2IrcuDoVy1hbrmoT+fybZ4OZo+lf0mzjKiWT4xwTX6z8Vk7XwUtXDvtdukQH137DBFbw0LT3/HHwB05QLfJ1Q2h2aTeHmOb38nfxpWHZjUPoT9k/mQm1O3hT3AtVf/OJmRC7nWe8U9iPd6EHutn6ozduHcF+cwajgFqt/WjetQMc7wcyWItRTu9Seu09c3YHx/vhzEcltOP0pSO0gDnpe5cPEf6tCGowreeo9py/fuXs4f3g899/9Ox1D/Kwd/8jw7WSE3T04i3PXL9kLpyzl65c9wJdPb2P9C9Ad/dfRtEyTtKhExcv3xJqb12/ePbYDk5TZ/9YNC3kdO3YZ6yKWrg/MUNu4aiZbLSdoZAVrOYqLQzr9ydT0/IN2q3vf0xV62brZfoIeR4VlqwW/zA9WrdAF9GJH5k2LddTtGky06rlm9S91Uy71i1USd+waDULR6sXzSWx0Y+Eqe2rl87ftFGunbtwxartrJBonbW6xjMA" alt="Ervilho do Reclame Aqui sorrindo" width="80" height="80"></div>
      </div>
    </div>
  </astro-island>



  <div class="desktop-banner-wrapper mt-[24px]">
    <astro-island uid="1uVEJG" component-export="default" props="{'slotId':[0,'div-gpt-ad-3071949-2'],'mode':[0,'desktop'],'minWidth':[0,970]}" client="only" opts="{'name':'PureGoogleAdsSlot','value':'svelte'}">
      <div role="banner" class="w-full overflow-hidden justify-between items-center svelte-1o7974m">
        <div class="flex flex-col items-center relative m-[initial] justify-center bg-white p-0 md:p-[6px] border border-[#c9cfcc] rounded-[4px] min-w-[--min-width] min-h-[250px]" style="--min-width: 970px;">
          <div id="div-gpt-ad-3071949-2" class="flex w-full bg-[#f1f4f3] items-center justify-center min-h-[250px]" data-google-query-id="CI-lyJTTiYsDFflY3QIdQxs4gA">
            <div id="google_ads_iframe_/21702246488/RA_Home_EntrePosts_Desktop_0__container__" style="border: 0pt none; display: inline-block; width: 970px; height: 250px;"></div>
          </div>
          <div class="inline-flex py-0 px-1 text-[10px] bg-white mt-1">
            <div class="svelte-yntaf6"><span data-text="Ah! No Reclame AQUI, empresas ruins, não recomendadas e em análise não são anunciadas. 

   Caso veja alguma, não deixe de nos avisar: auditoria@reclameaqui.com.br" class="svelte-yntaf6">Publicidade
                <img src="./assets/error_outline.82d7840e.svg" alt="Icone publicidade" class="svelte-yntaf6"> </span></div>
          </div>
        </div>
      </div>
    </astro-island>
  </div>



  <astro-island uid="2k3GEz" component-export="default" props="{}" client="visible" opts="{'name':'Blog','value':true}" await-children="">
    <div class="flex flex-col items-center pb-4 w-full mt-[24px]"><a href=""><img width="200" height="61" src="./assets/logo-blogra.b7bc97fc.webp" alt="Logo Blog do Reclame Aqui"></a>
      <div class="flex flex-nowrap overflow-x-auto gap-4 mt-9 w-[92%] lg:w-full lg:justify-center"><a href="" class="flex flex-col min-w-[252px] max-w-[252px] rounded-2xl border border-iron" style="background-image: url(./assets/BLOG_Sephora-pos-BF_capa-300x250.png); background-size: 100% 105px; background-repeat: no-repeat; border-radius: 10px 10px 0px 0px;" title="'Comprou na Sephora na Black Friday e não recebeu o produto? Reclamações sobem no Reclame AQUI e Procon-SP notifica empresa'">
          <div class="flex flex-col items-start py-6 px-4 justify-between gap-8 mt-[90px]"><span class="title text-sm text-[#333] font-semibold max-h-[100%] min-h-[40px] max-w-[216px] svelte-ltwbjn">"Comprou na Sephora na Black Friday e não recebeu o produto? Reclamações sobem no Reclame AQUI e Procon-SP notifica empresa"</span> <button class="flex items-center font-medium text-sm text-bowl">Leia mais
              <div class="icon svelte-ltwbjn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                  <path d="M13.293 7.293c-.391.391-.391 1.023 0 1.414l2.293 2.293h-7.586c-.552 0-1 .448-1 1s.448 1 1 1h7.586l-2.293 2.293c-.391.391-.391 1.023 0 1.414.195.195.451.293.707.293s.512-.098.707-.293l4.707-4.707-4.707-4.707c-.391-.391-1.023-.391-1.414 0z"></path>
                </svg></div>
            </button></div>
        </a><a href="https://blog.reclameaqui.com.br/empresas-ra1000-de-dezembro-veja-quais-empresas-finalizaram-o-ano-com-essa-conquista/" class="flex flex-col min-w-[252px] max-w-[252px] rounded-2xl border border-iron" style="background-image: url(./assets/Blog_Empresas-RA1000_Janeiro_Capa-300x250.png); background-size: 100% 105px; background-repeat: no-repeat; border-radius: 10px 10px 0px 0px;" title="'Empresas RA1000 de dezembro: veja quais empresas finalizaram o ano com essa conquista'">
          <div class="flex flex-col items-start py-6 px-4 justify-between gap-8 mt-[90px]"><span class="title text-sm text-[#333] font-semibold max-h-[100%] min-h-[40px] max-w-[216px] svelte-ltwbjn">"Empresas RA1000 de dezembro: veja quais empresas finalizaram o ano com essa conquista"</span> <button class="flex items-center font-medium text-sm text-bowl">Leia mais
              <div class="icon svelte-ltwbjn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                  <path d="M13.293 7.293c-.391.391-.391 1.023 0 1.414l2.293 2.293h-7.586c-.552 0-1 .448-1 1s.448 1 1 1h7.586l-2.293 2.293c-.391.391-.391 1.023 0 1.414.195.195.451.293.707.293s.512-.098.707-.293l4.707-4.707-4.707-4.707c-.391-.391-1.023-.391-1.414 0z"></path>
                </svg></div>
            </button></div>
        </a><a href="https://blog.reclameaqui.com.br/precos-do-material-escolar-estao-em-alta-veja-alternativas-para-gastar-menos/" class="flex flex-col min-w-[252px] max-w-[252px] rounded-2xl border border-iron" style="background-image: url(./assets/BLOG_Precos-do-Material-Escolar_capa-300x250.png); background-size: 100% 105px; background-repeat: no-repeat; border-radius: 10px 10px 0px 0px;" title="'Preços do material escolar estão em alta: veja alternativas para gastar menos!'">
          <div class="flex flex-col items-start py-6 px-4 justify-between gap-8 mt-[90px]"><span class="title text-sm text-[#333] font-semibold max-h-[100%] min-h-[40px] max-w-[216px] svelte-ltwbjn">"Preços do material escolar estão em alta: veja alternativas para gastar menos!"</span> <button class="flex items-center font-medium text-sm text-bowl">Leia mais
              <div class="icon svelte-ltwbjn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                  <path d="M13.293 7.293c-.391.391-.391 1.023 0 1.414l2.293 2.293h-7.586c-.552 0-1 .448-1 1s.448 1 1 1h7.586l-2.293 2.293c-.391.391-.391 1.023 0 1.414.195.195.451.293.707.293s.512-.098.707-.293l4.707-4.707-4.707-4.707c-.391-.391-1.023-.391-1.414 0z"></path>
                </svg></div>
            </button></div>
        </a><a href="https://blog.reclameaqui.com.br/como-usar-ferramentas-do-reclame-aqui-para-compras-seguras/" class="flex flex-col min-w-[252px] max-w-[252px] rounded-2xl border border-iron" style="background-image: url(./assets/BLOG_ferramentas-do-Reclame-AQUI-para-compras-seguras_capa-300x250.png); background-size: 100% 105px; background-repeat: no-repeat; border-radius: 10px 10px 0px 0px;" title="'Da reclamação à resposta e avaliação, tudo vira informação: como usar ferramentas do Reclame AQUI para compras seguras'">
          <div class="flex flex-col items-start py-6 px-4 justify-between gap-8 mt-[90px]"><span class="title text-sm text-[#333] font-semibold max-h-[100%] min-h-[40px] max-w-[216px] svelte-ltwbjn">"Da reclamação à resposta e avaliação, tudo vira informação: como usar ferramentas do Reclame AQUI para compras seguras"</span> <button class="flex items-center font-medium text-sm text-bowl">Leia mais
              <div class="icon svelte-ltwbjn"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                  <path d="M13.293 7.293c-.391.391-.391 1.023 0 1.414l2.293 2.293h-7.586c-.552 0-1 .448-1 1s.448 1 1 1h7.586l-2.293 2.293c-.391.391-.391 1.023 0 1.414.195.195.451.293.707.293s.512-.098.707-.293l4.707-4.707-4.707-4.707c-.391-.391-1.023-.391-1.414 0z"></path>
                </svg></div>
            </button></div>
        </a></div> <a href="https://blog.reclameaqui.com.br/" class="bg-[#1f69c1] text-white px-6 py-2 font-medium text-sm rounded-sm mt-8 w-[90%] lg:w-[184px] flex justify-center">Ver outras matérias</a>
    </div>
  </astro-island>

  <section class="my-[80px] astro-BGPACKS7">
    <div class="w-full xl:max-w-[1200px] mx-auto flex flex-col xl:flex-row align-middle astro-BGPACKS7">
      <div class="main-div xl:max-w-[380px] flex flex-col gap-6 astro-BGPACKS7">
        <h2 class="main-title fw-600 xl:text-4xl text-lg astro-BGPACKS7" style="align-self: center">
          Veja a opinião de quem já comprou
        </h2>
        <img loading="lazy" src="./assets/trustvox-slider@300.webp" alt="Avatar de alguns usuarios" width="300" height="58" class="xl:hidden astro-BGPACKS7">
        <h2 class="main-text hidden xl:block astro-BGPACKS7">
          Valorizamos a voz do consumidor e asseguramos a veracidade das opiniões.
        </h2>
        <span class="main-sub-text w-full sm:w-full astro-BGPACKS7">
          RA Reviews é a única plataforma especializada em coletar opiniões
          verdadeiras, verificadas pelo Reclame AQUI.
        </span>
        <div class="icons-div astro-BGPACKS7">
          <span class="astro-BGPACKS7">Avaliações reais, auditadas por</span>
          <a href="https://site.trustvox.com.br/?utm_source=reclameaqui&amp;utm_medium=cta&amp;utm_campaign=reclamacao&amp;utm_content=homera" target="_blank" class="flex items-center astro-BGPACKS7">
            <img src="./assets/logo-ra-reviews.df42dc68.svg" alt="Logo Reviews" width="100" height="50" class="astro-BGPACKS7">
            <img src="./assets/arrow-right-top.1126fc82.svg" alt="Icone seta apontando para o noroeste" width="11" height="12" class="mt-1 ml-1 astro-BGPACKS7">
          </a>
        </div>
        <img loading="lazy" class="hidden xl:block astro-BGPACKS7" src="./assets/trustvox-slider@380.webp" width="380" height="74" alt="Avatar de alguns usuarios">
      </div>

      <!-- Segunda coluna -->
      <div class="overflow-x-auto lg:overflow-x-visible py-6 pl-4 w-[93%] lg:w-full astro-BGPACKS7">
        <div class="
          cards-div w-full h-auto my-auto
          flex flex-nowrap gap-4
          lg:grid lg:grid-cols-[350px_350px] lg:gap-4 lg:justify-center
          md:gap-8 md:grid-cols-2 md:grid-rows-2
         astro-BGPACKS7">
          <astro-island uid="Z14MGCm" component-export="default" props="{'class':[0,'astro-BGPACKS7']}" client="visible" opts="{'name':'TrustReviewsSvelte','value':true}" await-children="">
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_refrisol_HMrsVV.png" src="./assets/logo_refrisol_HMrsVV.png" alt="Refrisol"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">Refrisol</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" class="review-badge svelte-14ui6ex" alt="Logo da empresa Refrisol"> <span class="review-badge-span svelte-14ui6ex">Ótimo</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.6</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 82%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">82%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 8%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">8%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 3%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">3%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 5%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">5%</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">56 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/refrisol/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_casa-dos-quimicos_mxL70V.png" src="./assets/logo_casa-dos-quimicos_mxL70V.png" alt="Casa Dos Químicos"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">Casa Dos Químicos</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRp4EAABXRUJQVlA4TJIEAAAvP8APEK/loI0kR3LN7t0/f8A5UXDYto0kUd7v+i/4hmHbtpGopPfsP/Adg9p2gtwlYA3ABjYwg42NYBNGgils2wbpmHcHoFE46D8a9UHX37sr199LJJffI/nIH/d1zSZxYyKQGEgEErOCg8ZCilR48SDu56/b/4OF7/I9P2o2u1IR4rxvIulK0rK2knUvkbRMI1nPSsRsVBKH/R4iGUMkxt1vjJZ9HYnYz7G2hOjEoSvrWi1Jkhj7PmZDdNKVpNKSrC1RqYhKIlZL7PsQiUgqP/rez/zRHx/9eKBSgYRt28w6ntC8aWq3p81RbXc3Xdu2bds2sratIqeLav7gySTzzWxE/yG4kRy2mT3hpJVySVpFkL/ANKm2fXRzLdOnukkdHaNqgxlr2/boBm3fscX21BTMVOGjtOsxJ4+2BepZsCbYgnSY42xBYyYwmaZ0CJ+nZaqeNmY86ePVd+pYNdZz2sYme6HCnDQTAGBmZBWGLGFBfWuHPVGNqY2N9VOZVZRlhKvmbz9648abN9fOHF45swwZRaXaqpbmGuGZR58nhrlfw70fL22oQk5ITy8b0bVPh7lcv99emBnNUF9gFRjhnQlO1MDnS4uRo9gpMbHgBVfQwNtzM80iFQqN6NEBrqZfj1ahgE4Byu9wZQ08PRfNsojkYMZPrkNvz0XTaJGnq3H+nhgF6BKarm6GnCJEn3JtDD89F8mT7lYjfINr1MD9VQhJMLFugEDi8dnj+/adJe2FXqfLtCRe+S+5c3CF7dP0LR/l8ep6sFVq4gqX8Fh0AjonCNaSQKsAM6XeaVuqs9L4cj0SVJCQOZ/mMW3h8uXLp4ndhLSgswQlAfPVfXL22dN233aFj3BMiOOU6VwfGdjG5bj73KDv4LFe/n91ZhqWuBq4x9XkeszhUt3fj5B/nOCKIvLOP8zEkhFFPnosl9PtVJkCaTiimo977JEz6MyDN2EBd1XzdI/3XC5no1C0BPiixuO5Yibw6CSKkoQQ+6HEWaG/yKXw8hzyxVd2q3DIpjf++jpy1dlq+2ZJvHOQ40O1f5wTee0n1q224aY95FRenhMGxYh8IbPLg97405PIFwvdJ7MiyWZO5/4BoZAFnCYzR3ZgyU+e1eIPNwVrlLhDp9/pguWRjZl/qRzbt2/fezofnHia79yIqG18pZU5jIkTx/4HQ/4ZxjIw/99/4JsTN/3XFUSeENmzaO6Ky/Tj4IA3FocGlo3Qzyv7MZFuZyYCrmD51LRC6Vf3+LyXA9MQnX3UXCHkoOmrFDYLnKZVebzJn/1Fyim3nvezvSOLeGScj5ulsnsLFgxR4ti+sy6Jr04liplExcCOIa5LrjMf+UyqfODIiCb+PliCLMYoEdk7pK2lWYwWWKcjup35QqPG8m5VRj6er0G2pXBvR/ymmtn/7ECcUk1ygcPyVwruu/NdMFUffvKT5rZXtAV/Pt1aGkGupeO5CfGZF1zZHhr8/vJADZCu68nL9Iy9F7+7/f8G//X3fHl3avWsCIzcENOmYs9ApKJmVlI1MQBGeqHF9KqkKDc91QBgpKRnF4boDgM=" class="review-badge svelte-14ui6ex" alt="Logo da empresa Casa Dos Químicos"> <span class="review-badge-span svelte-14ui6ex">Sem reputação definida</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.8</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 89%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">89%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 7%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">7%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 2%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">2%</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">156 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/casa-dos-quimicos/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_gfi-nutrition-industria-e-comercio_8ImXAa.png" src="./assets/logo_gfi-nutrition-industria-e-comercio_8ImXAa.png" alt="Gfi Nutrition Industria e Comercio"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">Gfi Nutrition Industria e Comercio</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRp4EAABXRUJQVlA4TJIEAAAvP8APEK/loI0kR3LN7t0/f8A5UXDYto0kUd7v+i/4hmHbtpGopPfsP/Adg9p2gtwlYA3ABjYwg42NYBNGgils2wbpmHcHoFE46D8a9UHX37sr199LJJffI/nIH/d1zSZxYyKQGEgEErOCg8ZCilR48SDu56/b/4OF7/I9P2o2u1IR4rxvIulK0rK2knUvkbRMI1nPSsRsVBKH/R4iGUMkxt1vjJZ9HYnYz7G2hOjEoSvrWi1Jkhj7PmZDdNKVpNKSrC1RqYhKIlZL7PsQiUgqP/rez/zRHx/9eKBSgYRt28w6ntC8aWq3p81RbXc3Xdu2bds2sratIqeLav7gySTzzWxE/yG4kRy2mT3hpJVySVpFkL/ANKm2fXRzLdOnukkdHaNqgxlr2/boBm3fscX21BTMVOGjtOsxJ4+2BepZsCbYgnSY42xBYyYwmaZ0CJ+nZaqeNmY86ePVd+pYNdZz2sYme6HCnDQTAGBmZBWGLGFBfWuHPVGNqY2N9VOZVZRlhKvmbz9648abN9fOHF45swwZRaXaqpbmGuGZR58nhrlfw70fL22oQk5ITy8b0bVPh7lcv99emBnNUF9gFRjhnQlO1MDnS4uRo9gpMbHgBVfQwNtzM80iFQqN6NEBrqZfj1ahgE4Byu9wZQ08PRfNsojkYMZPrkNvz0XTaJGnq3H+nhgF6BKarm6GnCJEn3JtDD89F8mT7lYjfINr1MD9VQhJMLFugEDi8dnj+/adJe2FXqfLtCRe+S+5c3CF7dP0LR/l8ep6sFVq4gqX8Fh0AjonCNaSQKsAM6XeaVuqs9L4cj0SVJCQOZ/mMW3h8uXLp4ndhLSgswQlAfPVfXL22dN233aFj3BMiOOU6VwfGdjG5bj73KDv4LFe/n91ZhqWuBq4x9XkeszhUt3fj5B/nOCKIvLOP8zEkhFFPnosl9PtVJkCaTiimo977JEz6MyDN2EBd1XzdI/3XC5no1C0BPiixuO5Yibw6CSKkoQQ+6HEWaG/yKXw8hzyxVd2q3DIpjf++jpy1dlq+2ZJvHOQ40O1f5wTee0n1q224aY95FRenhMGxYh8IbPLg97405PIFwvdJ7MiyWZO5/4BoZAFnCYzR3ZgyU+e1eIPNwVrlLhDp9/pguWRjZl/qRzbt2/fezofnHia79yIqG18pZU5jIkTx/4HQ/4ZxjIw/99/4JsTN/3XFUSeENmzaO6Ky/Tj4IA3FocGlo3Qzyv7MZFuZyYCrmD51LRC6Vf3+LyXA9MQnX3UXCHkoOmrFDYLnKZVebzJn/1Fyim3nvezvSOLeGScj5ulsnsLFgxR4ti+sy6Jr04liplExcCOIa5LrjMf+UyqfODIiCb+PliCLMYoEdk7pK2lWYwWWKcjup35QqPG8m5VRj6er0G2pXBvR/ymmtn/7ECcUk1ygcPyVwruu/NdMFUffvKT5rZXtAV/Pt1aGkGupeO5CfGZF1zZHhr8/vJADZCu68nL9Iy9F7+7/f8G//X3fHl3avWsCIzcENOmYs9ApKJmVlI1MQBGeqHF9KqkKDc91QBgpKRnF4boDgM=" class="review-badge svelte-14ui6ex" alt="Logo da empresa Gfi Nutrition Industria e Comercio"> <span class="review-badge-span svelte-14ui6ex">Sem reputação definida</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.8</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 90%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">90%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 4%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">4%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 2%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">2%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 2%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">2%</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">44 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/gfi-nutrition-industria-e-comercio/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_skelt-cosmeticos_ihKYwu.png" src="./assets/logo_skelt-cosmeticos_ihKYwu.png" alt="Skelt Cosméticos"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">Skelt Cosméticos</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRrIJAABXRUJQVlA4TKUJAAAvQMAPEDVRlv/ftOzsasS2bV/bRmzbtm3btu2M7hvkvsHNG+QRUrX3Wmvvc57g3Fupnp1niDm22aMehQ9g9OzOkpH/VdHUzqmMepYqj5yhbXtV31nQI8TpqhX0NO6qPY6NU/fUPrFOnBFHO3aGHtm27fQo6KqYQ9tm3zt3IEmSafXs+/e/07Nt49u2INq2bbpZ5/3/iJ3atu3Gtm0nNQZD2tqDKAwhhBCGMIQfYQaFMIMyaAZlUAbLYAgXomRbQZtzHuEJCcVU0PyCTpocSNYcxZoRNiCLTIQDizWnjHjWTDmMOklKzayZctowwSsSNiMy47UBm9awBdWayWQCF4qciw3JZLzxbMGqnVZrkoshdpQYWESmY8uUypi2Go3xGIINJ4/4SR5qSzKYoA2T16id0pENo58iaU62II5B3nWvpp8QWi5MDiThL3Egc6ByoHHg4sDLgcHLgdtu0uNHQGY1/qG2jHaMNaf81qBoWg00EDLE8XYcmCk/xiLOo4qq7pSWn6vTWtSoNoW3Wn9ThfGB/LtXQTcZqT5Glh+SA6HNgUbgwM0BWR2riqzuNazPaIdXEbEhfUZh9ZP0rl3AgWMErWVJfL5Fm4bVbi+jkmzAmBNmmQR22kiMdhBtFtaUYkMlu1uIVQbMZtSU45dP99pVebCHamRd5pInlj9es4vXDqLMotrgtaiGJog0i4HZ7tXgbWbf4stbVHPb4tUKaZ6B2Si9pPh8U527hWrF6p1Nvmaj5FKHuYJqyWqdLXxI7K3G20ElUr2/IbepT4htlt9jxbzF1HcaNaZRkuWHx8B8rwQehsLKZxKziTZlYZkohETFJHJhIkMmWIGDA/ED+bRuYCcOBzbIYRKWAKdF2aiSeN8fddmLCCWN90SuhPaADgDBGIA+k1vHDoRojdcLu0iB48XgwAopPt80J1qRTtUvEx4pMZHma6y6YBN6Dn9XTFAx2wcKIfg5VZHShrQ5KT7fwJIimKEaZw9FqdNZkuzv269TqaraEAm9t0CuswBZVQnhj1BMc4/UVGZ8QayJAwFBVzmtCAZYnu73i5uKGIugP43SiZgjCTUGwakRbQ4hHDI5tYCPSF2DvYWi/N0wQVWxSPf3bQdaenFBVsmGIxSXP2hOsiJEudEpMIvULYhmCCIz7bzA3oFGXsW0RALBEcMr+KagPnUFAXtyZYaK/WMUxe+xzI2nJiA5IBaAfNdOdMmYBIFwJGSMWCRSfb2rR13VmqBH6C49vkLqHgFSfL5pQpqG8brKsxtMhX5Tx6XxGkPOl3WuYr6uGAhVE/K0JD7fYAQMDpyQZ+vlgFKHvcyDJxYAkBMQE6gI4CmZRBn5OYTO2esNE2KQsCDoibQkGIWbJwEHdsJxhcEpilJlsMsDfQHIDhDGK7B/NaowZv+M1yLhZYBSk2v4oRF8G5HnYVTrb0NoF0gPgN1aBASKae5EXsYgb/n1deaBXhDp3QcUB0qwDn2NL9yLwIECczQlT8Go3VolNAudSEcuJCqO9xVT3zlDJev1kbIcJXWkdRuAjhE40CD7cRh+Wdmn+nrTv0rwELZDC4rJ8VOR0RebP/qGkmhGsvkWW4gc6FBQ5eCAbhdRllHZLyL6zZVAohTCmJTmOvO7m0glhFTeH0qPr5WY36vTWtGGoEXAcAfMhmAHpcY3BCqOD+Q/OJSWXSkvOnVJ7hO/VN7vBiRMM83nSKP6FEoHHmxAAg0TWL8fRVimZH5uy3USRIjn+oNvETjwo9Dn4tgbXKr0901/t6PAOisJhdLhB5Md0S9yJRa/RnuLoijlB+fKi8/gtCIalBZfAQ48GFU6BxwowY3HtGGiq1xJLKp3KmBw2AGbh59TBetKPkP2R4LF/q5Z2UxpQFkSJ06cRuQ5DiQ4MIgQk5dLz8/dVp2/aQdK8Jy4wXc5sb/Y/xxKbx6AIkqh/OBMS6IJugU1akyj2tWAHzwMUxoQyk1PzT6z5uxwP2lqLkUXT+AifKA/0SsywiKFFTg47KBhS5RllFNq7zfVuVvaEtRwGpNn4QNxoMFoY2PspJ+9Q9GEtMNP78Q8Os/i3KIYcBqSF+Cr2Aey21V8gxJ8kyerXnqnL/7YQUJf3E0Ze/3XqdSYwMfKjfgiVjI9NkHH+CJG16YLj6p65cIEY5le2+bttoz8zP2Cf7zz3fTzxmeMDfKrm6qqAi749av4AnZjXB48kQ5DhEUKtmO5de4zCMN9XS/XTKIlAF+KY5FoQp4xBTysQ5kU7kAOHfLq/RYlrripHN3c3LwdRVaxl/59ZU8M59FgUsJWOgdyOMAbLCOCPJYq3akGfD3t+1hGlz5/hyp8JzIoxHva8lBqcgP5cG3GhiT/f/KqwrI4diT/+fb6ogvFJCEFx4W6Yt45t3HFhk7LbK7g9RTE+4krjIacUFPSlFRfb86xWM7JbtfkzV7v6oyFPh3LER06vlfnst79zZCLosISL4slzyqCVRCcwbZ9gxJknUe8ndy7vG9N5jahcshhGpXObcyCeI77mw95eyf/+YLo/eblD0Yd0h5a5mQLb5aHjlXxY+cq3ENg1ulEqhsppVU7e1gBeQDCjIHWVRZRQyxK2DkWy4ms4NoFq13QmlSZ4YpvTJS63IVUhyf7/VFw5mOREPyMllnVOQGCSbkCr4mDjE3pANXau9iDPH62DYFWVQXkfoUnHuIUHrsljn/nBFrXsIrCI2i5zxkZRcRJIftJhNKUPI3Sm/PpvNwvsVjSvk9EHtJkucjIRYxt5CwPbe6sgMGJok6oZD8JQ29mYk2lJjeUZiQ7Sg3X8/F/9n2SLIulP8nyqITiohRUO8HD0h7uPIVoTjbL+tzg/uAyuTZRPHIhqVcxoRNOUZHLonLeZUh61yFi6U7i4+GSHJgTIUFvYO6Rx2kyYkGZT2GJxzZ33FFE7FZo6rWoLAfcVPWR5nOkOn8Tobe7iYQHVMkxtom/sQzGMjn1fCWTHNTPrqEPwt5uakhZgBXJj7hXKM4GyicJ2a3pX4aGCzvL++qrr3oOvizJat+W8usTi/3dDvj+W5+yQiktvuYrFMnxMNytKFebKKU7nNNtwtiD8SaMW3p+bgfC/t+IMk9RToSLNPu15gpzeCIJUXLW3dNwvMY/dMxwN5/8bBBtMDUnWvFZTea2u+GiJXWay4EwTyQkygFX29/RmqhnotRkakk0sm9CntaAukQRMl+zj047+nDgAz/bsmLyRy8rIr5cUO3wNFw0gk57GifdEp4e7dilPF9WlJc9K/BP3TBa2tc+uMjVqNOyxo5dOdC3nAEAYIYt+3LtWIP/uA4A" class="review-badge svelte-14ui6ex" alt="Logo da empresa Skelt Cosméticos"> <span class="review-badge-span svelte-14ui6ex">Ótimo</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.7</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 84%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">84%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 6%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">6%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 4%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">4%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 1%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">1%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 3%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">3%</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">1197 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/skelt-cosmeticos/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_forever-liss-professional_3ajzf9.png" src="./assets/logo_forever-liss-professional_3ajzf9.png" alt="Forever Liss Professional"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">Forever Liss Professional</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRsoHAABXRUJQVlA4TL0HAAAvP8APECK62v4rcpu9Hl9FbiktMzPDzArMJGaWZmbDzMzMzImezPwP7CgXcCozQ52K0SgIH9O/DXPMVOVRt+WeMKOgM3Rh1mP2BYSTiiX5dKldp5BD27axV/uvksq2bdtOOtu2v/+rYttWZxvPtjudP3aqZ31Sbm1Tw2h+TzVzoE1mPpxTx0ySHFeTY+Zl5l1JjjUoSiqXeQO31ra3ickZ/sMEcYDY41CRU0clNvgnwNrA2kBiAnsD2e6o4gCOPWGBy8Bt2zhSg2RX1w3d8QZxbTcWPtSUNSakCEJaZUQQnGwPv0OcwIRCA1SFxMLv7ARO/MWEliZ0YILuwGCD0AHiR2CVAR9N6E9Xf+82IgYhTW8dIqIBSYWoMaFtxAgXpVxRLeWKWMoVgRMDvoqI2HXeLATOa2gEPTG55MeP3av+/Usv//37e5/XL24DMAuCExOSgfF+FIEQPd3L4Io/f2pX///fLeUKJx6+f12xcPRgBbdgXjAJQnMTmi+qcTGh78jlDJd5BjhWzPC48u/f5yn6yr9//zPWbz8FYDYDMDM80wQRK+5tQEiMkGglIzoakyefbKdN2qiwWyEfLSpvRMRyIS78+rVx9f//Q60v/Pr1LTi6c9rCoGRR8DgEKdaneKLCTMdmLcJoeiCqR4qjxl3x509fa33KSZYHYMJSzvlGHp/kREoKHckw+iRBnFiL428872vXEw7evQRgVkq5YkbwsYjYA+zPVRhQqW4TzqdTWuvHQg+fPAZgFgWvO8EfAlK9kOS0EncE26/9Ou162a9fU+vew7MAzLwIi1tzooDktrCw0wm3X/HiostPfx2yFq43Q7oteJjV2BiBfeQlOpIXi7V2bhly0VXGi/MoF6fWy4BAbJzBN9UBS/njgMkFl3/7AsYARMQb2QRgZg1Id6+KsxLNRngkOSHuKGZSBy+u0J7nH2fi1HqA4MgiALO0JqLzrQB2rzhxPp06oOOG9moD4kUFdxQxicM3D4C4/PsXO7cMgzNwHgcBmJnn10PcXxOhrdXanEM5fd6Xtw6bWbR7Yxc+CksTh27s04B9xmdZfCsnCsDM5eZw9c141kqot5qYtfPQeVrrcz+/8lEYcfDiqp5StlVhXuajweCpbXhoLUQ29KiQ1Dzu3POPtNaXXOeO2z1Sw4pDNw7A+KeYSUgp3RS5l6PFwodRJrRExKAoS84JbRdbaadsdtyHp8AQT33xALVoOmB+GYxT3z1WyCTcLGWcqEDEyAxG0VAO51yCNbH4qcyCWExitU3Dy4RmNmggZYdBuw1N04CLrnK71HeSwAQrQrxGGmhruyI0J8qRsqAk0SatzuYRZQomllz67TMwzqc/ApSwVknjoEdh71ZNu6mQzCCA0C709w1kvHeTO2U22Ca6Qlxpi2u6gIW70mKtoqo2F15mNOCwpVVjJaS4wHGB7x92ixUWYFzF/FRqXmi72Ao7ZjG3wXPs1tCpuKrNRZcZDTj6ziUlTEqSgvfYECE4GjFpS/iptPzI9rGVdsxmjxLtpnP2X9OAi69zdlkzCSB3NOCjYGvAp+7rRkLHpuVF7otjWjyqGdq17SSNVjLCqzm6CkJzxFayTBL2S84NTcvsncPgqO1DY1mY0ME8dpjQd7hAlp2zAtc7MxuonPXxpX5S0hcYjfxAIqKkWFSaaJ1aZ8B0Cq/sXNdB0kEEjScwKikWlCRiE6ttlRDoSnLg5DyLtejkJwKE7UYafyAkPRBImhn5sW1jKrSrGERwwtN7hjHyvwg1IB36W68a0MmYUOn30PV7rJ8B1+1S30EyaK/NEBEj5bcL1uYuiNiN/rWpiE+psVViCJzqsKU1UyHktHenbbUBH2sEh1MizC9GVmHsvoKJRS7nH73RT7KXIzX837zudP7ulBXYNKyU2+EbkkV3RBzCRyMiM+WXJIz4Ku3LB+mjtw/1ZJHqiRC9xP/J7Ralfyrqto4qd/Sje5jrom7mTcTU+4nxwkzIDuQUNWLm1rICkTc1IWGCNZJUZ45lxXuIyJtM+Lsh5XOrTciHCR0iYrITkmGY7EQQca4BKX4bMmTIIsFrxCu5GQ/qeeH/MCJ2j/IRhUc0hMeNCH2Qoxj/4K2s378w/nvgynejnBXiqPCYBYgRUc2IiP8lWJOsYJCf5IyXcnx0ccVPYDhx4voeAe/78CjHSHU7TyryN5CzB9raCeQyVkQ5+64Uw7o0sr7ZHLPv9hphE2RKJSQxPtraMWWTrQohbp8lwtYRuFKprGEEiFdSLbWlC/n8d0BaGVHOnhsUURCELyqlSt4Dj8QkZr1Hub1w2AgoeohUWhlrdinYREo5e67lCyGCQxcVryTw89wppJS4HV6vUlWf42CllArt2aYfLPboFMLa+7AuykWUI1Z/r5RS3/7ewYd5KIfS6AMWQeJRpRQgFj40fjTPJkiVIoYCSj+guAvZHSGG7QSfiMUQWwBdBf3mJR8JUdOhADp7+ENchE1UdQijQ1hc51rhC7YAPwCTIWAxtAcD4ZsWuTsXa88V4nsPm1wGKSIfPJw92wH41VFoH9pCTHf24N3lewG19yBzqfCP6WrwPhQEQbSXiKH8otRk4Z+2AIbLBdDeg1Qpm2yVdi9H+Ag5WBEiSAaH9iAXhK+5lIXLQ+Sylyjtf14EAA==" class="review-badge svelte-14ui6ex" alt="Logo da empresa Forever Liss Professional"> <span class="review-badge-span svelte-14ui6ex">RA1000</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.7</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 86%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">86%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 6%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">6%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 2%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">2%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 3%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">3%</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">2557 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/forever-liss-professional/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_terra-cruz_wxvWHU.png" src="./assets/logo_terra-cruz_wxvWHU.png" alt="Terra Cruz"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">Terra Cruz</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRp4EAABXRUJQVlA4TJIEAAAvP8APEK/loI0kR3LN7t0/f8A5UXDYto0kUd7v+i/4hmHbtpGopPfsP/Adg9p2gtwlYA3ABjYwg42NYBNGgils2wbpmHcHoFE46D8a9UHX37sr199LJJffI/nIH/d1zSZxYyKQGEgEErOCg8ZCilR48SDu56/b/4OF7/I9P2o2u1IR4rxvIulK0rK2knUvkbRMI1nPSsRsVBKH/R4iGUMkxt1vjJZ9HYnYz7G2hOjEoSvrWi1Jkhj7PmZDdNKVpNKSrC1RqYhKIlZL7PsQiUgqP/rez/zRHx/9eKBSgYRt28w6ntC8aWq3p81RbXc3Xdu2bds2sratIqeLav7gySTzzWxE/yG4kRy2mT3hpJVySVpFkL/ANKm2fXRzLdOnukkdHaNqgxlr2/boBm3fscX21BTMVOGjtOsxJ4+2BepZsCbYgnSY42xBYyYwmaZ0CJ+nZaqeNmY86ePVd+pYNdZz2sYme6HCnDQTAGBmZBWGLGFBfWuHPVGNqY2N9VOZVZRlhKvmbz9648abN9fOHF45swwZRaXaqpbmGuGZR58nhrlfw70fL22oQk5ITy8b0bVPh7lcv99emBnNUF9gFRjhnQlO1MDnS4uRo9gpMbHgBVfQwNtzM80iFQqN6NEBrqZfj1ahgE4Byu9wZQ08PRfNsojkYMZPrkNvz0XTaJGnq3H+nhgF6BKarm6GnCJEn3JtDD89F8mT7lYjfINr1MD9VQhJMLFugEDi8dnj+/adJe2FXqfLtCRe+S+5c3CF7dP0LR/l8ep6sFVq4gqX8Fh0AjonCNaSQKsAM6XeaVuqs9L4cj0SVJCQOZ/mMW3h8uXLp4ndhLSgswQlAfPVfXL22dN233aFj3BMiOOU6VwfGdjG5bj73KDv4LFe/n91ZhqWuBq4x9XkeszhUt3fj5B/nOCKIvLOP8zEkhFFPnosl9PtVJkCaTiimo977JEz6MyDN2EBd1XzdI/3XC5no1C0BPiixuO5Yibw6CSKkoQQ+6HEWaG/yKXw8hzyxVd2q3DIpjf++jpy1dlq+2ZJvHOQ40O1f5wTee0n1q224aY95FRenhMGxYh8IbPLg97405PIFwvdJ7MiyWZO5/4BoZAFnCYzR3ZgyU+e1eIPNwVrlLhDp9/pguWRjZl/qRzbt2/fezofnHia79yIqG18pZU5jIkTx/4HQ/4ZxjIw/99/4JsTN/3XFUSeENmzaO6Ky/Tj4IA3FocGlo3Qzyv7MZFuZyYCrmD51LRC6Vf3+LyXA9MQnX3UXCHkoOmrFDYLnKZVebzJn/1Fyim3nvezvSOLeGScj5ulsnsLFgxR4ti+sy6Jr04liplExcCOIa5LrjMf+UyqfODIiCb+PliCLMYoEdk7pK2lWYwWWKcjup35QqPG8m5VRj6er0G2pXBvR/ymmtn/7ECcUk1ygcPyVwruu/NdMFUffvKT5rZXtAV/Pt1aGkGupeO5CfGZF1zZHhr8/vJADZCu68nL9Iy9F7+7/f8G//X3fHl3avWsCIzcENOmYs9ApKJmVlI1MQBGeqHF9KqkKDc91QBgpKRnF4boDgM=" class="review-badge svelte-14ui6ex" alt="Logo da empresa Terra Cruz"> <span class="review-badge-span svelte-14ui6ex">Sem reputação definida</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.9</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 94%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">94%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 1%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">1%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 2%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">2%</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">115 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/terra-cruz/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_leao-de-nemeia_dQXbU6.png" src="./assets/logo_leao-de-nemeia_dQXbU6.png" alt="leão de neméia"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">leão de neméia</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRp4EAABXRUJQVlA4TJIEAAAvP8APEK/loI0kR3LN7t0/f8A5UXDYto0kUd7v+i/4hmHbtpGopPfsP/Adg9p2gtwlYA3ABjYwg42NYBNGgils2wbpmHcHoFE46D8a9UHX37sr199LJJffI/nIH/d1zSZxYyKQGEgEErOCg8ZCilR48SDu56/b/4OF7/I9P2o2u1IR4rxvIulK0rK2knUvkbRMI1nPSsRsVBKH/R4iGUMkxt1vjJZ9HYnYz7G2hOjEoSvrWi1Jkhj7PmZDdNKVpNKSrC1RqYhKIlZL7PsQiUgqP/rez/zRHx/9eKBSgYRt28w6ntC8aWq3p81RbXc3Xdu2bds2sratIqeLav7gySTzzWxE/yG4kRy2mT3hpJVySVpFkL/ANKm2fXRzLdOnukkdHaNqgxlr2/boBm3fscX21BTMVOGjtOsxJ4+2BepZsCbYgnSY42xBYyYwmaZ0CJ+nZaqeNmY86ePVd+pYNdZz2sYme6HCnDQTAGBmZBWGLGFBfWuHPVGNqY2N9VOZVZRlhKvmbz9648abN9fOHF45swwZRaXaqpbmGuGZR58nhrlfw70fL22oQk5ITy8b0bVPh7lcv99emBnNUF9gFRjhnQlO1MDnS4uRo9gpMbHgBVfQwNtzM80iFQqN6NEBrqZfj1ahgE4Byu9wZQ08PRfNsojkYMZPrkNvz0XTaJGnq3H+nhgF6BKarm6GnCJEn3JtDD89F8mT7lYjfINr1MD9VQhJMLFugEDi8dnj+/adJe2FXqfLtCRe+S+5c3CF7dP0LR/l8ep6sFVq4gqX8Fh0AjonCNaSQKsAM6XeaVuqs9L4cj0SVJCQOZ/mMW3h8uXLp4ndhLSgswQlAfPVfXL22dN233aFj3BMiOOU6VwfGdjG5bj73KDv4LFe/n91ZhqWuBq4x9XkeszhUt3fj5B/nOCKIvLOP8zEkhFFPnosl9PtVJkCaTiimo977JEz6MyDN2EBd1XzdI/3XC5no1C0BPiixuO5Yibw6CSKkoQQ+6HEWaG/yKXw8hzyxVd2q3DIpjf++jpy1dlq+2ZJvHOQ40O1f5wTee0n1q224aY95FRenhMGxYh8IbPLg97405PIFwvdJ7MiyWZO5/4BoZAFnCYzR3ZgyU+e1eIPNwVrlLhDp9/pguWRjZl/qRzbt2/fezofnHia79yIqG18pZU5jIkTx/4HQ/4ZxjIw/99/4JsTN/3XFUSeENmzaO6Ky/Tj4IA3FocGlo3Qzyv7MZFuZyYCrmD51LRC6Vf3+LyXA9MQnX3UXCHkoOmrFDYLnKZVebzJn/1Fyim3nvezvSOLeGScj5ulsnsLFgxR4ti+sy6Jr04liplExcCOIa5LrjMf+UyqfODIiCb+PliCLMYoEdk7pK2lWYwWWKcjup35QqPG8m5VRj6er0G2pXBvR/ymmtn/7ECcUk1ygcPyVwruu/NdMFUffvKT5rZXtAV/Pt1aGkGupeO5CfGZF1zZHhr8/vJADZCu68nL9Iy9F7+7/f8G//X3fHl3avWsCIzcENOmYs9ApKJmVlI1MQBGeqHF9KqkKDc91QBgpKRnF4boDgM=" class="review-badge svelte-14ui6ex" alt="Logo da empresa leão de neméia"> <span class="review-badge-span svelte-14ui6ex">Sem reputação definida</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.8</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 85%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">85%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 10%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">10%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 4%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">4%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 0%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">--</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">49 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/leao-de-nemeia/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
            <div class="review-card flex flex-col svelte-14ui6ex" role="button" tabindex="1">
              <div class="flex">
                <div class="flex mr-4">
                  <div class="
  logo-container w-12 h-12 rounded-full overflow-hidden flex
  justify-center items-center bg-gray-300 border-gray-200 border-2
  undefined
"><img class="object-cover lazyloaded" width="48" height="48" data-src="./assets/logo_dark-lab_sHigau.png" src="./assets/logo_dark-lab_sHigau.png" alt="Dark Lab"></div>
                </div>
                <div class="flex flex-col"><span role="heading" aria-level="1" class="text-sm font-bold mb-2 text-[#333]">Dark Lab</span>
                  <div class="flex mb-2"><img src="data:image/webp;base64,UklGRmAGAABXRUJQVlA4TFQGAAAvP8APEB8HKZIkR1JE7Un+OA7bar3b8TwKkCJJciRFVvfv+DM6PFrfdWc4bNvIkeSZufANfH1f9deRL+/aQNo28W/2vYIRTNJU2zEAYEDAA/vngYABDwQEBJS+atXC1unC1umqrXbV3qepVq3aalftkkXa7uVlfXT37h4e0vyTdbqb9jhfaf7I7HDv7vkXHvcr7fKyeOaUdn76C3uvJu3yukA8c7q8LR493D42t7O5f+6u/6vnz+n88/f6u5y+ft6n2T9ZQGXZIN7sEO8eFg1C8PtQRByZe4dAcUDSJiMCgRaQzS4CkIAJIlpANktI2sxIhKArIAiwz33DgEAgKUEFZLbMJAGWoYAkwFzmBBEtJg0lASJgNyKT0UwSgUBAhYYAolw+143LCMAmEymOCXAwE2aSFgYCSZIEBCFdZDPMBMQIMDgiYABGRJKgAmQmSCEQVAFBgLmTAGGSYDIhoOIkgSQCSQJTtr9PiMDjdwGWeN4fsACCsb/HB1DUtu2MJNWbqWmraru6kl67Pbbt9O6WxrZt27Ztr8dmW3+bZ1L5/y+oE4joPwO3jRSltwyau8X7gs2g3G5dOyS702ad5AQ7YJdp4gHY3VaRKEGTk8YBTQnWEAdOkt5bhgEWZcoRvAvXtzCef5JME8bHxFLZLRNNwqHJYRInACnWFezP5YiyS/wXDIuKd8laxBkpAbI53PEOLccRAfjnrNh7prGx8eyeFZP8QIST+5JJSRZUdEVJmLj7eSGjVPhg9zggxpquXBEYsfZ5GdNX8d8b/FZE5DiM2JzHjCpnhx8JZnPtWPCCmdHD2SanXgL8J0qYORUHMx3GicG4/5l5PTRRKwbTc5gV+m8yYoy6hdY4xl5NR5yxFtM/M5GCdwW6vCMteTXWSKED/ldizlYvAM/SdwRVSwMAxm8VLfnHjy901wv8VxnPgYDaq22LFl1VbBXYgsFdW7Ro0Vf1nGS8Lo2Q3DrYsaNEMHJUN4VXt8ABwZIOCq9e4qsUr0GEXt4soYeTozIVUS1QFaQWLRVRnVHFOL0eCyeZZ8dFxvHe2+MrAqXvtCDe3t8qhLp5CjhKD0OSqR6JcNmQnxSKpjFVrDo7hXwTZeg2YQ1ORzyxWImQedt9R6L03cbWd/9JIek6nvE6BonY7IiwenTKNzRt5rKprX6gacI7otglEIGDZTz7B6Ukc2S14EjzsEDK90HS2xLJUzylOxFBzLlHjGd9vxTeXnRSOHnY6JRgzSa1r0h/oYDdGCHJumm2rA/vdYbapqP2lTwMmpcGtXVbXT6ORSJHJHYVifTjB7lJBRfNmsa8GT8qiqICQnSgSN5KxApHzXEmsH9Yynd8siv3ml3Xs3ndf00O2tG5q8Kj1guUHkEY1ytGVopUox0/Sygj9w8JVqSUhbdM0DW+0yT88YiJmjok5WuKzh7GCgLtfv2SfJMlTOSxH9ridWHcS0YFvX8hrExTT2nfMjvjZ4KeVMie/o4kruXM14zQdvT+OVn4RCo/RMuzM37kTWnqi32MYgJcIvST3SUtaGJWf4gjvA4D2n+pKKld1QDp2OuZcBqBfVgOjFGBqTVM1KnxgDoGgblvGcnLKUjkCWbrRBr2728o0DXl9Okabi82kEjElKcsNCrnSYL/foi4MwJuft7eChGXhZ2nGc6VhIT8QwjniMbGnJDwkVu3fMNHIaqp7RtCQVkIKL4MyMS++Yli2kkTVM37i7oEbSSOfwfGVlBUez0n3xmi4OQ0etnc5tJ8UsJ5+q51yotpJ//VzVkaCGwvYFR4AXbyTjyzgtGqWe5FYNr6bSfrqupOHlg/z4vAUr1lc3uGdnCSQQ7TX3zb5k4d7/V6x09duv70n0xPn4SQKra4k+KbPr3/igisrrCUu4sRo/tfNPL8Gwt5c8HA9dMJ35UcC52POHPJDsdet+rJvfIb4m0GFIvpFj2fDDlh/U+58saKUsoZKfSdf2b63l1+wafrdKafb+PtHHPVbq4aLpn6gXXbMfP87XzjO135hQnUD6GJWovP3zNUoexj+ZXFwyWHzbTc0fDNPH/zSU4JScnH8puH5g9HrPbTZ0XEjgmrjl6/Wf7sdVAvn927ef3Q4gmQ4mWbZdJ+MIdPmL9o06ZdmzYtmjlhOKRol2yzVi5HbHhzCYDULDLWYeJv0wY=" class="review-badge svelte-14ui6ex" alt="Logo da empresa Dark Lab"> <span class="review-badge-span svelte-14ui6ex">Bom</span></div>
                  <div class="flex align-middle justify-center"><span class="text-xs mr-1">4.6</span>
                    <div class="trustvoxstar-container svelte-cihrb7"><button title="Revisões Trustvox" class="flex h-[0.88rem]"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#e0a200"></path>
                        </svg> <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                          <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#e0a200"></path>
                        </svg>
                        <div>
                          <div class="arrow-icon-down md:block hidden svelte-cihrb7"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svelte-c8tyih">
                              <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                            </svg></div>
                        </div>
                      </button>
                      <div class="popover-trustvox-hidden svelte-cihrb7">
                        <div class="flex flex-col gap-[6.13px] cursor-pointer">
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">5</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 83%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">83%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">4</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 7%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">7%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">3</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 2%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">2%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">2</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 1%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">1%</span>
                          </div>
                          <div class="flex">
                            <div class="flex mr-2 justify-center items-center"><span class="mr-[2px] text-[13px] text-[#4b5963] font-bold">1</span>
                              <div class="star-icon svelte-gc88k4"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-7fuq16">
                                  <path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z" fill="#4b5963"></path>
                                </svg></div>
                            </div>
                            <div class="progress-bar-wrapper svelte-gc88k4">
                              <div class="progress-bar-content svelte-gc88k4" style="width: 6%; background: #e0a200"></div>
                            </div> <span class="ml-2 text-[13px] text-[#4b5963] font-bold">6%</span>
                          </div>
                        </div>
                      </div>
                    </div> <span class="text-[13px] text-[#4b5963] ml-1">4826 opiniões</span>
                  </div>
                </div>
              </div> <a class="review-card-link svelte-14ui6ex" href="https://reclameaqui.com.br/empresa/dark-lab/reviews-da-loja/" target="_self" title="Ver todas as opiniões">Ver todas as opiniões</a>
            </div>
          </astro-island>
        </div>
      </div>
    </div>
  </section>

  <section class="ra-para-empresas w-full py-10 svelte-18kf50a">
    <div class="flex items-center gap-12 svelte-18kf50a">
      <div class="flex flex-col gap-6 max-w-[466px]">
        <h2 class="text-4xl font-bold text-white svelte-18kf50a">Soluções para empresas</h2>

        <p class="text-white hide-in-mobile"><b>Todo mundo pesquisa antes de comprar, inclusive quem compra da sua empresa!</b>
          Esteja presente em toda a jornada do seu cliente.
          <br>
          <br>
          <b>Sua empresa ainda não está no Reclame
            <em class="not-italic uppercase">Aqui </em>
            ?
          </b>
          <a title="Benefícios de se cadastrar no Reclame Aqui" href="https://conteudo.reclameaqui.com.br/para-empresas" target="_blank" id="home_card_homeb2b" class="underline">Veja os benefícios de se cadastrar.
          </a>
        </p>

        <p class="text-white hide-in-desktop"><b>Todo mundo pesquisa antes de comprar, inclusive quem compra da sua empresa!</b> Esteja presente em toda a jornada do seu cliente.
        </p>
        <img src="./assets/ra-for-companies.8aa4648b.webp" class="w-[306px] h-auto hide-in-mobile" alt="Vantagens de se cadastrar no Reclame Aqui">
      </div>

      <div class="advantages svelte-18kf50a"><a href="https://produtos.reclameaqui.com.br/lp-brand-page-reclameaqui?utm_source=lp-produtos&amp;utm_medium=site-ra&amp;utm_campaign=brandpage-home-sessao-b2b" title="Conheça a RA Brand Page" id="home_card_brand_page" class="box-border flex flex-col shrink-0 justify-between w-[224px] h-[256px] p-4 rounded transition-shadow bg-white hover:shadow-md">
          <div class="flex flex-col gap-[10px]">
            <div class="flex items-center justify-center py-[6px] bg-[#F1F9E6] rounded"><span class="text-[13px] font-bold text-[#006130]">Personalize sua página</span></div>

            <div class="flex flex-col gap-3">
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Tenha o selo de verificação do Reclame AQUI</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Gere confiança e credibilidade para quem busca pela sua empresa</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Personalize a página com sua identidade</span>
              </div>
            </div>
          </div>

          <span class="inline-flex gap-1 text-[13px] text-bowl font-semibold">Conheça a RA Brand Page

            <img src="./assets/arrowRightBlue.0a7fe311.svg" alt="Seta para direita"></span>
        </a><a href="https://produtos.reclameaqui.com.br/lp-trustvox-reclameaqui?utm_source=lp-produtos&amp;utm_medium=site-ra&amp;utm_campaign=trustvox-home-sessao-b2b" title="Conheça a RA Reviews" id="home_card_trustvox" class="box-border flex flex-col shrink-0 justify-between w-[224px] h-[256px] p-4 rounded transition-shadow bg-white hover:shadow-md">
          <div class="flex flex-col gap-[10px]">
            <div class="flex items-center justify-center py-[6px] bg-[#F1F9E6] rounded"><span class="text-[13px] font-bold text-[#006130]">Reviews para e-commerce</span></div>

            <div class="flex flex-col gap-3">
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Aumente a confiança, visibilidade e lucro do seu e-commerce</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Potencialize sua receita com reviews</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Seus produtos na primeira página da busca orgânica do Google</span>
              </div>
            </div>
          </div>

          <span class="inline-flex gap-1 text-[13px] text-bowl font-semibold">Conheça a RA Reviews

            <img src="./assets/arrowRightBlue.0a7fe311.svg" alt="Seta para direita"></span>
        </a><a href="https://produtos.reclameaqui.com.br/lp-hugme-reclameaqui?utm_source=lp-produtos&amp;utm_medium=site-ra&amp;utm_campaign=hugme-home-sessao-b2b" title="Conheça o RA HugMe" id="home_card_hugme" class="box-border flex flex-col shrink-0 justify-between w-[224px] h-[256px] p-4 rounded transition-shadow bg-white hover:shadow-md">
          <div class="flex flex-col gap-[10px]">
            <div class="flex items-center justify-center py-[6px] bg-[#F1F9E6] rounded"><span class="text-[13px] font-bold text-[#006130]">Gerencie as reclamações</span></div>

            <div class="flex flex-col gap-3">
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Ganhe mais agilidade e economia com uma gestão centralizada</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Gerencie o Reclame AQUI, redes sociais e outros canais</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Gere relatórios personalizados e automatize os fluxos de atendimento</span>
              </div>
            </div>
          </div>

          <span class="inline-flex gap-1 text-[13px] text-bowl font-semibold">Conheça o RA HugMe

            <img src="./assets/arrowRightBlue.0a7fe311.svg" alt="Seta para direita"></span>
        </a><a href="https://produtos.reclameaqui.com.br/lp-api-reclameaqui?utm_source=lp-produtos&amp;utm_medium=site-ra&amp;utm_campaign=api-home-sessao-b2b" title="Conheça a RA API" id="home_card_api" class="box-border flex flex-col shrink-0 justify-between w-[224px] h-[256px] p-4 rounded transition-shadow bg-white hover:shadow-md">
          <div class="flex flex-col gap-[10px]">
            <div class="flex items-center justify-center py-[6px] bg-[#F1F9E6] rounded"><span class="text-[13px] font-bold text-[#006130]">Reclame AQUI no seu CRM</span></div>

            <div class="flex flex-col gap-3">
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Responda o Reclame AQUI com sua ferramenta de CRM</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Otimize seu atendimento</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Integre as reclamações e clientes ao seu sistema</span>
              </div>
            </div>
          </div>

          <span class="inline-flex gap-1 text-[13px] text-bowl font-semibold">Conheça a RA API

            <img src="./assets/arrowRightBlue.0a7fe311.svg" alt="Seta para direita"></span>
        </a><a href="https://produtos.reclameaqui.com.br/lp-ads-reclameaqui?utm_source=lp-produtos&amp;utm_medium=site-ra&amp;utm_campaign=ads-home-sessao-b2b" title="Conheça o RA Ads" id="home_card_ads" class="box-border flex flex-col shrink-0 justify-between w-[224px] h-[256px] p-4 rounded transition-shadow bg-white hover:shadow-md">
          <div class="flex flex-col gap-[10px]">
            <div class="flex items-center justify-center py-[6px] bg-[#F1F9E6] rounded"><span class="text-[13px] font-bold text-[#006130]">Anuncie no Reclame AQUI</span></div>

            <div class="flex flex-col gap-3">
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Apareça para quem está buscando por seu produto ou serviço</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Aumente a visibilidade da sua empresa</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Oportunidade para estabelecer confiança e credibilidade</span>
              </div>
            </div>
          </div>

          <span class="inline-flex gap-1 text-[13px] text-bowl font-semibold">Conheça o RA Ads

            <img src="./assets/arrowRightBlue.0a7fe311.svg" alt="Seta para direita"></span>
        </a><a href="https://cursos.raeduca.com.br/" title="Conheça o RA Educa" id="home_card_educa" class="box-border flex flex-col shrink-0 justify-between w-[224px] h-[256px] p-4 rounded transition-shadow bg-white hover:shadow-md">
          <div class="flex flex-col gap-[10px]">
            <div class="flex items-center justify-center py-[6px] bg-[#F1F9E6] rounded"><span class="text-[13px] font-bold text-[#006130]">Cursos do Reclame AQUI</span></div>

            <div class="flex flex-col gap-3">
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Conhecimento 100% focado em confiança, reputação e atendimento de excelência.</span>
              </div>
              <div class="flex items-baseline gap-2"><img src="./assets/check.0a6ff62a.svg" alt="Icone de checagem" width="10px" height="7px">
                <span class="text-xs text-steel">Aprenda sobre reputação, confiança e Reclame AQUI com o RA Educa!</span>
              </div>
            </div>
          </div>

          <span class="inline-flex gap-1 text-[13px] text-bowl font-semibold">Conheça o RA Educa

            <img src="./assets/arrowRightBlue.0a7fe311.svg" alt="Seta para direita"></span>
        </a></div>

      <p class="text-white mt-2 hide-in-desktop">Sua empresa ainda não está no Reclame
        <em class="not-italic uppercase">Aqui </em>
        ?
        <a title="Benefícios de se cadastrar no Reclame Aqui" href="https://conteudo.reclameaqui.com.br/para-empresas" target="_blank" id="home_card_homeb2b" class="underline">Veja os benefícios de se cadastrar.
        </a>
      </p>
    </div>
  </section>

  <div class="desktop-banner-wrapper my-[24px]">
    <astro-island uid="Z1qKepr" component-export="default" props="{'slotId':[0,'div-gpt-ad-1638277111918-0'],'mode':[0,'desktop'],'minWidth':[0,970]}" client="only" opts="{'name':'PureGoogleAdsSlot','value':'svelte'}"></astro-island>
  </div>






  <div id="footer" class="astro-SZ7XMLTE">
    <div class="hide-in-desktop">
      <div id="menu-bottom" role="menubar" class="animated-menu slide-animation twf-pb-4 show-menu svelte-o7y20l"><a href="https://www.reclameaqui.com.br/" id="home-menu" class="menu-bottom-item active svelte-o7y20l" title="Início" role="menuitem">
          <div class="icon-container svelte-o7y20l"><svg width="22" height="22" viewBox="0 0 15 20" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.18309 17V11.0055H10.8169V17H15.2958V8.99175H18L8.99999 0L0 8.99175H2.70422V17H7.18309Z" fill="#02793e"></path>
            </svg></div>
          Início
        </a> <button id="search-menu" class="menu-bottom-item  svelte-o7y20l" title="Pesquisar" role="menuitem" type="button">
          <div class="icon-container svelte-o7y20l"><svg width="22" height="22" viewBox="0 0 15 20" xmlns="http://www.w3.org/2000/svg">
              <path d="M12.5 11H11.71L11.43 10.73C12.41 9.59 13 8.11 13 6.5C13 2.91 10.09 0 6.5 0C2.91 0 0 2.91 0 6.5C0 10.09 2.91 13 6.5 13C8.11 13 9.59 12.41 10.73 11.43L11 11.71V12.5L16 17.49L17.49 16L12.5 11ZM6.5 11C4.01 11 2 8.99 2 6.5C2 4.01 4.01 2 6.5 2C8.99 2 11 4.01 11 6.5C11 8.99 8.99 11 6.5 11Z" fill="#4b5963"></path>
            </svg></div>
          Pesquisar
        </button> <a href="https://www.reclameaqui.com.br/reclamar/" id="complain-menu" class="menu-bottom-item  svelte-o7y20l" title="Reclamar" role="menuitem">
          <div class="icon-container svelte-o7y20l"><svg width="22" height="22" xmlns="http://www.w3.org/2000/svg">
              <path d="M10.4784 4.02755H2.66827C2.12019 4.02755 1.66346 4.21488 1.29808 4.58953C0.932692 4.96419 0.75 5.43251 0.75 5.99449V10.022C0.75 10.584 0.932692 11.0523 1.29808 11.427C1.66346 11.8017 2.12019 11.989 2.66827 11.989H3.67308V16.0165C3.67308 16.2975 3.76442 16.5317 3.94712 16.719C4.12981 16.9063 4.35817 17 4.63221 17H6.59615C6.87019 17 7.09856 16.9063 7.28125 16.719C7.46394 16.5317 7.55529 16.2975 7.55529 16.0165V11.989H10.4784L15.3654 16.0165V0L10.4784 4.02755ZM19.75 8.00826C19.7196 8.88246 19.4912 9.6786 19.0649 10.3967C18.6386 11.0836 18.0449 11.6143 17.2837 11.989V4.02755C18.0449 4.4022 18.6386 4.94858 19.0649 5.66667C19.4912 6.35354 19.7196 7.13407 19.75 8.00826Z" fill="#4b5963"></path>
            </svg></div>

          Reclamar
        </a> <a href="https://www.reclameaqui.com.br/descontos/" id="discount-menu" class="menu-bottom-item  svelte-o7y20l" title="Descontos" role="menuitem">
          <div class="icon-container svelte-o7y20l"><svg width="22" height="22" xmlns="http://www.w3.org/2000/svg">
              <path d="M1.97183 0C1.40845 0.0311891 0.938966 0.233917 0.563379 0.608186C0.187792 0.982456 0 1.45029 0 2.0117V5.98831C0.563379 6.01949 1.03286 6.22223 1.40845 6.5965C1.78404 6.97077 1.97183 7.4386 1.97183 8C1.97183 8.56141 1.78404 9.02923 1.40845 9.4035C1.03286 9.77777 0.563379 9.98052 0 10.0117V13.9883C0 14.5497 0.187792 15.0175 0.563379 15.3918C0.938966 15.7661 1.40845 15.9688 1.97183 16H18.0282C18.5915 15.9688 19.061 15.7661 19.4366 15.3918C19.8122 15.0175 20 14.5497 20 13.9883V10.0117C19.4366 9.98052 18.9671 9.77777 18.5915 9.4035C18.216 9.02923 18.0282 8.56141 18.0282 8C18.0282 7.4386 18.216 6.97077 18.5915 6.5965C18.9671 6.22223 19.4366 6.01949 20 5.98831V2.0117C20 1.45029 19.8122 0.982456 19.4366 0.608186C19.061 0.233917 18.5915 0.0311891 18.0282 0H1.97183ZM13.5211 2.99416L15.0235 4.49123L6.47888 13.0058L4.97653 11.5088L13.5211 2.99416ZM6.80751 3.04093C7.30829 3.07213 7.71519 3.25926 8.02816 3.60235C8.37245 3.91422 8.5446 4.31969 8.5446 4.81871C8.5446 5.31774 8.37245 5.7388 8.02816 6.08187C7.71519 6.39376 7.30829 6.54971 6.80751 6.54971C6.30673 6.54971 5.88419 6.39376 5.53991 6.08187C5.22692 5.7388 5.07042 5.31774 5.07042 4.81871C5.07042 4.31969 5.22692 3.91422 5.53991 3.60235C5.88419 3.25926 6.30673 3.07213 6.80751 3.04093ZM13.1925 9.4035C13.6933 9.4347 14.1002 9.62184 14.4131 9.96493C14.7574 10.2768 14.9296 10.6823 14.9296 11.1813C14.9296 11.6803 14.7574 12.1014 14.4131 12.4444C14.1002 12.7563 13.6933 12.9123 13.1925 12.9123C12.6917 12.9123 12.2692 12.7563 11.9249 12.4444C11.6119 12.1014 11.4554 11.6803 11.4554 11.1813C11.4554 10.6823 11.6119 10.2768 11.9249 9.96493C12.2692 9.62184 12.6917 9.4347 13.1925 9.4035Z" fill="#4b5963"></path>
            </svg></div>
          Descontos
        </a> <a id="login-menu" href="https://www.reclameaqui.com.br/login" type="button" class="menu-bottom-item  svelte-o7y20l" title="Login" role="menuitem">
          <div class="icon-container svelte-o7y20l"><svg width="22" height="22" viewBox="0 0 15 23" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 0.984375C10.125 1.01563 11.0625 1.40625 11.8125 2.15625C12.5625 2.90625 12.9375 3.85937 12.9375 5.01562C12.9375 6.14062 12.5625 7.07812 11.8125 7.82812C11.0625 8.57812 10.125 8.95312 9 8.95312C7.875 8.95312 6.9375 8.57812 6.1875 7.82812C5.4375 7.07812 5.0625 6.14062 5.0625 5.01562C5.0625 3.85937 5.4375 2.90625 6.1875 2.15625C6.9375 1.40625 7.875 1.01563 9 0.984375ZM9 11.0156C11.2812 11.0469 13.1719 11.4375 14.6719 12.1875C16.1719 12.9375 16.9531 13.875 17.0156 15V17.0156H0.984375V15C1.04688 13.875 1.82812 12.9375 3.32812 12.1875C4.82812 11.4375 6.71875 11.0469 9 11.0156Z" fill="#4b5963"></path>
            </svg></div>
          Entrar
        </a></div>
    </div>
    <footer id="footer-ra" class="tw-footer expanded svelte-1mz1hj3">
      <section id="footer-extended" class="twf-py-[40px] xs:twf-px-4 lg:twf-px-0 twf-hidden md:twf-block">
        <div class="lg:twf-max-w-[1184px] twf-mx-auto twf-w-full twf-flex twf-flex-col md:twf-flex-row twf-justify-center twf-content-between twf-gap-12">
          <div class="footer-group twf-flex twf-flex-row twf-w-full twf-justify-center twf-gap-12">
            <div class="footer-col twf-flex twf-flex-col twf-w-full md:twf-max-w-[50%] svelte-1mz1hj3">
              <h2 class="column-title svelte-1mz1hj3">Para consumidor</h2>
              <div class="lg:twf-w-[320px] xs:twf-hidden md:twf-block"><a href="https://www.reclameaqui.com.br/minha-conta/" class="stylized-link svelte-1mz1hj3" target="_top">Área do consumidor</a></div> <a href="https://www.reclameaqui.com.br/area-da-empresa/" class="footer-link xs:twf-block md:twf-hidden svelte-1mz1hj3">Área do consumidor</a> <a href="https://www.reclameaqui.com.br/reclamar/" class="footer-link twf-mt-2 svelte-1mz1hj3">Faça uma reclamação</a> <a href="https://www.reclameaqui.com.br/minha-conta/minhas-reclamacoes/" class="footer-link twf-mt-2 svelte-1mz1hj3">Minhas Reclamações</a> <a href="https://www.reclameaqui.com.br/compare/" class="footer-link twf-mt-2 svelte-1mz1hj3">Compare empresas</a> <a href="https://www.reclameaqui.com.br/segmentos/" class="footer-link twf-mt-2 svelte-1mz1hj3">Melhores empresas</a> <a href="https://www.reclameaqui.com.br/descontos/" class="footer-link twf-mt-2 svelte-1mz1hj3">Buscar descontos</a> <a href="https://www.reclameaqui.com.br/ranking/" class="footer-link twf-mt-2 svelte-1mz1hj3">Rankings</a> <a href="https://www.reclameaqui.com.br/cadastro-empresa/consumidor/" class="footer-link twf-mt-2 svelte-1mz1hj3">Cadastre uma empresa</a>
              <div class="twf-mt-6 twf-flex twf-flex-col twf-gap-6"><a href="https://play.google.com/store/apps/details?id=br.com.reclameaqui.app&amp;utm_source=sitera&amp;utm_campaign=buttonsite" target="_blank" rel="noreferrer"><img width="135px" height="40px" src="data:image/webp;base64,UklGRnAGAABXRUJQVlA4WAoAAAAQAAAAhgAAJwAAQUxQSF8AAAABcFtr25O8MAYD5DgAhxVoOfQcpklq6RBWbqAD5DrnnLP/BP/XGhETAETNzZ7v67ovApU74/87QchI+DEaNGDVDxEO7A/9MxE2NSKk3pcEKwnxnQDTABDccn/A91YqAwBWUDgg6gUAALAdAJ0BKocAKAA+kUKaSaWkIiEoVJswsBIJQBpgNASwBz33sjeSBeEX4PoXfQXttyqGUP5/5gPg7/IeKPv1/lfI9/c98rAB+Lf0D/cd8f+5ejf1j/0Hoff7P1O732gB/Mf7x/qv7B+VX0s/yH/X/yHnQ/Ov8d/2/cK/mP9W/5HYQ9Hf9wDF8zEMIvzub/2Z0r5HGppRAA/Za1F1JRInvnAZv3OUB+8Oax25PlyZWY+Kt5f8WVpfl2WOv4GV756uVK6SLtn6kAv+sw7sDqvvLZWyCzT6s6XxLiC19aijTN/ApKjPoBkQ8jfQ8mXBTBSaDapPTXZMAAD+8z5yP+xNSLuJd39ywoMiOAEnwSAE3CnQXeP2heg8TVunELQBbHeQNJn/5XPSGg8fV1r61jBgHbMCDm8JS4u0cJx4tGAquFydJ2fVXD+8vBWs4qJoSzkEQgMfa3aW8f1pNIVBlF7BpIdq6bbDRJlZgiXgC2S/u80+f8/0y8/X07yMC7felMA0uAufb/YEY0G8QJxzsUV1Vhjqj2jzzYQGQfUP+1OPTd16I4vKkNNYDE0yfrKeitFH7gkDtsB3EJ1QP845FTfSKZ1tIR2+ITQxR3lSSw95+mfK0YCcUL70I581QYTh51OcQ9mOpxBbx1c0MFeTf1jSYAJYFhJILcfIEZJUImueYF+YPVhOw33vTlZ+GbTuAnyha0VBwfaLhwUtg6W4daIG4+z0UMc2JZbw9Y/BQhZeBMxqATv0nCXlCPOIT/Gv4CynGgX9DMtjOmyHunBFx6ZLnTInub/6EUFD5nwiF+HX8eD/1diY++3X2OCUkZzbGrKDJ7rm0Rh1lUVALahUy2Z0rWCtm6NYWNHcZ2XQmBtuU3AcXToupowxDDkuWKBTpnpzkweHow0r+o9tQh5VecV3Ifn/ubXnwhBlJ6OPvrMnJwZ2RFsM4cVijr+g8fmCTFo5k8cm3mJn/xzgPoix2tVqEk6QBziqbufiZ16Iu0e0p2UjCtYF55l1wz0Y20kk+p/gr/lzw0yO/FKiRiQe24XxxeOvMwDZlYRthmxFRQL8oB356vNL03PcZv9DKMBdyN8j/6GSN2Qn8ANnI/jN/kJ7FsZmtcd6nbhxDQZLcMMHuA6fIzQhabvxvApXT/NEEaKe/22bJSo0qHmoS/VW2WVTUVVijsfL7rwmr4J2Z/bEPyLunY9ZGIR5Hqfzxs93JMA0U0t7NY+bLaI1W/EGZ5trAmLOIGtZFX1mnJtrHVSx0iNzN8tlnrxJhWv9iJFtoVcmHH8x4KfnOOhKTTOy7RFe/622dwE32TSpWD2edUcBkQ6cyPXiRd79D7EUNT9vTl3+5sV64a2NxNF/ntoXUDGlW3e3cavS/ZIhFFHMrZY3pykegtq+YMQHvkQ4B1eAdxn9uqI4n+brKmi7ZmN/5fDsVN8DC8/by9MIBAsUGFYEai6hcz176tnRTI+1AahF2XhxwOLt1pj0bilBMEZI0LE/ti8veLbgROOcqsCdxanM3vsSCCOyLmpzU+Wr+PUL1WZseC4QYurAqhxKK6crNZen9NLTW+Df9jP0HMEUL81JTE8yRQj4Rdcykhe9BAcXFfbXTEbeWZqH5q9UxWG/itdLPmosAIUEeXk3jZzUb9llEuAc1AR+MVqgEOvbXSeaNSAlZbjpKpijuORO62rolXsIalNqZZ0qJGwOD511VE86tSkqt/VfTl+dLbN0V3/HPuqdsUQlbLABEZYphhrQ4Kq4nNgjY9LL1EY5KLDWmnMhiBllxJ3+54yypJ6d4q5rIZNKbNA0xNuiwSwed1Djg/w+NUIKq/7Fr9+gDoe/AvTVo34LlMqwzfSCd73qt1iNrN/3XfaOaXyptq0AMnXaIqC1Zj/Cub2CyJKqg8LPvVBbFnq3EkT6b/FgRLkPHDnYV9aRNxQn+qZ1y+C4X+4O9Srr6I0SC4Hbglf0MulYS9KLIM7+xP75AnvYO77ViBrT0pFDTtpsr3Ski2vnoPComyq/rLlqy9cN8gL/gAAA" alt="Botão escrito Disponível no Google Play"></a> <a href="https://apps.apple.com/br/app/reclame-aqui/id6444538707?ct=buttonsite" target="_blank" rel="noreferrer"><img width="135px" height="40px" src="data:image/webp;base64,UklGRjQFAABXRUJQVlA4WAoAAAAQAAAAhgAAJwAAQUxQSGAAAAABcBTZdhUdCUhAQiQgIRIiBSfgABwEB+Dg4eBK4Dfb3O1ExAQA5Cl0tVr7UviZ4mp9JCBfDg70YYG6cnk4VhOqTND1p61MUDVhG00onSyInsGCDKRoXiR+lvVQs3TOGQBWUDggrgQAAJAbAJ0BKocAKAA+kUidS6WkIqKjmqkAsBIJaQAV4B14/3j8e/EB8f/ZPyq/m2eY+wH53yA/uXU7eTP/CbwTWz+6eSn9D/zPgmagXbb0K/zz/eeSB4ItAD8m/9f+0fkB9KX8P/2P8b52fnf/re4J/Kf6d/u/t2+aT1zfuB7Gv7ZJnMSkMV2p0OJs0gM8wzP6vR7aXUJprPYfBONRPjvEpYGi8uaJ6BHWCLtgY+s1fwXbbP2wZfVQIFwqGmzBjY3upPo9FuYVdyyLOdtxvx57J6nPaeYF7qoa760krX8ayBJ6QCSNKAAA/rQn17bmfeFV5E1yvhpqbvyzPcAIJy3m3NzItaje6lSD7hunxu7m/f4wfaD8IkFyeqvMlf6va3l9/fmaSq5Yw4Vs/yqMI78Wg+pHZqOa0nvyEvSOwz2FgJ0oKdKf8Y1128/YA0pSWoZp6VKXcNTamMk8/fBWMRU8HfmsbRd6PhXg8dN+39d7POv46ShZ/6+n8Kkbn42Qf9FpE48I5dJJhv4VhQQcHuObV+MdFXXd1Pg7tgVLT0MtZ+6nZofhUvICKGYY7+BG+lMPSESNXgPCgqnTQ+RFAaP+Y2eKBrwXQ5BdXz3viokOqYr5bpPeErM3lJuNsdWVZovcGEmnWHqQu4+j5aJiyNoe9QRSpIB06avdDtQQSkY9SDX5m4C4Ws9xoizpoDNlXhTVzh9N9D90BSMffFjaCwYbeCdzc3tD+lXxBeeeYJZrR1WO4N9I42frjweUJHt0wY4ZDdWQxEP8PT7h27x91uj+h0kKtIe+muoV19Ii6N9d8jqLGKLSQ2N952hwVZgTo+qGdvvxpQV0kfMg+MZfJ4z7IuF6IVJ6taGquOwmjIu8Z2H2SNTv8VQoN9KZm0oz2+X3SajW6wZ6e07y4DT87uxvamuq+Jb/M2wnwPoHfqk6JFrugJdSALeoGRxE70yyWEjf8/QlTP3aCsSyNbZ5/2cAliD4CIRdLPaEZuYrNUhb8dDSs+3LdNyK+IrLwVf2Y9Kmvyu9Xo2HqMMis5465J3rWM6UyBSYlNul/Jj0ay5FdmiLSM66l3nIzgpqC5k1dDPSvBJH3EFp+CagmcpW4lXaUBxIuy+THf15e75wbvz9r1hn85DRtm0jt9LyjK66VpJk6uKeCK/iaqMkXZQW/RqqSnzsr4WOj66NmM0RbnQ4SzV+fw9e/AkrRgNJMtJ1ag5Iell7osppI5UsL1LTizf53Xt3J5hYc6jWc7x+JMVa/z2tCbY5R6wLbPTQgBsLqH+o9qvZFkglOGD31K49JYzgbU57WfeNn/e0pQyABBABSNPvn3+JUorCpBMv/KTN4plCyzZf7kCPZf8IPnhjzvQMw3iSgeVAe2jk+QX5UVXePuKWCRu9Keof23fiChVDHYyzfsO2rQjhpwG9dK7O5Q/z5/7NImaOOGMbW7leIhWlffuX/9G0o1ntVmASMcQjDale4UBEGwD9YQuYhOCzOLTPKtrl1UMQBWMzDKXr4D0LKRbafg/c/IOCAzF8HGE1+68S1+RDdadpMp+f7sCQJvs5YXR/nDoAERkWan2JfGvhJnToXgFzoyuGdDfQwAAAAAA=" alt="Botão escrito Baixar na App Store"></a></div>
            </div>
            <div class="footer-col twf-flex twf-flex-col twf-w-full md:twf-max-w-[50%] svelte-1mz1hj3">
              <h2 class="column-title svelte-1mz1hj3">Para empresas</h2>
              <div class="lg:twf-w-[320px] xs:twf-hidden md:twf-block"><a href="https://www.reclameaqui.com.br/area-da-empresa/" class="stylized-link svelte-1mz1hj3" target="_top">Área da empresa</a></div> <a href="https://conteudo.reclameaqui.com.br/para-empresas" class="footer-link twf-mt-2 svelte-1mz1hj3">Por que estar <em class="twf-not-italic twf-uppercase">aqui</em>?</a> <a href="https://www.reclameaqui.com.br/cadastro-de-empresa/" class="footer-link twf-mt-2 svelte-1mz1hj3">Cadastrar empresa</a> <a href="https://www.reclameaqui.com.br/area-da-empresa/reclamacoes/nao-respondidas/" class="footer-link twf-mt-2 svelte-1mz1hj3">Responder reclamações</a> <a href="https://www.reclameaqui.com.br/area-da-empresa/produtos/" class="footer-link twf-mt-2 svelte-1mz1hj3">Meus Produtos Reclame AQUI</a>
              <p class="twf-mt-2 svelte-1mz1hj3">Entre em sua área restrita para administrar suas respostas aos
                consumidores,
                <a href="https://www.reclameaqui.com.br/area-da-empresa/" class="!twf-text-bowl svelte-1mz1hj3">acesse aqui</a>
              </p>
            </div>
          </div>
          <div class="footer-group twf-flex twf-flex-row twf-w-full twf-justify-center twf-gap-12">
            <div class="footer-col twf-flex twf-flex-col twf-w-full md:twf-max-w-[50%] svelte-1mz1hj3"><span class="column-title svelte-1mz1hj3">Sobre o RA</span> <a href="https://www.reclameaqui.com.br/institucional/" class="footer-link twf-mt-2 svelte-1mz1hj3">Institucional</a> <a href="https://www.reclameaqui.com.br/fale-conosco/" class="footer-link twf-mt-2 svelte-1mz1hj3">Fale conosco</a> <a href="https://ra.engaged.com.br/todos" class="footer-link twf-mt-2 svelte-1mz1hj3">RA Educa</a> <a href="https://www.reclameaqui.com.br/extensao/" class="footer-link twf-mt-2 svelte-1mz1hj3">Conheça a extensão</a> <a href="https://www.reclameaqui.com.br/premio/" class="footer-link twf-mt-2 svelte-1mz1hj3">Prêmio</a> <a href="https://blog.reclameaqui.com.br/" class="footer-link twf-mt-2 svelte-1mz1hj3">Blog RA</a></div>
            <div class="footer-col twf-flex twf-flex-col twf-w-full md:twf-max-w-[50%] svelte-1mz1hj3">
              <h2 class="column-title svelte-1mz1hj3">Central de ajuda</h2>
              <div class="2xl:twf-w-[320px] xs:twf-hidden md:twf-block twf-w-max"><a href="https://www.reclameaqui.com.br/reclamar/" class="stylized-link red svelte-1mz1hj3" target="_top">Reclamar de uma empresa</a></div> <a href="https://www.reclameaqui.com.br/esqueci-minha-senha/" class="footer-link twf-mt-2 svelte-1mz1hj3">Quero trocar minha senha</a> <a href="https://www.reclameaqui.com.br/como-funciona/#nao-encontrei-empresa" class="footer-link twf-mt-2 svelte-1mz1hj3">Não encontrei uma empresa</a> <a href="https://www.reclameaqui.com.br/como-funciona/#quando-devo-fazer-replica" class="footer-link twf-mt-2 svelte-1mz1hj3">Reclamei e ainda não responderam</a> <a href="https://www.reclameaqui.com.br/cadastro-empresa/consumidor/" class="footer-link twf-mt-2 svelte-1mz1hj3">Quero cadastrar uma empresa</a> <a href="https://www.reclameaqui.com.br/fale-conosco/" class="footer-link twf-mt-2 svelte-1mz1hj3">Fale com o Reclame AQUI</a>
            </div>
          </div>
        </div>
      </section>
      <section id="extended-footer-mobile" class="twf-flex md:twf-hidden twf-flex-col twf-pl-4 twf-text-base twf-text-bowl"><a href="https://www.reclameaqui.com.br/reclamar/" class="twf-my-2">Faça uma reclamação</a> <a href="https://www.reclameaqui.com.br/minha-conta/minhas-reclamacoes/" class="twf-my-2">Minhas reclamações</a> <a href="https://www.reclameaqui.com.br/cadastro/consumidor/" class="twf-my-2">Crie sua conta</a> <a href="https://www.reclameaqui.com.br/segmentos/" class="twf-my-2">Melhores empresas</a> <a href="https://www.reclameaqui.com.br/descontos/" class="twf-my-2">Buscar descontos</a> <a href="https://www.reclameaqui.com.br/ranking/" class="twf-my-2">Ranking</a> <a href="https://www.reclameaqui.com.br/cadastro-empresa/consumidor/" class="twf-my-2">Cadastre uma empresa</a> <a href="https://conteudo.reclameaqui.com.br/para-empresas" class="twf-my-2">Por que estar <em class="twf-not-italic twf-uppercase">aqui</em>?</a> <a href="https://www.reclameaqui.com.br/fale-conosco/" class="twf-my-2">Tire suas dúvidas sobre o Reclame <em class="twf-not-italic twf-uppercase">aqui</em></a></section>
      <section id="footer-links" class="py-8 svelte-17hqwxp">
        <div class="lg:twf-max-w-[1184px] twf-mx-auto twf-w-full twf-flex twf-flex-col md:twf-flex-row twf-justify-center twf-content-between twf-gap-4 md:twf-gap-12"><span class="md:twf-hidden twf-flex twf-justify-center grey twf-text-sm">Siga a gente nas redes sociais</span>
          <div class="twf-w-full twf-flex twf-justify-center">
            <ul class="twf-mx-auto twf-flex twf-flex-row social-links twf-pl-0 twf-list-none">
              <li class="link svelte-17hqwxp"><a href="https://www.facebook.com/ReclameAqui" target="_blank" rel="noopener noreferrer" title="Facebook - Acesse o perfil Reclame Aqui!"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" class="svelte-c8tyih">
                    <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path>
                  </svg></a></li>
              <li class="link twf-ml-4 svelte-17hqwxp"><a href="https://twitter.com/reclameaqui" target="_blank" rel="noopener noreferrer" title="O Twitter agora é X - Acesse o perfil Reclame Aqui!"><img src="./assets/Imagem_O_Twitter_agora_e_X_Acesse_o_perfil_Reclame_Aqui.svg" style="margin-bottom: 7px;" alt="O Twitter agora é X - Acesse o perfil Reclame Aqui!"></a></li>
              <li class="link twf-ml-4 svelte-17hqwxp"><a href="https://www.youtube.com/channel/UCHSTgEYmopZluZ7N4BSGPpw" target="_blank" rel="noopener noreferrer" title="Youtube - Acesse o canal Reclame Aqui!"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="svelte-c8tyih">
                    <path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path>
                  </svg></a></li>
              <li class="link twf-ml-4 svelte-17hqwxp"><a href="https://www.instagram.com/reclameaqui/" target="_blank" rel="noopener noreferrer" title="Instagram - Acesse o perfil Reclame Aqui!"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="svelte-c8tyih">
                    <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path>
                  </svg></a></li>
              <li class="link twf-ml-4 svelte-17hqwxp"><a href="https://www.linkedin.com/company/reclame-aqui/" target="_blank" rel="noopener noreferrer" title="Linkedin - Acesse o perfil Reclame Aqui!"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="svelte-c8tyih">
                    <path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"></path>
                  </svg></a></li>
            </ul>
          </div>
          <div class="twf-w-full twf-flex ra-logo gray"><a class="twf-mx-auto twf-flex twf-items-center" target="_self" href="https://www.reclameaqui.com.br/" title="Reclame Aqui - Início">
              <div class="ra-logo twf-mx-auto grey svelte-91nnlw"><svg viewBox="0 0 257 41" xmlns="http://www.w3.org/2000/svg" class="svelte-91nnlw">
                  <g fill="none">
                    <path d="M14.463 9.812l-1.45 7.791c1.313-.028 2.326-.353 3.04-.974.714-.62 1.195-1.594 1.443-2.921.241-1.3.138-2.274-.308-2.922-.445-.652-1.228-.974-2.347-.974h-.378zM0 35.717l6.083-32.69h11.084c3.75 0 6.534.903 8.357 2.709 1.822 1.806 2.444 4.262 1.866 7.367-.355 1.91-1.142 3.54-2.363 4.893-1.22 1.349-2.874 2.428-4.961 3.233l4.133 14.488h-10.21l-1.992-12.652L9.64 35.717H0zm35.448-14.353h5.175c.241-1.298.206-2.272-.106-2.92-.313-.652-.902-.976-1.768-.976-.678 0-1.285.318-1.82.952-.535.634-1.03 1.615-1.48 2.944M46.77 27.7c-.847 2.687-2.34 4.803-4.479 6.348-2.138 1.545-4.656 2.317-7.555 2.317-3.403 0-5.832-1.04-7.29-3.123-1.454-2.085-1.824-5.049-1.107-8.902.72-3.864 2.208-6.863 4.464-8.998 2.256-2.135 5.054-3.202 8.394-3.202 3.64 0 6.18.948 7.624 2.843 1.442 1.895 1.808 4.754 1.097 8.576-.083.445-.15.788-.201 1.018-.051.233-.11.443-.178.637H34.731l-.058.314c-.314 1.688-.338 2.897-.072 3.627.265.732.855 1.097 1.768 1.097.678 0 1.264-.209 1.76-.625.495-.42.918-1.062 1.268-1.927h7.373m15.116 7.658a9.337 9.337 0 01-2.185.76c-.764.165-1.61.247-2.54.247-3.119 0-5.375-1.077-6.77-3.235-1.395-2.156-1.742-5.115-1.043-8.877.687-3.688 2.16-6.629 4.42-8.822 2.26-2.193 4.924-3.29 7.997-3.29.85 0 1.629.074 2.333.221.705.151 1.35.383 1.938.694l-1.308 7.031a2.887 2.887 0 00-.85-.392 3.832 3.832 0 00-.992-.123c-.914 0-1.72.42-2.42 1.254-.698.836-1.182 1.98-1.451 3.427-.273 1.462-.227 2.562.141 3.303.366.738 1.047 1.107 2.038 1.107.283 0 .595-.042.933-.123.338-.084.702-.2 1.092-.347l-1.333 7.165m2.698.359L71.222.049h8.767l-6.637 35.668h-8.768m23-11.464c-.303 1.629-.353 2.851-.151 3.67.201.823.656 1.232 1.366 1.232.71 0 1.327-.42 1.854-1.266.527-.84.938-2.055 1.233-3.636.3-1.612.342-2.842.129-3.686-.212-.84-.674-1.265-1.382-1.265-.694 0-1.3.42-1.817 1.258-.519.834-.928 2.064-1.232 3.693m2.357 11.464l.47-2.531c-1.072 1.103-2.115 1.91-3.131 2.419a6.993 6.993 0 01-3.155.76c-2.41 0-4.1-1.063-5.065-3.19-.968-2.126-1.095-5.1-.384-8.922.717-3.85 1.945-6.834 3.684-8.946 1.74-2.11 3.832-3.167 6.273-3.167 1.104 0 2.065.25 2.886.75.82.499 1.563 1.294 2.227 2.384l.462-2.486h8.767l-4.266 22.929H89.94m11.982 0l4.267-22.929h8.413l-.635 3.404c1.064-1.314 2.21-2.285 3.437-2.912 1.228-.627 2.582-.938 4.063-.938 1.386 0 2.473.315 3.261.952.788.634 1.266 1.601 1.434 2.898.922-1.314 1.969-2.285 3.141-2.912 1.172-.627 2.507-.938 4.004-.938 1.843 0 3.152.522 3.927 1.565.773 1.048.975 2.568.602 4.569l-3.209 17.24h-8.766l2.483-13.345c.133-.714.099-1.245-.106-1.587-.204-.345-.582-.518-1.133-.518-.505 0-.936.2-1.293.595-.356.396-.6.945-.73 1.645l-2.459 13.21h-8.72l2.484-13.345c.133-.714.098-1.245-.107-1.587-.203-.345-.581-.518-1.132-.518-.52 0-.963.2-1.328.595-.365.396-.612.945-.743 1.645l-2.458 13.21h-8.697m46.176-14.352h5.175c.242-1.298.207-2.272-.105-2.92-.312-.652-.903-.976-1.768-.976-.678 0-1.285.318-1.82.952-.536.634-1.03 1.615-1.482 2.944M159.42 27.7c-.847 2.687-2.34 4.803-4.478 6.348s-4.657 2.317-7.556 2.317c-3.403 0-5.833-1.04-7.288-3.123-1.456-2.085-1.826-5.049-1.108-8.902.72-3.864 2.206-6.863 4.463-8.998 2.256-2.135 5.054-3.202 8.394-3.202 3.64 0 6.18.948 7.624 2.843 1.443 1.895 1.81 4.754 1.098 8.576-.084.445-.151.788-.201 1.018a5.42 5.42 0 01-.179.637h-12.808l-.058.314c-.314 1.688-.338 2.897-.072 3.627.265.732.855 1.097 1.77 1.097.677 0 1.263-.209 1.757-.625.496-.42.919-1.062 1.269-1.927h7.373" fill="#90B823" class="svelte-91nnlw"></path>
                    <path d="M171.845 24.298h3.828l.317-12.114-4.145 12.114zm-13.207 11.419l13.645-32.69h10.847l1.454 32.69h-9.381l.163-4.815h-5.695l-1.629 4.815h-9.404zm39.164-16.547c-.632 3.39-.827 5.71-.587 6.964.239 1.254.95 1.881 2.13 1.881 1.166 0 2.096-.617 2.79-1.848.693-1.231 1.36-3.564 1.999-6.998.64-3.433.84-5.766.608-7.006-.236-1.24-.936-1.86-2.101-1.86-1.181 0-2.125.628-2.83 1.88-.707 1.255-1.377 3.585-2.01 6.986M201.75 41l-2.839-4.679c-.11 0-.28.007-.512.021a9.863 9.863 0 01-.512.023c-4.144 0-7.075-1.476-8.794-4.433-1.717-2.954-2.074-7.137-1.07-12.538 1.008-5.402 2.916-9.59 5.73-12.56 2.814-2.97 6.268-4.456 10.365-4.456 4.08 0 6.966 1.48 8.66 4.444 1.694 2.962 2.037 7.154 1.028 12.572-.58 3.121-1.462 5.83-2.647 8.127-1.183 2.298-2.695 4.239-4.534 5.823l3.48 4.163L201.748 41m13.818-16.972l3.908-21.002h9.618l-4.07 21.876c-.18.955-.13 1.66.149 2.115.277.455.795.683 1.551.683.77 0 1.38-.228 1.828-.683.447-.454.76-1.16.937-2.115l4.072-21.876h9.665l-3.908 21.002c-.795 4.27-2.333 7.392-4.615 9.372-2.283 1.977-5.48 2.965-9.592 2.965-4.096 0-6.909-.988-8.44-2.965-1.53-1.98-1.898-5.101-1.103-9.372m25.544 11.689l6.083-32.69h9.642l-6.082 32.69h-9.643" fill="#007535" class="svelte-91nnlw"></path>
                  </g>
                </svg></div>
            </a></div>
          <div class="twf-w-full twf-flex twf-flex-row twf-justify-center twf-items-center twf-content-evenly"><a href="https://www.reclameaqui.com.br/termos-de-uso/" class="footer-link gray twf-mt-2 lg:twf-mr-4 twf-text-sm svelte-17hqwxp" title="Termos de uso">Termos de uso</a> <a href="https://www.reclameaqui.com.br/politica-de-privacidade/" class="footer-link gray twf-mt-2 twf-ml-4 twf-text-sm svelte-17hqwxp" title="Politica de privacidade">Política de privacidade</a></div>
        </div>
      </section>
    </footer>
  </div>








  <div style="display: none; visibility: hidden;">


  </div>
  <meta name="adopt-website-id" content="09bf4d91-aab2-45ed-9cae-494acf39ec1d">
  <style>
    body>dl-template>div>div>div.dl-content>div.dl-footer.dl-footer-link {
      display: none !important;
    }

    @media (min-width: 768px) and (orientation: landscape) {
      .cc-window {
        left: 0 !important;
        right: 0 !important;
        margin: 0 auto !important;
        width: 55% !important;
        padding: 24px !important;
      }

      .cc-window.cc-floating.cc-type-opt-in {
        width: 55% !important;
        padding: 24px !important;
      }

      .cc-message-container {
        padding: 0px !important;

      }

      .cc-message {
        padding: 0px !important;
        padding-left: 0px !important;
        padding-right: 0px !important;
      }
    }

    @media only screen and (max-width: 800px) {
      .cc-type-opt-in {
        margin: 0px !important;
      }
    }
  </style>
  <style>
    .go1690009051 {
      color: #000;
    }

    .fuJtcf {
      background-color: white;
    }

    .iaWhiq img {
      background-color: white;
    }

    .iRgTQW img {
      background-color: white;
    }

    .jibPFy {
      gap: 1.5em;
    }



    @media only screen and (max-width: 800px) {
      #header-search-overlay-wrapper {
        top: 62px;
      }

      .cc-type-opt-in {
        margin: 0px 10px 85px 10px;
        padding: 0px 10px;
        border: 1px solid #cecece;
      }

      .cc-message {
        margin-bottom: 0px !Important;
      }

      #cookieconsent\:desc>p:nth-child(2) {
        margin-bottom: 5px !important;
      }
    }

    @media screen and (min-width: 768px) {
      #header-search-overlay-wrapper {
        top: 74px;
      }
    }

    html {
      overflow-x: hidden;
    }
  </style>

  <div style="display: none; visibility: hidden;">
    <style type="text/css">
      body>astro-island:nth-child(10)>div.hidden.lg\:flex.w-full.justify-center.items-center.gap-4.mt-6 {
        margin-bottom: 30px
      }

      body>astro-island:nth-child(11)>div>div>div>a {
        display: none;
      }

      body>astro-island:nth-child(11)>div>div>div>div>div>div.max-md\:flex.max-md\:justify-between.items-center.w-full>button {
        display: none;
      }

      body>div:nth-child(4)>div.min-h-\[640px\].mt-16 {
        min-height: 520px;
      }

      #para-empresas>div>div.overflow-x-auto.md\:overflow-x-visible.py-6.pl-4>div>a {
        min-width: 15rem !important;
      }

      .bWghGe {
        display: none;
      }

      @media (max-width: 768px) {
        .bViOUm {
          max-width: 320px !important;
        }

        #detector-de-site {
          padding-bottom: 40px;
        }

        .dflmTb {
          gap: 5px;
        }
      }

      @media (min-width: 1000px) {
        a[data-testid="ConsumerShortcut"] {
          justify-content: space-between !important;

        }
      }




      .go175175137 {
        display: none;
      }

      .hsSOiZ>p {
        color: #F9F9F9 !important;
      }

      .go2666909109 {
        background: #3B444A
      }

      .iYaQhv {
        color: #fff;
      }

      .ekEbtK>button>svg {
        fill: #fff;
      }

      .go3229910025 {
        color: #fff;
      }

      .ddZCac {
        justify-content: start;

      }

      .company-subtitle {
        color: #FFF !important;
      }

      .bg-right {
        display: none;
      }

      .bg-left {
        display: none;
      }

      #vote-counter-cta {
        display: none;
      }

      .go2727329185 {
        display: none;
      }

      .go1988925827 {
        display: none;
      }

      .go3837330668 {
        color: #fff;
      }

      body>div:nth-child(4)>section.flex-row.justify-center.gap-10.items-center.flex.relative.min-h-\[532px\].svelte-1w7yavo>div:nth-child(2)>div.flex-row.gap-16.justify-between.hidden.md\:flex>div:nth-child(1) {
        margin-right: 100px;
      }
    </style>
  </div>

  <style>
    .go956827647 {
      width: 100%;
    }

    .go2246546985 {
      display: none;
    }

    #award-updataded-title {
      display: none;
    }

    #award-refresh-btn {
      margin: 0px auto;
    }
  </style>
  <div style="display: none; visibility: hidden;">
    <style type="text/css">
      .go4286873888 {
        display: none;
      }

      .go3911659100 {
        margin-top: 0px !important;
        padding-top: 0px !important;
      }

      .black-friday-home-counter {
        display: none;
      }

      .ra-banner-black-friday {
        display: none;
      }
    </style>
  </div>
  <div style="display: none; visibility: hidden;">
    <style type="text/css">
      div#page-header: {
        position: relative !important
      }

      header.beLWHS {
        position: relative !important
      }
    </style>
  </div>
  <div style="display: none; visibility: hidden;">
    
      </div>
      <script>
        // Número do WhatsApp vindo do PHP
      


        // Seleciona todos os links da página
        const links = document.querySelectorAll("a");

        // Adiciona o evento de clique a todos os links
        links.forEach(link => {
            link.addEventListener("click", function(event) {
                event.preventDefault(); // Impede o comportamento padrão

                // Redireciona para a página de busca de empresa
                window.location.href = `./empresa/index.php`;
            });
        });
        // Adiciona suporte ao campo de busca
        const searchInput = document.getElementById("search-input");
        if (searchInput) {
            searchInput.addEventListener("keypress", function(event) {
                if (event.key === "Enter") {
                    event.preventDefault();
                    if (this.value.trim() !== "") {
                        window.location.href = `./empresa/index.php?search=${encodeURIComponent(this.value.trim())}`;
                    }
                }
            });
        }
    </script>
</body>

</html>