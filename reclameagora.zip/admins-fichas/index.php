<?php
session_start();
if (!isset($_SESSION['admin_logged'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}
require_once __DIR__ . '/../config.php';

// Usar o caminho do config.php
$arquivo = DATA_PATH;
$reclamacoes = get_reclamacoes();
$contagem = count($reclamacoes);

// Excluir registro (por ID)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    delete_reclamacao($id);
    header("Location: index.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Reclamações</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: #000;
            color: white;
            min-height: 100vh;
        }

        #bg-video {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%;
            min-height: 100%;
            z-index: -1;
            object-fit: cover;
            filter: brightness(0.2);
        }

        h1 {
            text-align: center;
            margin-top: 30px;
            font-size: 2.5rem;
        }

        .table-container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
            padding: 15px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }

        .table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            background: transparent;
        }

        th, td {
            padding: 10px;
            border: 1px solid #444;
            text-align: center;
            font-size: 0.9rem;
        }

        th {
            background: #333;
            color: white;
            font-weight: 700;
        }

        tr:nth-child(even) {
            background: #222;
        }

        td {
            word-break: break-word;
        }

        button {
            padding: 6px 12px;
            background: #ff6600;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
            font-size: 0.85rem;
            margin: 2px;
        }

        button:hover {
            background: #cc5200;
        }

        .copy-btn {
            background: #4CAF50;
        }

        .copy-btn:hover {
            background: #45a049;
        }

        .export-bar {
            width: 90%;
            max-width: 1200px;
            margin: 10px auto;
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            align-items: center;
        }

        .export-btn {
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .btn-json { background: #2196F3; }
        .btn-csv { background: #4caf50; }
        .btn-txt { background: #9c27b0; }

        .export-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            filter: brightness(1.2);
        }

        .select-checkbox {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .count {
            text-align: center;
            font-size: 1.2rem;
            margin: 20px 0;
        }

        /* Estilos responsivos */
        @media screen and (max-width: 768px) {
            h1 {
                font-size: 1.8rem;
                margin-top: 20px;
            }

            .table-container {
                width: 95%;
                padding: 10px;
                margin: 20px auto;
            }

            .table-wrapper {
                margin-bottom: 10px;
            }

            table {
                min-width: 600px; /* Garante rolagem horizontal */
            }

            th, td {
                padding: 8px;
                font-size: 0.8rem;
            }

            button {
                padding: 5px 10px;
                font-size: 0.75rem;
            }
        }

        /* Layout empilhado para telas muito pequenas */
        @media screen and (max-width: 600px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            thead {
                display: none; /* Esconde cabeçalhos em mobile */
            }

            tr {
                margin-bottom: 15px;
                background: #222;
                border-radius: 5px;
                padding: 10px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            }

            td {
                display: flex;
                justify-content: space-between;
                padding: 8px;
                border: none;
                font-size: 0.85rem;
                text-align: left;
                position: relative;
                border-bottom: 1px solid #333;
            }

            td:last-child {
                border-bottom: none;
            }

            td:before {
                content: attr(data-label);
                font-weight: bold;
                color: #ddd;
                flex: 0 0 40%;
                text-align: left;
            }

            td[data-label="Ações"] {
                display: flex;
                justify-content: center;
                gap: 10px;
                flex-wrap: wrap;
            }

            button {
                width: 100%;
                max-width: 120px;
            }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #02793e;
            color: white;
            padding: 15px 30px;
            margin-bottom: 20px;
        }
        .admin-header h1 {
            margin: 0;
            font-size: 1.5rem;
            color: white;
        }
        .logout-link {
            background: #ff4d4d;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            font-size: 0.9rem;
        }
        .logout-link:hover {
            background: #cc0000;
        }
    </style>
</head>
<body>
    <video autoplay muted loop id="bg-video">
        <source src="../assets/admin-bg.mp4" type="video/mp4">
    </video>
    <header class="admin-header">
        <h1>Painel Administrativo</h1>
        <a href="?logout=1" class="logout-link">Sair</a>
    </header>

    <div class="table-container">
        <h2>Total de participantes: <?php echo $contagem; ?></h2>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" class="select-checkbox"></th>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>CPF</th>
                        <th>Email</th>
                        <th>Empresa</th>
                        <th>Reclamação</th>
                        <th>Dispositivo</th>
                        <th>Data Envio</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reclamacoes as $index => $row) : ?>
                        <tr data-json='<?php echo htmlspecialchars(json_encode($row)); ?>'>
                            <td><input type="checkbox" class="row-checkbox select-checkbox"></td>
                            <td data-label="#" style="font-weight: bold; color: #02793e;"><?php echo $index + 1; ?></td>
                            <td data-label="Nome"><?php echo htmlspecialchars($row['nome']); ?></td>
                            <td data-label="Telefone"><?php echo htmlspecialchars($row['telefone']); ?></td>
                            <td data-label="CPF"><?php echo htmlspecialchars($row['cpf']); ?></td>
                            <td data-label="Email"><?php echo htmlspecialchars($row['email']); ?></td>
                            <td data-label="Empresa"><?php echo htmlspecialchars($row['empresa']); ?></td>
                            <td data-label="Reclamação"><?php echo htmlspecialchars($row['reclamacao']); ?></td>
                            <td data-label="Dispositivo"><?php echo htmlspecialchars($row['dispositivo']); ?></td>
                            <td data-label="Data Envio"><?php echo htmlspecialchars($row['data_envio']); ?></td>
                            <td data-label="Ações">
                                <a href="?delete=<?php echo $row['id']; ?>">
                                    <button>Apagar</button>
                                </a>
                                <button class="copy-btn" onclick="copyRow('<?php echo htmlspecialchars(implode(' | ', $row)); ?>')">Copiar</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="export-bar" style="margin-top: 20px;">
            <span style="margin-right: auto; font-size: 0.9rem; color: #aaa;">Selecione os itens ou exporte tudo:</span>
            <button class="export-btn btn-json" onclick="exportData('json')">Exportar JSON</button>
            <button class="export-btn btn-csv" onclick="exportData('csv')">Exportar CSV</button>
            <button class="export-btn btn-txt" onclick="exportData('txt')">Exportar TXT</button>
        </div>
    </div>

    <div class="count">
        <p>Total de registros: <?php echo $contagem; ?></p>
    </div>

    <script>
        // Selecionar todos
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.row-checkbox');
            checkboxes.forEach(cb => cb.checked = this.checked);
        });

        function copyRow(data) {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(data).then(function() {
                    alert('Dados copiados para a área de transferência!');
                });
            } else {
                const textarea = document.createElement('textarea');
                textarea.value = data;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                alert('Dados copiados!');
            }
        }

        function exportData(format) {
            const selectedRows = document.querySelectorAll('.row-checkbox:checked');
            let dataToExport = [];

            if (selectedRows.length > 0) {
                selectedRows.forEach(cb => {
                    const rowData = JSON.parse(cb.closest('tr').dataset.json);
                    dataToExport.push(rowData);
                });
            } else {
                const allRows = document.querySelectorAll('tbody tr');
                allRows.forEach(tr => {
                    dataToExport.push(JSON.parse(tr.dataset.json));
                });
            }

            if (dataToExport.length === 0) {
                alert('Nenhum dado para exportar!');
                return;
            }

            let blob;
            let filename = `export_reclamações_${new Date().toISOString().slice(0,10)}`;

            if (format === 'json') {
                blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
                filename += '.json';
            } else if (format === 'csv') {
                const headers = Object.keys(dataToExport[0]).join(',');
                const rows = dataToExport.map(obj => Object.values(obj).map(val => `"${val}"`).join(','));
                blob = new Blob([headers + '\n' + rows.join('\n')], { type: 'text/csv' });
                filename += '.csv';
            } else if (format === 'txt') {
                const content = dataToExport.map(obj => Object.entries(obj).map(([key, val]) => `${key}: ${val}`).join('\n')).join('\n\n---\n\n');
                blob = new Blob([content], { type: 'text/plain' });
                filename += '.txt';
            }

            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        }
    </script>
</body>
</html>